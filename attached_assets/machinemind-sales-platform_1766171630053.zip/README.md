# MachineMind Sales Platform

## Complete SaaS System with Role-Based Access & Cost Controls

### Key Features
- ✅ **User Authentication** - Secure login with session management
- ✅ **Role-Based Access** - Admin, Manager, Rep with different permissions
- ✅ **Granular Permissions** - Control exactly what each user can see/do
- ✅ **Real-Time Sync** - Admin changes broadcast to all users instantly
- ✅ **Monitoring Dashboard** - Track API usage, errors, system health
- ✅ **Onboarding Wizard** - Guide new reps through setup
- ✅ **Prospect Intelligence** - Capture buyer type, urgency, objections
- ✅ **Call Logging** - Track calls with automatic deal scoring
- ✅ **Sales Scripts** - Centralized scripts that sync to all reps
- ✅ **Cost Controls** - Hard limits on expensive API operations
- ✅ **Admin-Only Scanning** - Lead discovery LOCKED to administrators

---

## 🔒 COST CONTROL: Admin-Only Operations

**These operations are LOCKED to administrators and CANNOT be delegated:**

| Operation | Why Restricted | Est. Cost |
|-----------|----------------|-----------|
| **Lead Scanning** | Google Places API | ~$0.03/call |
| **AI Enrichment** | OpenAI/Claude API | ~$0.02/prospect |
| **Bulk Import** | Processing overhead | Variable |
| **Automations** | Batch operations | Variable |

**Hard Enforcement:**
- These permissions are auto-stripped if someone tries to add them to non-admins
- Multiple layers of verification (role check + permission check)
- Daily and monthly spending limits with automatic blocking
- Full audit trail of all expensive operations

**Reps CAN:**
- View and work existing leads
- Create prospects manually
- Log calls and capture signals
- View scripts and strategies

**Reps CANNOT:**
- Scan for new businesses
- Enrich leads with AI
- Import bulk data
- Run automated operations

---

## Quick Deployment Guide

### Option 1: Local Development

```bash
# 1. Install dependencies
pip install flask

# 2. Run test setup (creates database + sample data)
python test_setup.py

# 3. Start API server
python api.py

# 4. Open app_v2.html in browser
# Or serve it: python -m http.server 8080
```

### Option 2: Deploy to VPS (DigitalOcean, Vultr, etc.)

```bash
# On your server:

# 1. Install Python & dependencies
sudo apt update
sudo apt install python3 python3-pip nginx
pip3 install flask gunicorn

# 2. Upload files
# Use scp, git, or your preferred method

# 3. Initialize database
python3 test_setup.py

# 4. Run with Gunicorn
gunicorn -w 4 -b 127.0.0.1:5000 api:app

# 5. Configure Nginx (see below)
```

---

## Default Logins

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@test.com | admin123 |
| Manager | manager@test.com | manager123 |
| Rep 1 | rep1@test.com | rep123 |
| Rep 2 | rep2@test.com | rep123 |

**⚠️ CHANGE PASSWORDS IMMEDIATELY AFTER FIRST LOGIN**

---

## User Roles & Permissions

### Admin
- Full access to everything
- Create/disable users
- Manage individual permissions
- Edit settings (syncs to all users)
- Manage scripts (syncs to all users)
- View monitoring dashboard

### Manager  
- View all prospects (across all reps)
- View all calls
- View analytics
- Cannot manage users or settings

### Rep (Sales Rep)
- View only their assigned prospects
- Log calls
- View scripts
- Cannot see other reps' data

### Granular Permission Control
Admins can customize permissions per user:
- `view_prospects` - See prospect list
- `create_prospects` - Add new prospects
- `edit_prospects` - Modify prospect data
- `delete_prospects` - Remove prospects
- `export_prospects` - Export data
- `log_calls` - Record calls
- `view_all_calls` - See other reps' calls
- `view_strategy` - Access closing strategies
- `view_scripts` - Access sales scripts
- `view_analytics` - See dashboard stats

---

## Real-Time Sync

When admin updates:
- **Settings** → All users get updated dropdowns instantly
- **Scripts** → All reps see new scripts within 30 seconds
- **User permissions** → Takes effect on next action

---

## Monitoring Dashboard (Admin Only)

- **System Health** - Healthy/Degraded/Critical status
- **Request Volume** - API calls per 24h
- **Response Time** - Average latency
- **Error Rate** - Percentage of failed requests
- **Active Users** - Users in last 24h
- **Recent Errors** - Last 50 errors with stack traces

---

## Onboarding Flow

New reps automatically see:
1. **Welcome** - Platform overview
2. **Profile** - Update their name
3. **First Prospect** - Add one prospect
4. **Scripts** - Review sales scripts
5. **Complete** - Ready to go

Can be skipped anytime.

---

## API Endpoints

### Authentication
```
POST /api/auth/login      - Login
POST /api/auth/logout     - Logout  
GET  /api/auth/me         - Current user
```

### Prospects
```
GET    /api/prospects              - List prospects
POST   /api/prospects              - Create prospect
GET    /api/prospects/:id          - Get prospect
PUT    /api/prospects/:id          - Update prospect
POST   /api/prospects/:id/call     - Log call
GET    /api/prospects/follow-ups   - Get due follow-ups
```

### Admin
```
GET    /api/users                  - List users
POST   /api/users                  - Create user
PUT    /api/users/:id/permissions  - Update permissions
POST   /api/users/:id/toggle       - Enable/disable user
```

### Settings & Sync
```
GET    /api/settings               - Get settings
PUT    /api/settings               - Update settings (admin)
GET    /api/sync/full              - Full data sync
GET    /api/sync/changes           - Get changes since timestamp
```

### Monitoring
```
GET    /api/monitoring/health      - System health (public)
GET    /api/monitoring/stats       - API statistics (admin)
GET    /api/monitoring/errors      - Recent errors (admin)
```

### Onboarding
```
GET    /api/onboarding/progress    - Get progress
POST   /api/onboarding/complete-step - Mark step done
POST   /api/onboarding/skip        - Skip onboarding
```

---

## File Structure

```
sales_platform/
├── database.py      # All models, users, prospects, monitoring, sync
├── api.py           # Flask API server with all endpoints
├── app_v2.html      # Full web app (login, onboarding, admin)
├── app.js           # JavaScript for app functionality
├── test_setup.py    # Test & sample data script
└── README.md        # This file
```

---

## 💰 Cost Controls

### Setting Limits (Admin Panel → Costs)
- **Daily Limit** - Max spend per day (default: $50)
- **Monthly Limit** - Max spend per month (default: $500)
- Operations automatically blocked when limits exceeded

### Cost Tracking
- Every API call is logged with estimated cost
- View daily spend history in admin panel
- Real-time remaining budget display

### Estimated Costs
```
Google Places Search:  $0.032 per call
Google Places Details: $0.017 per result
AI Enrichment:         $0.02 per prospect
```

---

## Data Ownership

All data stored in SQLite on YOUR server:
- Every prospect record
- Every call log
- Every signal captured
- User activity logs
- API request logs
- Cost tracking logs
- Complete intelligence database

Export anytime via Admin panel.

---

## Error Handling

- All API errors logged with stack traces
- Global exception handler catches unhandled errors
- Frontend shows user-friendly error messages
- Monitoring dashboard shows error trends

---

## Support

Contact: [your email]
