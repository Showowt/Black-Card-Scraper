"""
MACHINEMIND SALES PLATFORM - Database Schema
=============================================
Multi-tenant system with role-based access control.
Admin controls what reps can see/do.
"""

import sqlite3
import hashlib
import secrets
import json
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from contextlib import contextmanager
from enum import Enum


class UserRole(Enum):
    ADMIN = "admin"
    MANAGER = "manager"
    REP = "rep"


class Permission(Enum):
    # Prospect permissions
    VIEW_PROSPECTS = "view_prospects"
    CREATE_PROSPECTS = "create_prospects"  # Manual creation only
    EDIT_PROSPECTS = "edit_prospects"
    DELETE_PROSPECTS = "delete_prospects"
    EXPORT_PROSPECTS = "export_prospects"
    
    # Call permissions
    LOG_CALLS = "log_calls"
    VIEW_ALL_CALLS = "view_all_calls"  # See other reps' calls
    
    # Strategy permissions
    VIEW_STRATEGY = "view_strategy"
    VIEW_SCRIPTS = "view_scripts"
    
    # Admin permissions
    MANAGE_USERS = "manage_users"
    MANAGE_PERMISSIONS = "manage_permissions"
    VIEW_ANALYTICS = "view_analytics"
    MANAGE_SETTINGS = "manage_settings"
    
    # ============ EXPENSIVE OPERATIONS - ADMIN ONLY ============
    # These cost real money (API calls) and are LOCKED to admin only
    SCAN_LEADS = "scan_leads"              # Google Places API discovery
    ENRICH_LEADS = "enrich_leads"          # AI enrichment (OpenAI/Claude)
    BULK_IMPORT = "bulk_import"            # Bulk import from external sources
    RUN_AUTOMATIONS = "run_automations"    # Any automated/batch operations


# ============ COST-CONTROLLED PERMISSIONS ============
# These permissions can NEVER be assigned to non-admin users
# Even if someone tries to add them via API, they will be stripped
ADMIN_ONLY_PERMISSIONS = [
    Permission.SCAN_LEADS.value,
    Permission.ENRICH_LEADS.value,
    Permission.BULK_IMPORT.value,
    Permission.RUN_AUTOMATIONS.value,
]


# Default permissions by role
DEFAULT_PERMISSIONS = {
    UserRole.ADMIN: [p.value for p in Permission],  # All permissions including expensive ones
    UserRole.MANAGER: [
        Permission.VIEW_PROSPECTS.value,
        Permission.CREATE_PROSPECTS.value,
        Permission.EDIT_PROSPECTS.value,
        Permission.EXPORT_PROSPECTS.value,
        Permission.LOG_CALLS.value,
        Permission.VIEW_ALL_CALLS.value,
        Permission.VIEW_STRATEGY.value,
        Permission.VIEW_SCRIPTS.value,
        Permission.VIEW_ANALYTICS.value,
        # NO scan_leads, enrich_leads, bulk_import, run_automations
    ],
    UserRole.REP: [
        Permission.VIEW_PROSPECTS.value,
        Permission.CREATE_PROSPECTS.value,  # Can add manually, NOT scan
        Permission.EDIT_PROSPECTS.value,
        Permission.LOG_CALLS.value,
        Permission.VIEW_STRATEGY.value,
        Permission.VIEW_SCRIPTS.value,
        # NO scan_leads, enrich_leads, bulk_import, run_automations
    ]
}


class Database:
    """Main database handler with all tables"""
    
    def __init__(self, db_path: str = "machinemind_sales.db"):
        self.db_path = db_path
        self._init_database()
    
    @contextmanager
    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def _init_database(self):
        """Initialize all database tables"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # ============ USERS & AUTH ============
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id TEXT PRIMARY KEY,
                    email TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    name TEXT NOT NULL,
                    role TEXT DEFAULT 'rep',
                    is_active BOOLEAN DEFAULT 1,
                    permissions TEXT DEFAULT '[]',
                    settings TEXT DEFAULT '{}',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    last_login TEXT,
                    created_by TEXT
                )
            """)
            
            # Sessions for authentication
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    token TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    ip_address TEXT,
                    user_agent TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            # Password reset tokens
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS password_resets (
                    token TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    used BOOLEAN DEFAULT 0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            # ============ PROSPECTS ============
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS prospects (
                    id TEXT PRIMARY KEY,
                    
                    -- Basic info
                    business_name TEXT NOT NULL,
                    contact_name TEXT,
                    contact_role TEXT,
                    phone TEXT,
                    email TEXT,
                    city TEXT,
                    business_type TEXT,
                    
                    -- Signals (the genome)
                    buyer_type TEXT,
                    urgency TEXT,
                    authority TEXT,
                    budget TEXT,
                    
                    -- Pain & objections (JSON arrays)
                    pain_points TEXT DEFAULT '[]',
                    objections TEXT DEFAULT '[]',
                    
                    -- Notes & needs
                    notes TEXT,
                    needs TEXT DEFAULT '{}',
                    
                    -- Pipeline
                    deal_stage TEXT DEFAULT 'new',
                    deal_score INTEGER DEFAULT 50,
                    next_action TEXT,
                    follow_up_date TEXT,
                    
                    -- Assignment
                    assigned_to TEXT,
                    
                    -- Call tracking
                    total_calls INTEGER DEFAULT 0,
                    total_call_time INTEGER DEFAULT 0,
                    
                    -- Meta
                    source TEXT DEFAULT 'manual',
                    tags TEXT DEFAULT '[]',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    created_by TEXT,
                    
                    FOREIGN KEY (assigned_to) REFERENCES users(id),
                    FOREIGN KEY (created_by) REFERENCES users(id)
                )
            """)
            
            # ============ CALLS ============
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS calls (
                    id TEXT PRIMARY KEY,
                    prospect_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    
                    -- Call data
                    started_at TEXT,
                    ended_at TEXT,
                    duration_seconds INTEGER,
                    
                    -- Signals captured during call
                    signals_captured TEXT DEFAULT '[]',
                    
                    -- Outcome
                    outcome TEXT,
                    notes TEXT,
                    next_steps TEXT,
                    
                    -- Score before/after
                    score_before INTEGER,
                    score_after INTEGER,
                    
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    
                    FOREIGN KEY (prospect_id) REFERENCES prospects(id),
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            # ============ ADMIN SETTINGS ============
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_by TEXT
                )
            """)
            
            # ============ SCRIPTS & CONTENT ============
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS scripts (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    category TEXT,
                    content TEXT NOT NULL,
                    is_active BOOLEAN DEFAULT 1,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    created_by TEXT
                )
            """)
            
            # ============ ACTIVITY LOG ============
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS activity_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT,
                    action TEXT NOT NULL,
                    entity_type TEXT,
                    entity_id TEXT,
                    details TEXT DEFAULT '{}',
                    ip_address TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            # ============ ANALYTICS ============
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS daily_stats (
                    date TEXT NOT NULL,
                    user_id TEXT,
                    
                    -- Counts
                    calls_made INTEGER DEFAULT 0,
                    prospects_created INTEGER DEFAULT 0,
                    prospects_contacted INTEGER DEFAULT 0,
                    
                    -- Outcomes
                    deals_won INTEGER DEFAULT 0,
                    deals_lost INTEGER DEFAULT 0,
                    demos_booked INTEGER DEFAULT 0,
                    
                    -- Time
                    total_call_time INTEGER DEFAULT 0,
                    
                    PRIMARY KEY (date, user_id),
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            # ============ MONITORING & ERRORS ============
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS api_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                    user_id TEXT,
                    method TEXT,
                    endpoint TEXT,
                    status_code INTEGER,
                    response_time_ms INTEGER,
                    ip_address TEXT,
                    user_agent TEXT,
                    error_message TEXT
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS error_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                    user_id TEXT,
                    error_type TEXT,
                    error_message TEXT,
                    stack_trace TEXT,
                    endpoint TEXT,
                    request_data TEXT
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS system_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                    event_type TEXT,
                    user_id TEXT,
                    details TEXT,
                    is_read BOOLEAN DEFAULT 0
                )
            """)
            
            # ============ USER ONBOARDING ============
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS onboarding_progress (
                    user_id TEXT PRIMARY KEY,
                    step_completed INTEGER DEFAULT 0,
                    profile_completed BOOLEAN DEFAULT 0,
                    first_prospect_created BOOLEAN DEFAULT 0,
                    first_call_logged BOOLEAN DEFAULT 0,
                    scripts_viewed BOOLEAN DEFAULT 0,
                    completed_at TEXT,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            # ============ SYNC TRACKING ============
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS sync_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                    entity_type TEXT,
                    entity_id TEXT,
                    action TEXT,
                    changed_by TEXT,
                    data TEXT
                )
            """)
            
            # ============ COST TRACKING (ADMIN ONLY OPERATIONS) ============
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS api_costs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                    user_id TEXT NOT NULL,
                    operation_type TEXT NOT NULL,
                    api_provider TEXT,
                    api_calls INTEGER DEFAULT 1,
                    estimated_cost_usd REAL DEFAULT 0,
                    details TEXT,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS scan_history (
                    id TEXT PRIMARY KEY,
                    timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                    user_id TEXT NOT NULL,
                    scan_type TEXT NOT NULL,
                    query TEXT,
                    city TEXT,
                    business_type TEXT,
                    results_count INTEGER DEFAULT 0,
                    prospects_created INTEGER DEFAULT 0,
                    api_calls_used INTEGER DEFAULT 0,
                    estimated_cost_usd REAL DEFAULT 0,
                    status TEXT DEFAULT 'completed',
                    error_message TEXT,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS cost_limits (
                    id INTEGER PRIMARY KEY,
                    daily_limit_usd REAL DEFAULT 50.0,
                    monthly_limit_usd REAL DEFAULT 500.0,
                    alert_threshold_percent REAL DEFAULT 80.0,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_by TEXT
                )
            """)
            
            # Initialize cost limits
            cursor.execute("""
                INSERT OR IGNORE INTO cost_limits (id, daily_limit_usd, monthly_limit_usd)
                VALUES (1, 50.0, 500.0)
            """)
            
            # ============ INDEXES ============
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_prospects_assigned ON prospects(assigned_to)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_prospects_stage ON prospects(deal_stage)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_prospects_followup ON prospects(follow_up_date)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_calls_prospect ON calls(prospect_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_calls_user ON calls(user_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_activity_user ON activity_log(user_id)")
            
            # ============ DEFAULT ADMIN ============
            self._create_default_admin(cursor)
            
            # ============ DEFAULT SETTINGS ============
            self._create_default_settings(cursor)
            
            # ============ DEFAULT SCRIPTS ============
            self._create_default_scripts(cursor)
    
    def _create_default_admin(self, cursor):
        """Create default admin user if none exists"""
        cursor.execute("SELECT COUNT(*) as count FROM users WHERE role = 'admin'")
        if cursor.fetchone()['count'] == 0:
            admin_id = generate_id('user')
            password_hash = hash_password('admin123')  # Change this!
            
            cursor.execute("""
                INSERT INTO users (id, email, password_hash, name, role, permissions)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                admin_id,
                'admin@machinemind.ai',
                password_hash,
                'Admin',
                'admin',
                json.dumps(DEFAULT_PERMISSIONS[UserRole.ADMIN])
            ))
    
    def _create_default_settings(self, cursor):
        """Create default system settings"""
        defaults = {
            'company_name': 'MachineMind',
            'deal_stages': json.dumps(['new', 'contacted', 'qualified', 'demo', 'proposal', 'negotiation', 'won', 'lost']),
            'business_types': json.dumps(['hotel', 'villa', 'restaurant', 'tour', 'concierge']),
            'cities': json.dumps(['Cartagena', 'Medellín', 'Bogotá', 'Santa Marta', 'Barranquilla']),
            'default_follow_up_days': '3',
            'require_notes_on_call': 'true',
            'show_competitor_field': 'true',
        }
        
        for key, value in defaults.items():
            cursor.execute("""
                INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)
            """, (key, value))
    
    def _create_default_scripts(self, cursor):
        """Create default sales scripts"""
        scripts = [
            {
                'id': generate_id('script'),
                'name': 'Opening - Cold Call',
                'category': 'opening',
                'content': '''Hola [NOMBRE], soy [TU NOMBRE] de MachineMind. 

¿Tienes 2 minutos? Trabajo con hoteles/restaurantes en [CIUDAD] ayudándoles a capturar las reservas que pierden después de horas.

¿Qué pasa con las consultas que llegan a las 2am?'''
            },
            {
                'id': generate_id('script'),
                'name': 'Pain Discovery',
                'category': 'discovery',
                'content': '''PREGUNTAS CLAVE:

1. "¿Qué pasa cuando llega una consulta a las 2am?"
2. "¿Cuántas consultas crees que pierdes por semana?"
3. "¿Cuánto vale UNA reserva para ti?"
4. "Si pudieras resolver UN problema de tu negocio, ¿cuál sería?"'''
            },
            {
                'id': generate_id('script'),
                'name': 'Price Objection',
                'category': 'objection',
                'content': '''CUANDO DICEN "MUY CARO":

"Entiendo. Déjame preguntarte - ¿cuánto vale una reserva promedio para ti?"

[Espera respuesta]

"Entonces con solo recuperar [X] reservas al mes, esto se paga solo. El 67% de las consultas no se responden. ¿Cuántas de esas podrían ser tuyas?"'''
            },
            {
                'id': generate_id('script'),
                'name': 'Closing - Analytical',
                'category': 'closing',
                'content': '''PARA COMPRADORES ANALÍTICOS:

"Basado en los números que discutimos:
- [X] consultas perdidas por semana
- $[Y] valor promedio por reserva  
- = $[Z] que estás dejando en la mesa cada mes

¿Qué necesitarías ver para tomar una decisión?"'''
            },
            {
                'id': generate_id('script'),
                'name': 'Closing - Driver',
                'category': 'closing',
                'content': '''PARA COMPRADORES DIRECTOS:

"Mira, te voy a dar la línea directa:

Empezamos en 48 horas. Tú sigues haciendo lo que haces. Nosotros capturamos lo que estás perdiendo.

¿Listo para empezar, o hay algo que te detenga?"'''
            }
        ]
        
        for script in scripts:
            cursor.execute("""
                INSERT OR IGNORE INTO scripts (id, name, category, content)
                VALUES (?, ?, ?, ?)
            """, (script['id'], script['name'], script['category'], script['content']))


# ============ UTILITY FUNCTIONS ============

def generate_id(prefix: str = '') -> str:
    """Generate unique ID"""
    import uuid
    base = str(uuid.uuid4()).replace('-', '')[:12]
    return f"{prefix}_{base}" if prefix else base


def hash_password(password: str) -> str:
    """Hash password with salt"""
    salt = secrets.token_hex(16)
    hash_obj = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
    return f"{salt}:{hash_obj.hex()}"


def verify_password(password: str, password_hash: str) -> bool:
    """Verify password against hash"""
    try:
        salt, hash_value = password_hash.split(':')
        hash_obj = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
        return hash_obj.hex() == hash_value
    except:
        return False


def generate_session_token() -> str:
    """Generate secure session token"""
    return secrets.token_urlsafe(32)


# ============ USER MANAGEMENT ============

class UserManager:
    """Handle user operations"""
    
    def __init__(self, db: Database):
        self.db = db
    
    def create_user(self, email: str, password: str, name: str, 
                   role: str = 'rep', created_by: str = None) -> Dict:
        """Create new user"""
        user_id = generate_id('user')
        password_hash = hash_password(password)
        
        # Get default permissions for role
        try:
            role_enum = UserRole(role)
            permissions = DEFAULT_PERMISSIONS.get(role_enum, DEFAULT_PERMISSIONS[UserRole.REP])
        except:
            permissions = DEFAULT_PERMISSIONS[UserRole.REP]
        
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            try:
                cursor.execute("""
                    INSERT INTO users (id, email, password_hash, name, role, permissions, created_by)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (user_id, email.lower(), password_hash, name, role, json.dumps(permissions), created_by))
                
                self._log_activity(cursor, created_by, 'create_user', 'user', user_id, {'email': email, 'role': role})
                
                return {'success': True, 'user_id': user_id}
            except sqlite3.IntegrityError:
                return {'success': False, 'error': 'Email already exists'}
    
    def authenticate(self, email: str, password: str, ip: str = None, user_agent: str = None) -> Dict:
        """Authenticate user and create session"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE email = ? AND is_active = 1", (email.lower(),))
            user = cursor.fetchone()
            
            if not user or not verify_password(password, user['password_hash']):
                return {'success': False, 'error': 'Invalid credentials'}
            
            # Create session
            token = generate_session_token()
            expires_at = (datetime.utcnow() + timedelta(days=7)).isoformat()
            
            cursor.execute("""
                INSERT INTO sessions (token, user_id, expires_at, ip_address, user_agent)
                VALUES (?, ?, ?, ?, ?)
            """, (token, user['id'], expires_at, ip, user_agent))
            
            # Update last login
            cursor.execute("UPDATE users SET last_login = ? WHERE id = ?", 
                          (datetime.utcnow().isoformat(), user['id']))
            
            self._log_activity(cursor, user['id'], 'login', 'user', user['id'], {'ip': ip})
            
            return {
                'success': True,
                'token': token,
                'user': {
                    'id': user['id'],
                    'email': user['email'],
                    'name': user['name'],
                    'role': user['role'],
                    'permissions': json.loads(user['permissions'])
                }
            }
    
    def validate_session(self, token: str) -> Optional[Dict]:
        """Validate session token and return user"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT s.*, u.* FROM sessions s
                JOIN users u ON s.user_id = u.id
                WHERE s.token = ? AND s.expires_at > ? AND u.is_active = 1
            """, (token, datetime.utcnow().isoformat()))
            
            row = cursor.fetchone()
            if not row:
                return None
            
            return {
                'id': row['user_id'],
                'email': row['email'],
                'name': row['name'],
                'role': row['role'],
                'permissions': json.loads(row['permissions'])
            }
    
    def logout(self, token: str):
        """Invalidate session"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM sessions WHERE token = ?", (token,))
    
    def update_user_permissions(self, user_id: str, permissions: List[str], updated_by: str) -> Dict:
        """Update user permissions (admin only) - ENFORCES ADMIN-ONLY RESTRICTIONS"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            
            # Get the user's role
            cursor.execute("SELECT role FROM users WHERE id = ?", (user_id,))
            row = cursor.fetchone()
            if not row:
                return {'success': False, 'error': 'User not found'}
            
            user_role = row['role']
            
            # ============ CRITICAL: STRIP ADMIN-ONLY PERMISSIONS FROM NON-ADMINS ============
            if user_role != 'admin':
                original_count = len(permissions)
                permissions = [p for p in permissions if p not in ADMIN_ONLY_PERMISSIONS]
                stripped_count = original_count - len(permissions)
                
                if stripped_count > 0:
                    # Log this attempt
                    self._log_activity(
                        cursor, updated_by, 'blocked_permission_attempt', 'user', user_id,
                        {'attempted': [p for p in ADMIN_ONLY_PERMISSIONS if p in permissions],
                         'reason': 'admin_only_permissions_stripped'}
                    )
            
            cursor.execute("""
                UPDATE users SET permissions = ?, updated_at = ? WHERE id = ?
            """, (json.dumps(permissions), datetime.utcnow().isoformat(), user_id))
            
            self._log_activity(cursor, updated_by, 'update_permissions', 'user', user_id, 
                              {'permissions': permissions})
            
            return {'success': True, 'permissions': permissions}
    
    def get_all_users(self) -> List[Dict]:
        """Get all users (for admin)"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, email, name, role, is_active, permissions, created_at, last_login
                FROM users ORDER BY created_at DESC
            """)
            return [dict(row) for row in cursor.fetchall()]
    
    def get_user_permissions(self, user_id: str) -> List[str]:
        """Get permissions for a user"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT permissions FROM users WHERE id = ?", (user_id,))
            row = cursor.fetchone()
            if row:
                return json.loads(row['permissions'])
            return []
    
    def toggle_user_active(self, user_id: str, is_active: bool, updated_by: str):
        """Enable/disable user"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET is_active = ? WHERE id = ?", (is_active, user_id))
            self._log_activity(cursor, updated_by, 'toggle_user', 'user', user_id, {'is_active': is_active})
    
    def _log_activity(self, cursor, user_id: str, action: str, entity_type: str, 
                     entity_id: str, details: Dict = None):
        cursor.execute("""
            INSERT INTO activity_log (user_id, action, entity_type, entity_id, details)
            VALUES (?, ?, ?, ?, ?)
        """, (user_id, action, entity_type, entity_id, json.dumps(details or {})))


# ============ PROSPECT MANAGEMENT ============

class ProspectManager:
    """Handle prospect operations"""
    
    def __init__(self, db: Database):
        self.db = db
    
    def create_prospect(self, data: Dict, user_id: str) -> Dict:
        """Create new prospect"""
        prospect_id = generate_id('prospect')
        
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO prospects (
                    id, business_name, contact_name, contact_role, phone, email,
                    city, business_type, buyer_type, urgency, authority, budget,
                    pain_points, objections, notes, needs, deal_stage, deal_score,
                    next_action, follow_up_date, assigned_to, source, created_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                prospect_id,
                data.get('business_name', ''),
                data.get('contact_name'),
                data.get('contact_role'),
                data.get('phone'),
                data.get('email'),
                data.get('city'),
                data.get('business_type'),
                data.get('buyer_type'),
                data.get('urgency'),
                data.get('authority'),
                data.get('budget'),
                json.dumps(data.get('pain_points', [])),
                json.dumps(data.get('objections', [])),
                data.get('notes'),
                json.dumps(data.get('needs', {})),
                data.get('deal_stage', 'new'),
                data.get('deal_score', 50),
                data.get('next_action'),
                data.get('follow_up_date'),
                data.get('assigned_to', user_id),
                data.get('source', 'manual'),
                user_id
            ))
            
            return {'success': True, 'prospect_id': prospect_id}
    
    def update_prospect(self, prospect_id: str, data: Dict, user_id: str) -> Dict:
        """Update prospect"""
        # Build dynamic update query
        allowed_fields = [
            'business_name', 'contact_name', 'contact_role', 'phone', 'email',
            'city', 'business_type', 'buyer_type', 'urgency', 'authority', 'budget',
            'notes', 'deal_stage', 'deal_score', 'next_action', 'follow_up_date', 'assigned_to'
        ]
        
        updates = []
        values = []
        
        for field in allowed_fields:
            if field in data:
                updates.append(f"{field} = ?")
                values.append(data[field])
        
        # Handle JSON fields
        if 'pain_points' in data:
            updates.append("pain_points = ?")
            values.append(json.dumps(data['pain_points']))
        if 'objections' in data:
            updates.append("objections = ?")
            values.append(json.dumps(data['objections']))
        if 'needs' in data:
            updates.append("needs = ?")
            values.append(json.dumps(data['needs']))
        
        updates.append("updated_at = ?")
        values.append(datetime.utcnow().isoformat())
        values.append(prospect_id)
        
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(f"""
                UPDATE prospects SET {', '.join(updates)} WHERE id = ?
            """, values)
            
            return {'success': True}
    
    def get_prospects(self, user_id: str, user_role: str, filters: Dict = None) -> List[Dict]:
        """Get prospects based on user role and filters"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            
            query = "SELECT * FROM prospects WHERE 1=1"
            params = []
            
            # Reps only see their assigned prospects
            if user_role == 'rep':
                query += " AND assigned_to = ?"
                params.append(user_id)
            
            # Apply filters
            if filters:
                if filters.get('deal_stage'):
                    query += " AND deal_stage = ?"
                    params.append(filters['deal_stage'])
                if filters.get('assigned_to'):
                    query += " AND assigned_to = ?"
                    params.append(filters['assigned_to'])
                if filters.get('city'):
                    query += " AND city = ?"
                    params.append(filters['city'])
                if filters.get('min_score'):
                    query += " AND deal_score >= ?"
                    params.append(filters['min_score'])
            
            query += " ORDER BY updated_at DESC"
            
            cursor.execute(query, params)
            prospects = []
            for row in cursor.fetchall():
                p = dict(row)
                p['pain_points'] = json.loads(p['pain_points'] or '[]')
                p['objections'] = json.loads(p['objections'] or '[]')
                p['needs'] = json.loads(p['needs'] or '{}')
                prospects.append(p)
            
            return prospects
    
    def get_prospect(self, prospect_id: str) -> Optional[Dict]:
        """Get single prospect by ID"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM prospects WHERE id = ?", (prospect_id,))
            row = cursor.fetchone()
            
            if not row:
                return None
            
            p = dict(row)
            p['pain_points'] = json.loads(p['pain_points'] or '[]')
            p['objections'] = json.loads(p['objections'] or '[]')
            p['needs'] = json.loads(p['needs'] or '{}')
            return p
    
    def log_call(self, prospect_id: str, user_id: str, call_data: Dict) -> Dict:
        """Log a call for a prospect"""
        call_id = generate_id('call')
        
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            
            # Get current score
            cursor.execute("SELECT deal_score FROM prospects WHERE id = ?", (prospect_id,))
            row = cursor.fetchone()
            score_before = row['deal_score'] if row else 50
            
            cursor.execute("""
                INSERT INTO calls (
                    id, prospect_id, user_id, started_at, ended_at, duration_seconds,
                    signals_captured, outcome, notes, next_steps, score_before, score_after
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                call_id,
                prospect_id,
                user_id,
                call_data.get('started_at'),
                call_data.get('ended_at'),
                call_data.get('duration_seconds', 0),
                json.dumps(call_data.get('signals_captured', [])),
                call_data.get('outcome'),
                call_data.get('notes'),
                call_data.get('next_steps'),
                score_before,
                call_data.get('score_after', score_before)
            ))
            
            # Update prospect call counts
            cursor.execute("""
                UPDATE prospects SET 
                    total_calls = total_calls + 1,
                    total_call_time = total_call_time + ?,
                    updated_at = ?
                WHERE id = ?
            """, (call_data.get('duration_seconds', 0), datetime.utcnow().isoformat(), prospect_id))
            
            # Update daily stats
            today = datetime.utcnow().strftime('%Y-%m-%d')
            cursor.execute("""
                INSERT INTO daily_stats (date, user_id, calls_made, total_call_time)
                VALUES (?, ?, 1, ?)
                ON CONFLICT(date, user_id) DO UPDATE SET
                    calls_made = calls_made + 1,
                    total_call_time = total_call_time + ?
            """, (today, user_id, call_data.get('duration_seconds', 0), call_data.get('duration_seconds', 0)))
            
            return {'success': True, 'call_id': call_id}
    
    def get_prospect_calls(self, prospect_id: str) -> List[Dict]:
        """Get all calls for a prospect"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT c.*, u.name as user_name 
                FROM calls c
                LEFT JOIN users u ON c.user_id = u.id
                WHERE c.prospect_id = ?
                ORDER BY c.created_at DESC
            """, (prospect_id,))
            return [dict(row) for row in cursor.fetchall()]
    
    def get_follow_ups(self, user_id: str, user_role: str) -> List[Dict]:
        """Get prospects with follow-ups due today or overdue"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            today = datetime.utcnow().strftime('%Y-%m-%d')
            
            if user_role == 'admin':
                cursor.execute("""
                    SELECT p.*, u.name as assigned_name
                    FROM prospects p
                    LEFT JOIN users u ON p.assigned_to = u.id
                    WHERE p.follow_up_date <= ?
                    ORDER BY p.follow_up_date ASC
                """, (today,))
            else:
                cursor.execute("""
                    SELECT p.*, u.name as assigned_name
                    FROM prospects p
                    LEFT JOIN users u ON p.assigned_to = u.id
                    WHERE p.follow_up_date <= ? AND (p.assigned_to = ? OR p.created_by = ?)
                    ORDER BY p.follow_up_date ASC
                """, (today, user_id, user_id))
            
            return [dict(row) for row in cursor.fetchall()]


# ============ SETTINGS MANAGEMENT ============

class SettingsManager:
    """Handle system settings"""
    
    def __init__(self, db: Database):
        self.db = db
    
    def get_all_settings(self) -> Dict:
        """Get all settings as dict"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT key, value FROM settings")
            return {row['key']: row['value'] for row in cursor.fetchall()}
    
    def get_setting(self, key: str, default: str = None) -> str:
        """Get single setting"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
            row = cursor.fetchone()
            return row['value'] if row else default
    
    def set_setting(self, key: str, value: str, user_id: str):
        """Set a setting"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO settings (key, value, updated_by, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET
                    value = ?, updated_by = ?, updated_at = ?
            """, (key, value, user_id, datetime.utcnow().isoformat(),
                  value, user_id, datetime.utcnow().isoformat()))
    
    def get_scripts(self, category: str = None) -> List[Dict]:
        """Get sales scripts"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            if category:
                cursor.execute("SELECT * FROM scripts WHERE category = ? AND is_active = 1", (category,))
            else:
                cursor.execute("SELECT * FROM scripts WHERE is_active = 1")
            return [dict(row) for row in cursor.fetchall()]
    
    def get_settings(self) -> Dict:
        """Get all settings as dictionary"""
        return self.get_all_settings()
    
    def update_settings(self, user_id: str, settings_dict: Dict):
        """Update multiple settings at once"""
        for key, value in settings_dict.items():
            self.set_setting(key, str(value), user_id)
    
    def create_script(self, user_id: str, script_data: Dict) -> Dict:
        """Create a new script"""
        script_id = generate_id('script')
        
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO scripts (id, name, category, content, created_by)
                VALUES (?, ?, ?, ?, ?)
            """, (
                script_id,
                script_data.get('title', script_data.get('name', '')),
                script_data.get('category', 'general'),
                script_data.get('content', ''),
                user_id
            ))
            return {'success': True, 'id': script_id}


# ============ ANALYTICS ============

class AnalyticsManager:
    """Handle analytics and reporting"""
    
    def __init__(self, db: Database):
        self.db = db
    
    def get_dashboard_stats(self, user_id: str = None, days: int = 30) -> Dict:
        """Get dashboard statistics"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            
            start_date = (datetime.utcnow() - timedelta(days=days)).strftime('%Y-%m-%d')
            
            # Base query conditions
            user_filter = "AND assigned_to = ?" if user_id else ""
            params = [user_id] if user_id else []
            
            # Total prospects
            cursor.execute(f"""
                SELECT COUNT(*) as total FROM prospects WHERE 1=1 {user_filter}
            """, params)
            total_prospects = cursor.fetchone()['total']
            
            # By stage
            cursor.execute(f"""
                SELECT deal_stage, COUNT(*) as count 
                FROM prospects WHERE 1=1 {user_filter}
                GROUP BY deal_stage
            """, params)
            by_stage = {row['deal_stage']: row['count'] for row in cursor.fetchall()}
            
            # Hot prospects (score >= 70)
            cursor.execute(f"""
                SELECT COUNT(*) as hot FROM prospects 
                WHERE deal_score >= 70 {user_filter.replace('AND', 'AND' if user_filter else '')}
            """, params)
            hot_prospects = cursor.fetchone()['hot']
            
            # Follow-ups due
            cursor.execute(f"""
                SELECT COUNT(*) as due FROM prospects 
                WHERE follow_up_date <= date('now', '+3 days') 
                AND deal_stage NOT IN ('won', 'lost')
                {user_filter}
            """, params)
            follow_ups_due = cursor.fetchone()['due']
            
            # Calls this period
            call_params = [start_date] + params
            cursor.execute(f"""
                SELECT COUNT(*) as calls, SUM(duration_seconds) as time
                FROM calls 
                WHERE created_at >= ? {user_filter.replace('assigned_to', 'user_id')}
            """, call_params)
            call_stats = cursor.fetchone()
            
            return {
                'total_prospects': total_prospects,
                'by_stage': by_stage,
                'hot_prospects': hot_prospects,
                'follow_ups_due': follow_ups_due,
                'calls_this_period': call_stats['calls'] or 0,
                'call_time_minutes': (call_stats['time'] or 0) // 60
            }
    
    def get_rep_leaderboard(self, days: int = 30) -> List[Dict]:
        """Get rep performance leaderboard"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            start_date = (datetime.utcnow() - timedelta(days=days)).strftime('%Y-%m-%d')
            
            cursor.execute("""
                SELECT 
                    u.id, u.name,
                    COALESCE(SUM(ds.calls_made), 0) as calls,
                    COALESCE(SUM(ds.total_call_time), 0) as call_time,
                    COALESCE(SUM(ds.deals_won), 0) as deals_won,
                    (SELECT COUNT(*) FROM prospects WHERE assigned_to = u.id) as prospects
                FROM users u
                LEFT JOIN daily_stats ds ON u.id = ds.user_id AND ds.date >= ?
                WHERE u.role IN ('rep', 'manager') AND u.is_active = 1
                GROUP BY u.id
                ORDER BY deals_won DESC, calls DESC
            """, (start_date,))
            
            return [dict(row) for row in cursor.fetchall()]


# Initialize database
db = Database()
user_manager = UserManager(db)
prospect_manager = ProspectManager(db)
settings_manager = SettingsManager(db)
analytics_manager = AnalyticsManager(db)


# ============ MONITORING ============

class MonitoringManager:
    """Track API usage, errors, and system health"""
    
    def __init__(self, db: Database):
        self.db = db
    
    def log_api_request(self, user_id: str, method: str, endpoint: str, 
                       status_code: int, response_time_ms: int,
                       ip_address: str = None, user_agent: str = None,
                       error_message: str = None):
        """Log an API request"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO api_logs (user_id, method, endpoint, status_code, 
                                     response_time_ms, ip_address, user_agent, error_message)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (user_id, method, endpoint, status_code, response_time_ms,
                  ip_address, user_agent, error_message))
    
    def log_error(self, user_id: str, error_type: str, error_message: str,
                 stack_trace: str = None, endpoint: str = None, request_data: str = None):
        """Log an error"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO error_logs (user_id, error_type, error_message, 
                                       stack_trace, endpoint, request_data)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, error_type, error_message, stack_trace, endpoint, request_data))
    
    def get_api_stats(self, hours: int = 24) -> Dict:
        """Get API usage statistics"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            
            # Total requests
            cursor.execute("""
                SELECT COUNT(*) as total,
                       AVG(response_time_ms) as avg_time,
                       SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) as errors
                FROM api_logs
                WHERE timestamp >= datetime('now', ?)
            """, (f'-{hours} hours',))
            stats = dict(cursor.fetchone())
            
            # By endpoint
            cursor.execute("""
                SELECT endpoint, COUNT(*) as count, AVG(response_time_ms) as avg_time
                FROM api_logs
                WHERE timestamp >= datetime('now', ?)
                GROUP BY endpoint
                ORDER BY count DESC
                LIMIT 10
            """, (f'-{hours} hours',))
            stats['by_endpoint'] = [dict(row) for row in cursor.fetchall()]
            
            # By user
            cursor.execute("""
                SELECT user_id, COUNT(*) as count
                FROM api_logs
                WHERE timestamp >= datetime('now', ?) AND user_id IS NOT NULL
                GROUP BY user_id
                ORDER BY count DESC
            """, (f'-{hours} hours',))
            stats['by_user'] = [dict(row) for row in cursor.fetchall()]
            
            # Recent errors
            cursor.execute("""
                SELECT * FROM error_logs
                ORDER BY timestamp DESC
                LIMIT 20
            """)
            stats['recent_errors'] = [dict(row) for row in cursor.fetchall()]
            
            return stats
    
    def get_system_health(self) -> Dict:
        """Get system health metrics"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            
            # Active users (last 24h)
            cursor.execute("""
                SELECT COUNT(DISTINCT user_id) as active_users
                FROM api_logs
                WHERE timestamp >= datetime('now', '-24 hours')
            """)
            active_users = cursor.fetchone()['active_users']
            
            # Error rate (last hour)
            cursor.execute("""
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) as errors
                FROM api_logs
                WHERE timestamp >= datetime('now', '-1 hour')
            """)
            row = cursor.fetchone()
            total = row['total'] or 1
            errors = row['errors'] or 0
            error_rate = (errors / total) * 100
            
            # Avg response time (last hour)
            cursor.execute("""
                SELECT AVG(response_time_ms) as avg_time
                FROM api_logs
                WHERE timestamp >= datetime('now', '-1 hour')
            """)
            avg_time = cursor.fetchone()['avg_time'] or 0
            
            return {
                'status': 'healthy' if error_rate < 5 else 'degraded' if error_rate < 20 else 'critical',
                'active_users_24h': active_users,
                'error_rate_1h': round(error_rate, 2),
                'avg_response_time_ms': round(avg_time, 2),
                'timestamp': datetime.utcnow().isoformat()
            }


# ============ ONBOARDING ============

class OnboardingManager:
    """Manage new user onboarding"""
    
    STEPS = [
        {'id': 1, 'name': 'welcome', 'title': 'Welcome to MachineMind'},
        {'id': 2, 'name': 'profile', 'title': 'Complete Your Profile'},
        {'id': 3, 'name': 'first_prospect', 'title': 'Add Your First Prospect'},
        {'id': 4, 'name': 'scripts', 'title': 'Review Sales Scripts'},
        {'id': 5, 'name': 'first_call', 'title': 'Log Your First Call'},
    ]
    
    def __init__(self, db: Database):
        self.db = db
    
    def init_onboarding(self, user_id: str):
        """Initialize onboarding for new user"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR IGNORE INTO onboarding_progress (user_id, step_completed)
                VALUES (?, 0)
            """, (user_id,))
    
    def get_progress(self, user_id: str) -> Dict:
        """Get onboarding progress"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM onboarding_progress WHERE user_id = ?", (user_id,))
            row = cursor.fetchone()
            
            if not row:
                self.init_onboarding(user_id)
                return {'step': 0, 'completed': False, 'steps': self.STEPS}
            
            return {
                'step': row['step_completed'],
                'completed': row['completed_at'] is not None,
                'profile_done': bool(row['profile_completed']),
                'first_prospect_done': bool(row['first_prospect_created']),
                'first_call_done': bool(row['first_call_logged']),
                'scripts_viewed': bool(row['scripts_viewed']),
                'steps': self.STEPS
            }
    
    def complete_step(self, user_id: str, step_name: str):
        """Mark a step as completed"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            
            step_map = {
                'profile': 'profile_completed',
                'first_prospect': 'first_prospect_created',
                'first_call': 'first_call_logged',
                'scripts': 'scripts_viewed'
            }
            
            if step_name in step_map:
                cursor.execute(f"""
                    UPDATE onboarding_progress 
                    SET {step_map[step_name]} = 1, step_completed = step_completed + 1
                    WHERE user_id = ? AND {step_map[step_name]} = 0
                """, (user_id,))
            
            # Check if all done
            cursor.execute("""
                SELECT profile_completed, first_prospect_created, 
                       first_call_logged, scripts_viewed
                FROM onboarding_progress WHERE user_id = ?
            """, (user_id,))
            row = cursor.fetchone()
            
            if row and all([row['profile_completed'], row['first_prospect_created'],
                           row['first_call_logged'], row['scripts_viewed']]):
                cursor.execute("""
                    UPDATE onboarding_progress 
                    SET completed_at = ?
                    WHERE user_id = ?
                """, (datetime.utcnow().isoformat(), user_id))
    
    def skip_onboarding(self, user_id: str):
        """Skip remaining onboarding"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE onboarding_progress 
                SET completed_at = ?, step_completed = 5,
                    profile_completed = 1, first_prospect_created = 1,
                    first_call_logged = 1, scripts_viewed = 1
                WHERE user_id = ?
            """, (datetime.utcnow().isoformat(), user_id))


# ============ SYNC MANAGER ============

class SyncManager:
    """Handle real-time sync between admin updates and users"""
    
    def __init__(self, db: Database):
        self.db = db
    
    def log_change(self, entity_type: str, entity_id: str, action: str, 
                  changed_by: str, data: Dict = None):
        """Log a change for sync"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO sync_events (entity_type, entity_id, action, changed_by, data)
                VALUES (?, ?, ?, ?, ?)
            """, (entity_type, entity_id, action, changed_by, json.dumps(data or {})))
    
    def get_changes_since(self, since_timestamp: str, entity_types: List[str] = None) -> List[Dict]:
        """Get all changes since a timestamp"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            
            query = "SELECT * FROM sync_events WHERE timestamp > ?"
            params = [since_timestamp]
            
            if entity_types:
                placeholders = ','.join(['?' for _ in entity_types])
                query += f" AND entity_type IN ({placeholders})"
                params.extend(entity_types)
            
            query += " ORDER BY timestamp ASC"
            cursor.execute(query, params)
            
            return [dict(row) for row in cursor.fetchall()]
    
    def broadcast_settings_update(self, setting_key: str, setting_value: Any, changed_by: str):
        """Broadcast a settings update to all users"""
        self.log_change('settings', setting_key, 'update', changed_by, {'value': setting_value})
    
    def broadcast_script_update(self, script_id: str, action: str, changed_by: str, script_data: Dict = None):
        """Broadcast a script update"""
        self.log_change('script', script_id, action, changed_by, script_data)


# Initialize new managers
monitoring_manager = MonitoringManager(db)
onboarding_manager = OnboardingManager(db)
sync_manager = SyncManager(db)


# ============ COST TRACKING (ADMIN ONLY) ============

class CostManager:
    """Track API costs for expensive operations - ADMIN ONLY"""
    
    # Approximate costs per API call (USD)
    COST_PER_CALL = {
        'google_places_search': 0.032,      # $32 per 1000 calls
        'google_places_details': 0.017,     # $17 per 1000 calls
        'openai_gpt4': 0.03,                # ~$0.03 per enrichment
        'claude_sonnet': 0.015,             # ~$0.015 per enrichment
    }
    
    def __init__(self, db: Database):
        self.db = db
    
    def log_cost(self, user_id: str, operation_type: str, api_provider: str,
                api_calls: int = 1, details: Dict = None) -> Dict:
        """Log an API cost"""
        estimated_cost = self.COST_PER_CALL.get(api_provider, 0.01) * api_calls
        
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO api_costs (user_id, operation_type, api_provider, 
                                       api_calls, estimated_cost_usd, details)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, operation_type, api_provider, api_calls, 
                  estimated_cost, json.dumps(details or {})))
        
        return {'cost': estimated_cost}
    
    def get_daily_spend(self) -> float:
        """Get today's total spend"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT COALESCE(SUM(estimated_cost_usd), 0) as total
                FROM api_costs
                WHERE date(timestamp) = date('now')
            """)
            return cursor.fetchone()['total']
    
    def get_monthly_spend(self) -> float:
        """Get this month's total spend"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT COALESCE(SUM(estimated_cost_usd), 0) as total
                FROM api_costs
                WHERE strftime('%Y-%m', timestamp) = strftime('%Y-%m', 'now')
            """)
            return cursor.fetchone()['total']
    
    def get_limits(self) -> Dict:
        """Get cost limits"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM cost_limits WHERE id = 1")
            row = cursor.fetchone()
            return dict(row) if row else {'daily_limit_usd': 50, 'monthly_limit_usd': 500}
    
    def set_limits(self, daily: float, monthly: float, user_id: str):
        """Set cost limits (admin only)"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE cost_limits 
                SET daily_limit_usd = ?, monthly_limit_usd = ?, 
                    updated_at = ?, updated_by = ?
                WHERE id = 1
            """, (daily, monthly, datetime.utcnow().isoformat(), user_id))
    
    def check_limits(self) -> Dict:
        """Check if we're within limits"""
        limits = self.get_limits()
        daily = self.get_daily_spend()
        monthly = self.get_monthly_spend()
        
        return {
            'daily_spend': round(daily, 2),
            'daily_limit': limits['daily_limit_usd'],
            'daily_remaining': round(limits['daily_limit_usd'] - daily, 2),
            'daily_exceeded': daily >= limits['daily_limit_usd'],
            'monthly_spend': round(monthly, 2),
            'monthly_limit': limits['monthly_limit_usd'],
            'monthly_remaining': round(limits['monthly_limit_usd'] - monthly, 2),
            'monthly_exceeded': monthly >= limits['monthly_limit_usd'],
            'can_proceed': daily < limits['daily_limit_usd'] and monthly < limits['monthly_limit_usd']
        }
    
    def get_cost_history(self, days: int = 30) -> List[Dict]:
        """Get cost history"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT date(timestamp) as date, 
                       SUM(api_calls) as total_calls,
                       SUM(estimated_cost_usd) as total_cost,
                       COUNT(*) as operations
                FROM api_costs
                WHERE timestamp >= date('now', ?)
                GROUP BY date(timestamp)
                ORDER BY date DESC
            """, (f'-{days} days',))
            return [dict(row) for row in cursor.fetchall()]


# ============ LEAD SCANNER (ADMIN ONLY - HARD ENFORCED) ============

class LeadScanner:
    """
    Lead discovery and enrichment - ADMIN ONLY
    
    This class handles expensive API operations:
    - Google Places API for business discovery
    - AI enrichment (OpenAI/Claude)
    
    ALL methods require admin role verification.
    Cost limits are enforced before any operation.
    """
    
    def __init__(self, db: Database, cost_manager: CostManager):
        self.db = db
        self.cost_manager = cost_manager
    
    def _verify_admin(self, user_id: str) -> bool:
        """HARD CHECK: Verify user is admin"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT role FROM users WHERE id = ? AND is_active = 1", (user_id,))
            row = cursor.fetchone()
            return row and row['role'] == 'admin'
    
    def _check_permission(self, user_id: str, permission: str) -> bool:
        """Check if user has specific permission"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT role, permissions FROM users WHERE id = ? AND is_active = 1", (user_id,))
            row = cursor.fetchone()
            
            if not row:
                return False
            
            # Admin always has permission
            if row['role'] == 'admin':
                return True
            
            # For expensive operations, ONLY admin can proceed
            if permission in ADMIN_ONLY_PERMISSIONS:
                return False
            
            perms = json.loads(row['permissions'] or '[]')
            return permission in perms
    
    def scan_businesses(self, user_id: str, city: str, business_type: str, 
                       max_results: int = 20) -> Dict:
        """
        Scan for new businesses using Google Places API
        
        ADMIN ONLY - Hard enforced
        """
        # ============ HARD PERMISSION CHECK ============
        if not self._verify_admin(user_id):
            return {
                'success': False,
                'error': 'ACCESS DENIED: Only administrators can scan for new leads',
                'reason': 'scan_leads_admin_only'
            }
        
        if not self._check_permission(user_id, Permission.SCAN_LEADS.value):
            return {
                'success': False,
                'error': 'ACCESS DENIED: scan_leads permission required',
                'reason': 'missing_permission'
            }
        
        # ============ COST LIMIT CHECK ============
        limits = self.cost_manager.check_limits()
        if not limits['can_proceed']:
            return {
                'success': False,
                'error': f"Cost limit exceeded. Daily: ${limits['daily_spend']}/{limits['daily_limit']}, Monthly: ${limits['monthly_spend']}/{limits['monthly_limit']}",
                'reason': 'cost_limit_exceeded',
                'limits': limits
            }
        
        # ============ ESTIMATE COST ============
        estimated_calls = max_results + (max_results // 2)  # Search + some details
        estimated_cost = (
            self.cost_manager.COST_PER_CALL['google_places_search'] * 1 +
            self.cost_manager.COST_PER_CALL['google_places_details'] * max_results
        )
        
        # Log the scan attempt
        scan_id = generate_id('scan')
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO scan_history (id, user_id, scan_type, city, business_type, status)
                VALUES (?, ?, 'google_places', ?, ?, 'started')
            """, (scan_id, user_id, city, business_type))
        
        # In a real implementation, this would call Google Places API
        # For now, we return the structure showing it's admin-only
        return {
            'success': True,
            'scan_id': scan_id,
            'message': 'Scan initiated (API integration required)',
            'estimated_cost': round(estimated_cost, 2),
            'query': {
                'city': city,
                'business_type': business_type,
                'max_results': max_results
            },
            'admin_verified': True
        }
    
    def enrich_prospect(self, user_id: str, prospect_id: str) -> Dict:
        """
        Enrich a prospect with AI analysis
        
        ADMIN ONLY - Hard enforced
        """
        # ============ HARD PERMISSION CHECK ============
        if not self._verify_admin(user_id):
            return {
                'success': False,
                'error': 'ACCESS DENIED: Only administrators can enrich leads with AI',
                'reason': 'enrich_leads_admin_only'
            }
        
        # Cost check
        limits = self.cost_manager.check_limits()
        if not limits['can_proceed']:
            return {
                'success': False,
                'error': 'Cost limit exceeded',
                'limits': limits
            }
        
        # Log cost
        self.cost_manager.log_cost(
            user_id, 'enrich_prospect', 'claude_sonnet', 1,
            {'prospect_id': prospect_id}
        )
        
        return {
            'success': True,
            'message': 'Enrichment initiated (AI integration required)',
            'prospect_id': prospect_id,
            'admin_verified': True
        }
    
    def bulk_import(self, user_id: str, data: List[Dict]) -> Dict:
        """
        Bulk import prospects from external source
        
        ADMIN ONLY - Hard enforced
        """
        # ============ HARD PERMISSION CHECK ============
        if not self._verify_admin(user_id):
            return {
                'success': False,
                'error': 'ACCESS DENIED: Only administrators can bulk import',
                'reason': 'bulk_import_admin_only'
            }
        
        return {
            'success': True,
            'message': f'Bulk import of {len(data)} records initiated',
            'admin_verified': True
        }
    
    def get_scan_history(self, user_id: str, limit: int = 50) -> Dict:
        """Get scan history - admin only"""
        if not self._verify_admin(user_id):
            return {'success': False, 'error': 'Admin access required'}
        
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM scan_history
                ORDER BY timestamp DESC
                LIMIT ?
            """, (limit,))
            return {'success': True, 'history': [dict(row) for row in cursor.fetchall()]}


# Initialize cost and scanner managers
cost_manager = CostManager(db)
lead_scanner = LeadScanner(db, cost_manager)
