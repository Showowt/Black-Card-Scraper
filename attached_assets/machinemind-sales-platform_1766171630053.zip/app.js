// ============ CONFIG ============
const API_URL = window.location.hostname === 'localhost' 
    ? 'http://localhost:5000/api' 
    : '/api';

// ============ STATE ============
let currentUser = null;
let authToken = null;
let settings = {};
let prospects = [];
let allUsers = [];
let syncTimestamp = null;
let syncInterval = null;
let onboardingStep = 1;

let callState = {
    active: false,
    startTime: null,
    prospectId: null,
    signals: {},
    objections: [],
    outcome: null,
    timerInterval: null
};

// ============ API HELPER ============
async function api(endpoint, options = {}) {
    const url = `${API_URL}${endpoint}`;
    const headers = {
        'Content-Type': 'application/json',
        ...(authToken ? { 'Authorization': `Bearer ${authToken}` } : {})
    };
    
    try {
        const res = await fetch(url, { ...options, headers });
        const data = await res.json();
        
        if (!res.ok) {
            throw new Error(data.error || data.message || 'API Error');
        }
        
        return data;
    } catch (err) {
        console.error(`API Error: ${endpoint}`, err);
        showToast(err.message || 'Connection error', 'error');
        throw err;
    }
}

// ============ INIT ============
document.addEventListener('DOMContentLoaded', () => {
    const savedToken = localStorage.getItem('auth_token');
    if (savedToken) {
        authToken = savedToken;
        validateSession();
    }
    
    // Set default follow-up date
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const followUpEl = document.getElementById('call-follow-up');
    if (followUpEl) followUpEl.value = tomorrow.toISOString().split('T')[0];
});

// ============ AUTH ============
async function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    const btn = document.getElementById('login-btn');
    const error = document.getElementById('login-error');
    
    btn.textContent = 'Signing in...';
    btn.disabled = true;
    error.classList.add('hidden');
    
    try {
        const data = await api('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });
        
        if (data.success) {
            authToken = data.token;
            currentUser = data.user;
            localStorage.setItem('auth_token', authToken);
            showMainApp();
        }
    } catch (err) {
        error.textContent = err.message || 'Login failed';
        error.classList.remove('hidden');
    }
    
    btn.textContent = 'Sign In';
    btn.disabled = false;
}

async function validateSession() {
    try {
        const data = await api('/auth/me');
        currentUser = data.user;
        showMainApp();
    } catch (err) {
        localStorage.removeItem('auth_token');
        authToken = null;
    }
}

function logout() {
    api('/auth/logout', { method: 'POST' }).catch(() => {});
    localStorage.removeItem('auth_token');
    authToken = null;
    currentUser = null;
    stopSync();
    document.getElementById('main-app').classList.add('hidden');
    document.getElementById('login-screen').classList.remove('hidden');
}

// ============ MAIN APP ============
async function showMainApp() {
    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('main-app').classList.remove('hidden');
    
    document.getElementById('user-name').textContent = currentUser.name;
    document.getElementById('user-role').textContent = currentUser.role.toUpperCase();
    
    // Show admin tab if admin
    if (currentUser.role === 'admin') {
        document.getElementById('admin-tab-btn').classList.remove('hidden');
    }
    
    // Check permissions for UI elements
    applyPermissions();
    
    // Load settings
    await loadSettings();
    
    // Check onboarding
    await checkOnboarding();
    
    // Start sync
    startSync();
    
    // Load initial data
    showTab('dashboard');
}

function applyPermissions() {
    const perms = currentUser.permissions || [];
    
    // Hide create prospect button if no permission
    if (!perms.includes('create_prospects')) {
        const btn = document.getElementById('btn-new-prospect');
        if (btn) btn.classList.add('hidden');
    }
}

// ============ ONBOARDING ============
async function checkOnboarding() {
    try {
        const data = await api('/onboarding/progress');
        const progress = data.progress;
        
        if (!progress.completed) {
            showOnboarding(progress.step + 1);
        }
    } catch (err) {
        console.error('Onboarding check failed', err);
    }
}

function showOnboarding(step = 1) {
    onboardingStep = step;
    
    // Populate cities for step 3
    if (settings.cities) {
        const citySelect = document.getElementById('onboard-city');
        if (citySelect) {
            citySelect.innerHTML = '<option value="">Select...</option>' + 
                settings.cities.map(c => `<option value="${c}">${c}</option>`).join('');
        }
    }
    
    // Show modal
    document.getElementById('onboarding-modal').classList.remove('hidden');
    
    // Show correct step
    document.querySelectorAll('.onboarding-step').forEach(el => el.classList.add('hidden'));
    document.querySelector(`.onboarding-step[data-step="${step}"]`)?.classList.remove('hidden');
    
    // Update dots
    document.querySelectorAll('.onboard-dot').forEach(dot => {
        const dotStep = parseInt(dot.dataset.step);
        dot.classList.toggle('bg-blue-600', dotStep <= step);
        dot.classList.toggle('bg-gray-300', dotStep > step);
    });
    
    // Load scripts preview for step 4
    if (step === 4) loadOnboardingScripts();
    
    // Pre-fill name in step 2
    if (step === 2) {
        document.getElementById('onboard-name').value = currentUser.name;
    }
}

function nextOnboardingStep() {
    showOnboarding(onboardingStep + 1);
}

function skipOnboardingStep() {
    nextOnboardingStep();
}

async function skipOnboarding() {
    try {
        await api('/onboarding/skip', { method: 'POST' });
        document.getElementById('onboarding-modal').classList.add('hidden');
    } catch (err) {
        console.error('Skip onboarding failed', err);
    }
}

async function saveOnboardingProfile() {
    const name = document.getElementById('onboard-name').value;
    
    if (name) {
        try {
            await api('/profile', {
                method: 'PUT',
                body: JSON.stringify({ name })
            });
            currentUser.name = name;
            document.getElementById('user-name').textContent = name;
        } catch (err) {
            console.error('Profile save failed', err);
        }
    }
    
    nextOnboardingStep();
}

async function saveOnboardingProspect() {
    const business = document.getElementById('onboard-business').value;
    const contact = document.getElementById('onboard-contact').value;
    const city = document.getElementById('onboard-city').value;
    
    if (!business) {
        showToast('Enter a business name', 'error');
        return;
    }
    
    try {
        await api('/prospects', {
            method: 'POST',
            body: JSON.stringify({
                business_name: business,
                contact_name: contact,
                city: city
            })
        });
        showToast('Prospect added!');
        nextOnboardingStep();
    } catch (err) {
        console.error('Prospect creation failed', err);
    }
}

async function loadOnboardingScripts() {
    try {
        const data = await api('/scripts');
        const container = document.getElementById('onboard-scripts-preview');
        
        if (data.scripts.length === 0) {
            container.innerHTML = '<p class="text-gray-500">No scripts available yet</p>';
            return;
        }
        
        container.innerHTML = data.scripts.slice(0, 3).map(s => `
            <div class="bg-gray-50 rounded-lg p-3">
                <div class="font-medium text-sm">${s.name}</div>
                <div class="text-xs text-gray-500 capitalize">${s.category}</div>
            </div>
        `).join('');
    } catch (err) {
        console.error('Scripts load failed', err);
    }
}

async function completeOnboardingScripts() {
    try {
        await api('/onboarding/complete-step', {
            method: 'POST',
            body: JSON.stringify({ step: 'scripts' })
        });
    } catch (err) {
        console.error('Complete step failed', err);
    }
    nextOnboardingStep();
}

function finishOnboarding() {
    document.getElementById('onboarding-modal').classList.add('hidden');
}

// ============ SYNC ============
function startSync() {
    syncTimestamp = new Date().toISOString();
    document.getElementById('sync-indicator').classList.remove('hidden');
    
    // Sync every 30 seconds
    syncInterval = setInterval(checkForUpdates, 30000);
}

function stopSync() {
    if (syncInterval) clearInterval(syncInterval);
    document.getElementById('sync-indicator').classList.add('hidden');
}

async function checkForUpdates() {
    try {
        const data = await api(`/sync/changes?since=${encodeURIComponent(syncTimestamp)}`);
        
        if (data.changes && data.changes.length > 0) {
            // Process changes
            for (const change of data.changes) {
                if (change.entity_type === 'settings') {
                    // Reload settings
                    await loadSettings();
                    showToast('Settings updated by admin', 'info');
                } else if (change.entity_type === 'script') {
                    // Reload scripts if on that tab
                    if (document.getElementById('tab-scripts').classList.contains('hidden') === false) {
                        loadScripts();
                    }
                    showToast('Scripts updated by admin', 'info');
                }
            }
        }
        
        syncTimestamp = data.timestamp;
    } catch (err) {
        console.error('Sync check failed', err);
    }
}

// ============ SETTINGS ============
async function loadSettings() {
    try {
        const data = await api('/sync/full');
        settings = data.settings;
        
        // Populate filter dropdowns
        const stages = settings.deal_stages || [];
        const cities = settings.cities || [];
        
        document.getElementById('filter-stage').innerHTML = '<option value="">All Stages</option>' +
            stages.map(s => `<option value="${s}">${s}</option>`).join('');
        document.getElementById('filter-city').innerHTML = '<option value="">All Cities</option>' +
            cities.map(c => `<option value="${c}">${c}</option>`).join('');
    } catch (err) {
        console.error('Settings load failed', err);
    }
}

// ============ TABS ============
function showTab(tab) {
    document.querySelectorAll('#main-nav button').forEach(btn => {
        btn.classList.remove('tab-active');
        if (btn.dataset.tab === tab) btn.classList.add('tab-active');
    });
    
    document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
    document.getElementById(`tab-${tab}`).classList.remove('hidden');
    
    switch(tab) {
        case 'dashboard': loadDashboard(); break;
        case 'prospects': loadProspects(); break;
        case 'call': loadCallTab(); break;
        case 'scripts': loadScripts(); break;
        case 'admin': loadAdminData(); break;
    }
}

// ============ DASHBOARD ============
async function loadDashboard() {
    try {
        const data = await api('/analytics/dashboard');
        const stats = data.stats;
        
        document.getElementById('stat-total').textContent = stats.total_prospects;
        document.getElementById('stat-hot').textContent = stats.hot_prospects;
        document.getElementById('stat-followups').textContent = stats.follow_ups_due;
        document.getElementById('stat-calls').textContent = stats.calls_this_period;
        
        // Pipeline
        const stages = settings.deal_stages || ['new', 'contacted', 'qualified', 'demo', 'proposal', 'negotiation', 'won', 'lost'];
        document.getElementById('pipeline-stages').innerHTML = stages.map(stage => `
            <div class="text-center p-2 bg-gray-100 rounded-lg">
                <div class="text-xl font-bold">${stats.by_stage[stage] || 0}</div>
                <div class="text-xs text-gray-500 capitalize">${stage}</div>
            </div>
        `).join('');
        
        // Follow-ups
        const followData = await api('/prospects/follow-ups?days=7');
        
        if (followData.prospects.length === 0) {
            document.getElementById('followups-list').innerHTML = '<p class="text-gray-500 text-sm">No follow-ups due</p>';
        } else {
            document.getElementById('followups-list').innerHTML = followData.prospects.slice(0, 5).map(p => `
                <div class="flex items-center justify-between bg-gray-50 rounded-lg p-3 cursor-pointer hover:bg-gray-100" onclick="goToProspect('${p.id}')">
                    <div>
                        <div class="font-medium">${p.business_name}</div>
                        <div class="text-sm text-gray-500">${p.contact_name || 'No contact'}</div>
                    </div>
                    <div class="text-right">
                        <div class="text-sm text-orange-600">${p.follow_up_date}</div>
                        <div class="text-xs text-gray-500">Score: ${p.deal_score}</div>
                    </div>
                </div>
            `).join('');
        }
    } catch (err) {
        showToast('Failed to load dashboard', 'error');
    }
}

function goToProspect(id) {
    showTab('call');
    document.getElementById('call-prospect-select').value = id;
    loadProspectForCall();
}

// ============ PROSPECTS ============
async function loadProspects() {
    const stage = document.getElementById('filter-stage').value;
    const city = document.getElementById('filter-city').value;
    const minScore = document.getElementById('filter-min-score').value;
    
    let params = [];
    if (stage) params.push(`stage=${stage}`);
    if (city) params.push(`city=${city}`);
    if (minScore) params.push(`min_score=${minScore}`);
    
    try {
        const data = await api(`/prospects?${params.join('&')}`);
        prospects = data.prospects;
        
        if (prospects.length === 0) {
            document.getElementById('prospects-list').innerHTML = '<p class="text-gray-500 text-center py-8">No prospects found</p>';
            return;
        }
        
        document.getElementById('prospects-list').innerHTML = prospects.map(p => `
            <div class="bg-white rounded-xl shadow-sm p-4 flex items-center justify-between cursor-pointer hover:shadow-md" onclick="goToProspect('${p.id}')">
                <div>
                    <div class="font-semibold">${p.business_name}</div>
                    <div class="text-sm text-gray-500">${p.contact_name || 'No contact'} • ${p.city || 'No city'} • ${p.business_type || 'No type'}</div>
                </div>
                <div class="text-right">
                    <div class="text-2xl font-bold ${p.deal_score >= 70 ? 'text-green-600' : p.deal_score >= 40 ? 'text-yellow-600' : 'text-red-600'}">${p.deal_score}</div>
                    <div class="text-xs text-gray-500 capitalize">${p.deal_stage}</div>
                </div>
            </div>
        `).join('');
    } catch (err) {
        showToast('Failed to load prospects', 'error');
    }
}

function showNewProspectModal() {
    const cities = settings.cities || [];
    const types = settings.business_types || [];
    
    document.getElementById('new-prospect-city').innerHTML = '<option value="">Select...</option>' + 
        cities.map(c => `<option value="${c}">${c}</option>`).join('');
    document.getElementById('new-prospect-type').innerHTML = '<option value="">Select...</option>' + 
        types.map(t => `<option value="${t}">${t}</option>`).join('');
    
    document.getElementById('new-prospect-modal').classList.remove('hidden');
}

async function createProspect(e) {
    e.preventDefault();
    
    const data = {
        business_name: document.getElementById('new-prospect-business').value,
        contact_name: document.getElementById('new-prospect-contact').value,
        contact_role: document.getElementById('new-prospect-role').value,
        phone: document.getElementById('new-prospect-phone').value,
        email: document.getElementById('new-prospect-email').value,
        city: document.getElementById('new-prospect-city').value,
        business_type: document.getElementById('new-prospect-type').value
    };
    
    try {
        await api('/prospects', {
            method: 'POST',
            body: JSON.stringify(data)
        });
        showToast('Prospect created');
        closeModal('new-prospect-modal');
        loadProspects();
        
        // Clear form
        e.target.reset();
    } catch (err) {
        showToast('Failed to create prospect', 'error');
    }
}

// ============ CALL TAB ============
async function loadCallTab() {
    try {
        const data = await api('/prospects');
        
        document.getElementById('call-prospect-select').innerHTML = 
            '<option value="">Select Prospect...</option>' +
            data.prospects.map(p => `<option value="${p.id}">${p.business_name} - ${p.contact_name || 'No contact'}</option>`).join('');
        
        prospects = data.prospects;
    } catch (err) {
        console.error('Failed to load prospects for call', err);
    }
}

function loadProspectForCall() {
    const prospectId = document.getElementById('call-prospect-select').value;
    
    // Hide contact actions if no prospect
    document.getElementById('call-contact-actions').classList.add('hidden');
    document.getElementById('call-prospect-info').classList.add('hidden');
    
    if (!prospectId) return;
    
    callState.prospectId = prospectId;
    const prospect = prospects.find(p => p.id === prospectId);
    
    if (prospect) {
        // Load existing signals
        callState.signals = {
            buyer_type: prospect.buyer_type,
            urgency: prospect.urgency,
            authority: prospect.authority,
            budget: prospect.budget
        };
        callState.objections = prospect.objections || [];
        callState.outcome = null;
        
        // Show prospect info
        document.getElementById('call-prospect-info').classList.remove('hidden');
        document.getElementById('call-prospect-name').textContent = prospect.business_name;
        document.getElementById('call-prospect-contact').textContent = prospect.contact_name || 'No contact name';
        document.getElementById('call-prospect-phone').textContent = prospect.phone || 'No phone';
        
        // Show contact actions if phone exists
        if (prospect.phone) {
            document.getElementById('call-contact-actions').classList.remove('hidden');
            
            // Clean phone number for WhatsApp (remove spaces, dashes, etc.)
            const cleanPhone = prospect.phone.replace(/[\s\-\(\)\.]/g, '').replace(/^\+/, '');
            
            // WhatsApp link (wa.me format)
            document.getElementById('whatsapp-link').href = `https://wa.me/${cleanPhone}`;
            
            // Direct phone link
            document.getElementById('phone-link').href = `tel:${prospect.phone}`;
        }
        
        // Update UI
        renderCallObjections();
        updateCallDealScore();
        
        // Highlight existing signals
        document.querySelectorAll('#tab-call .signal-btn').forEach(btn => btn.classList.remove('selected'));
        Object.entries(callState.signals).forEach(([type, value]) => {
            if (value) {
                const btn = document.querySelector(`#tab-call button[onclick*="'${type}', '${value}'"]`);
                if (btn) btn.classList.add('selected');
            }
        });
        
        // Clear outcome buttons
        document.querySelectorAll('#tab-call button[onclick^="setCallOutcome"]').forEach(btn => {
            btn.classList.remove('selected');
        });
    }
}

function toggleCall() {
    if (callState.active) {
        endCall();
    } else {
        startCall();
    }
}

function startCall() {
    if (!callState.prospectId) {
        showToast('Select a prospect first', 'error');
        return;
    }
    
    callState.active = true;
    callState.startTime = new Date();
    
    document.getElementById('call-status').className = 'w-3 h-3 rounded-full bg-green-500 animate-pulse';
    document.getElementById('call-toggle-btn').textContent = '⏹ END LOGGING';
    document.getElementById('call-toggle-btn').className = 'bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg font-medium';
    
    callState.timerInterval = setInterval(() => {
        const elapsed = Math.floor((new Date() - callState.startTime) / 1000);
        const mins = Math.floor(elapsed / 60).toString().padStart(2, '0');
        const secs = (elapsed % 60).toString().padStart(2, '0');
        document.getElementById('call-timer').textContent = `${mins}:${secs}`;
    }, 1000);
    
    showToast('Call logging started - capture signals during your WhatsApp call');
}

function endCall() {
    callState.active = false;
    clearInterval(callState.timerInterval);
    
    document.getElementById('call-status').className = 'w-3 h-3 rounded-full bg-gray-500';
    document.getElementById('call-toggle-btn').textContent = '▶ START LOGGING';
    document.getElementById('call-toggle-btn').className = 'bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg font-medium';
    
    showToast('Call ended - review and save your log');
}

function setCallOutcome(outcome, btn) {
    callState.outcome = outcome;
    
    // Update UI
    document.querySelectorAll('#tab-call button[onclick^="setCallOutcome"]').forEach(b => {
        b.classList.remove('selected');
    });
    if (btn) btn.classList.add('selected');
}

function setCallSignal(type, value, btn) {
    callState.signals[type] = value;
    
    if (btn) {
        btn.parentElement.querySelectorAll('button').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
    }
    
    updateCallDealScore();
}

function addCallObjection(type) {
    callState.objections.push({ type, addressed: false, timestamp: new Date().toISOString() });
    renderCallObjections();
    updateCallDealScore();
}

function renderCallObjections() {
    const icons = { price: '💰', timing: '⏰', trust: '🤔', authority: '👤', competitor: '🆚', need: '❓' };
    document.getElementById('call-objections-list').innerHTML = callState.objections.map((o, i) => `
        <div class="flex items-center justify-between bg-red-900/30 rounded px-2 py-1 text-sm">
            <span>${icons[o.type] || '⚠️'} ${o.type}</span>
            <button onclick="toggleCallObjAddressed(${i})" class="${o.addressed ? 'text-green-400' : 'text-gray-400'}">
                ${o.addressed ? '✅' : 'Done'}
            </button>
        </div>
    `).join('');
}

function toggleCallObjAddressed(i) {
    callState.objections[i].addressed = !callState.objections[i].addressed;
    renderCallObjections();
    updateCallDealScore();
}

function updateCallDealScore() {
    let score = 50;
    
    const urgencyScores = { bleeding: 25, urgent: 15, planning: 5, browsing: -10 };
    score += urgencyScores[callState.signals.urgency] || 0;
    
    if (callState.signals.authority === 'sole') score += 15;
    else if (callState.signals.authority === 'influencer') score += 5;
    else if (callState.signals.authority === 'gatekeeper') score -= 10;
    
    if (callState.signals.budget === 'flexible') score += 15;
    else if (callState.signals.budget === 'price_first') score -= 5;
    else if (callState.signals.budget === 'constrained') score -= 10;
    
    const unaddressed = callState.objections.filter(o => !o.addressed).length;
    score -= unaddressed * 5;
    
    score = Math.max(0, Math.min(100, score));
    
    const el = document.getElementById('call-deal-score');
    el.textContent = score;
    el.className = `text-2xl font-bold ${score >= 70 ? 'text-green-400' : score >= 40 ? 'text-yellow-400' : 'text-red-400'}`;
}

async function saveCallData() {
    if (!callState.prospectId) {
        showToast('No prospect selected', 'error');
        return;
    }
    
    const score = parseInt(document.getElementById('call-deal-score').textContent);
    
    // Update deal stage based on outcome if applicable
    let newStage = null;
    if (callState.outcome === 'interested') {
        newStage = 'qualified';
    } else if (callState.outcome === 'not_interested') {
        newStage = 'lost';
    }
    
    const prospectData = {
        buyer_type: callState.signals.buyer_type,
        urgency: callState.signals.urgency,
        authority: callState.signals.authority,
        budget: callState.signals.budget,
        objections: callState.objections,
        notes: document.getElementById('call-notes').value,
        next_action: document.getElementById('call-next-action').value,
        follow_up_date: document.getElementById('call-follow-up').value,
        deal_score: score
    };
    
    if (newStage) {
        prospectData.deal_stage = newStage;
    }
    
    try {
        await api(`/prospects/${callState.prospectId}`, {
            method: 'PUT',
            body: JSON.stringify(prospectData)
        });
        
        // Log the call if we have timing data
        const duration = callState.startTime 
            ? Math.floor((new Date() - callState.startTime) / 1000) 
            : 0;
            
        await api(`/prospects/${callState.prospectId}/call`, {
            method: 'POST',
            body: JSON.stringify({
                started_at: callState.startTime ? callState.startTime.toISOString() : new Date().toISOString(),
                ended_at: new Date().toISOString(),
                duration_seconds: duration,
                signals_captured: Object.keys(callState.signals).filter(k => callState.signals[k]),
                outcome: callState.outcome,
                notes: document.getElementById('call-notes').value,
                next_steps: document.getElementById('call-next-action').value,
                score_after: score
            })
        });
        
        showToast('Call logged successfully!');
        
        // Reset for next call
        callState.startTime = null;
        document.getElementById('call-timer').textContent = '00:00';
        document.getElementById('call-notes').value = '';
        document.getElementById('call-next-action').value = '';
        
    } catch (err) {
        showToast('Failed to save call log', 'error');
    }
}

async function showCallStrategy() {
    if (!callState.prospectId) {
        showToast('Select a prospect first', 'error');
        return;
    }
    
    try {
        const data = await api(`/strategy/${callState.prospectId}`);
        const s = data.strategy;
        
        const panel = document.getElementById('call-strategy-panel');
        panel.innerHTML = `
            <h4 class="font-semibold text-purple-400 mb-2">${s.approach}</h4>
            <div class="mb-3">
                <p class="text-xs text-gray-400 mb-1">DO:</p>
                <ul class="text-sm space-y-1">${(s.do || []).map(d => `<li>✓ ${d}</li>`).join('')}</ul>
            </div>
            ${s.avoid?.length ? `
                <div class="mb-3">
                    <p class="text-xs text-gray-400 mb-1">AVOID:</p>
                    <ul class="text-sm space-y-1">${s.avoid.map(a => `<li>✗ ${a}</li>`).join('')}</ul>
                </div>
            ` : ''}
            ${s.must_address?.length ? `
                <div class="mb-3 p-2 bg-red-900/30 rounded border border-red-500/30">
                    <p class="text-xs text-red-400 mb-1">⚠️ MUST ADDRESS:</p>
                    <ul class="text-sm">${s.must_address.map(m => `<li>• ${m}</li>`).join('')}</ul>
                </div>
            ` : ''}
            <div class="p-2 bg-yellow-900/30 rounded border border-yellow-500/30">
                <p class="text-xs text-yellow-400 mb-1">CLOSING QUESTION:</p>
                <p class="italic">"${s.closing_question}"</p>
            </div>
            <div class="mt-3 text-center py-2 bg-gray-900/50 rounded">
                <div class="text-lg font-bold">${s.deal_score}</div>
                <div class="text-xs text-gray-400">${s.recommendation}</div>
            </div>
        `;
        panel.classList.remove('hidden');
    } catch (err) {
        showToast('Failed to load strategy', 'error');
    }
}

// ============ SCRIPTS ============
async function loadScripts() {
    try {
        const data = await api('/scripts');
        
        document.getElementById('scripts-list').innerHTML = data.scripts.map(s => `
            <div class="bg-white rounded-xl shadow-sm p-4">
                <div class="flex items-center justify-between mb-2">
                    <h3 class="font-semibold">${s.name}</h3>
                    <span class="text-xs bg-gray-100 px-2 py-1 rounded capitalize">${s.category}</span>
                </div>
                <pre class="text-sm text-gray-700 whitespace-pre-wrap bg-gray-50 p-3 rounded">${s.content}</pre>
            </div>
        `).join('');
    } catch (err) {
        showToast('Failed to load scripts', 'error');
    }
}

// ============ ADMIN ============
async function loadAdminData() {
    loadUsers();
    loadAdminSettings();
    loadAdminScripts();
    loadMonitoring();
    loadScanningSection();
    loadCostStatus();
}

function showAdminSection(section) {
    document.querySelectorAll('.admin-section').forEach(el => el.classList.add('hidden'));
    document.getElementById(`admin-${section}`).classList.remove('hidden');
    
    document.querySelectorAll('[id^="admin-"][id$="-tab"]').forEach(el => {
        el.classList.remove('border-blue-500', 'text-blue-600', 'border-b-2');
        el.classList.add('text-gray-600');
    });
    
    const tabId = `admin-${section.split('-')[0]}-tab`;
    const tab = document.getElementById(tabId);
    if (tab) {
        tab.classList.add('border-blue-500', 'text-blue-600', 'border-b-2');
        tab.classList.remove('text-gray-600');
    }
    
    // Load section-specific data
    if (section === 'costs') {
        loadCostStatus();
        loadScanCode();
    } else if (section === 'scanning') {
        loadScanningSection();
    } else if (section === 'monitoring') {
        loadMonitoringStats();
    }
}

async function loadUsers() {
    try {
        const data = await api('/users');
        allUsers = data.users;
        
        document.getElementById('users-list').innerHTML = `
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="text-left p-3 text-sm font-medium text-gray-500">Name</th>
                        <th class="text-left p-3 text-sm font-medium text-gray-500">Email</th>
                        <th class="text-left p-3 text-sm font-medium text-gray-500">Role</th>
                        <th class="text-left p-3 text-sm font-medium text-gray-500">Status</th>
                        <th class="text-left p-3 text-sm font-medium text-gray-500">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y">
                    ${allUsers.map(u => `
                        <tr>
                            <td class="p-3">${u.name}</td>
                            <td class="p-3 text-gray-500">${u.email}</td>
                            <td class="p-3"><span class="px-2 py-1 bg-gray-100 rounded text-xs uppercase">${u.role}</span></td>
                            <td class="p-3">
                                <span class="px-2 py-1 rounded text-xs ${u.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}">
                                    ${u.is_active ? 'Active' : 'Disabled'}
                                </span>
                            </td>
                            <td class="p-3">
                                <button onclick="toggleUserActive('${u.id}', ${!u.is_active})" class="text-sm text-blue-600 hover:text-blue-700">
                                    ${u.is_active ? 'Disable' : 'Enable'}
                                </button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
        
        // Populate permission user select
        document.getElementById('permission-user-select').innerHTML = 
            '<option value="">Select user...</option>' +
            allUsers.map(u => `<option value="${u.id}">${u.name} (${u.role})</option>`).join('');
            
    } catch (err) {
        showToast('Failed to load users', 'error');
    }
}

function showNewUserModal() {
    document.getElementById('new-user-modal').classList.remove('hidden');
}

async function createUser(e) {
    e.preventDefault();
    
    const data = {
        name: document.getElementById('new-user-name').value,
        email: document.getElementById('new-user-email').value,
        password: document.getElementById('new-user-password').value,
        role: document.getElementById('new-user-role').value
    };
    
    try {
        await api('/users', {
            method: 'POST',
            body: JSON.stringify(data)
        });
        showToast('User created');
        closeModal('new-user-modal');
        loadUsers();
        e.target.reset();
    } catch (err) {
        showToast(err.message || 'Failed to create user', 'error');
    }
}

async function toggleUserActive(userId, isActive) {
    try {
        await api(`/users/${userId}/toggle`, {
            method: 'POST',
            body: JSON.stringify({ is_active: isActive })
        });
        loadUsers();
    } catch (err) {
        showToast('Failed to update user', 'error');
    }
}

async function loadUserPermissions() {
    const userId = document.getElementById('permission-user-select').value;
    if (!userId) {
        document.getElementById('permission-checkboxes').classList.add('hidden');
        return;
    }
    
    const user = allUsers.find(u => u.id === userId);
    if (!user) return;
    
    const userPerms = typeof user.permissions === 'string' ? JSON.parse(user.permissions) : (user.permissions || []);
    
    const allPerms = [
        { id: 'view_prospects', label: 'View Prospects' },
        { id: 'create_prospects', label: 'Create Prospects' },
        { id: 'edit_prospects', label: 'Edit Prospects' },
        { id: 'delete_prospects', label: 'Delete Prospects' },
        { id: 'export_prospects', label: 'Export Data' },
        { id: 'log_calls', label: 'Log Calls' },
        { id: 'view_all_calls', label: 'View All Calls' },
        { id: 'view_strategy', label: 'View Strategy' },
        { id: 'view_scripts', label: 'View Scripts' },
        { id: 'view_analytics', label: 'View Analytics' },
        { id: 'manage_users', label: 'Manage Users' },
        { id: 'manage_settings', label: 'Manage Settings' }
    ];
    
    document.getElementById('permission-list').innerHTML = allPerms.map(p => `
        <label class="flex items-center gap-2 p-2 bg-gray-50 rounded cursor-pointer">
            <input type="checkbox" class="perm-checkbox w-4 h-4" value="${p.id}" ${userPerms.includes(p.id) ? 'checked' : ''}>
            <span class="text-sm">${p.label}</span>
        </label>
    `).join('');
    
    document.getElementById('permission-checkboxes').classList.remove('hidden');
}

async function saveUserPermissions() {
    const userId = document.getElementById('permission-user-select').value;
    if (!userId) return;
    
    const permissions = Array.from(document.querySelectorAll('.perm-checkbox:checked')).map(cb => cb.value);
    
    try {
        await api(`/users/${userId}/permissions`, {
            method: 'PUT',
            body: JSON.stringify({ permissions })
        });
        showToast('Permissions saved');
        loadUsers();
    } catch (err) {
        showToast('Failed to save permissions', 'error');
    }
}

async function loadAdminSettings() {
    document.getElementById('setting-company-name').value = settings.company_name || '';
    document.getElementById('setting-deal-stages').value = (settings.deal_stages || []).join(', ');
    document.getElementById('setting-cities').value = (settings.cities || []).join(', ');
    document.getElementById('setting-business-types').value = (settings.business_types || []).join(', ');
}

async function saveSettings() {
    const data = {
        company_name: document.getElementById('setting-company-name').value,
        deal_stages: document.getElementById('setting-deal-stages').value.split(',').map(s => s.trim()).filter(s => s),
        cities: document.getElementById('setting-cities').value.split(',').map(s => s.trim()).filter(s => s),
        business_types: document.getElementById('setting-business-types').value.split(',').map(s => s.trim()).filter(s => s)
    };
    
    try {
        await api('/settings', {
            method: 'PUT',
            body: JSON.stringify(data)
        });
        showToast('Settings saved & synced to all users');
        await loadSettings();
    } catch (err) {
        showToast('Failed to save settings', 'error');
    }
}

async function loadAdminScripts() {
    try {
        const data = await api('/scripts');
        
        document.getElementById('admin-scripts-list').innerHTML = data.scripts.map(s => `
            <div class="bg-white rounded-xl shadow-sm p-4">
                <div class="flex items-center justify-between mb-2">
                    <div>
                        <h3 class="font-semibold">${s.name}</h3>
                        <span class="text-xs text-gray-500 capitalize">${s.category}</span>
                    </div>
                    <button onclick="deleteScript('${s.id}')" class="text-red-600 hover:text-red-700 text-sm">Delete</button>
                </div>
                <pre class="text-sm text-gray-700 whitespace-pre-wrap bg-gray-50 p-3 rounded max-h-32 overflow-y-auto">${s.content}</pre>
            </div>
        `).join('');
    } catch (err) {
        console.error('Scripts load failed', err);
    }
}

function showNewScriptModal() {
    document.getElementById('new-script-modal').classList.remove('hidden');
}

async function createScript(e) {
    e.preventDefault();
    
    const data = {
        name: document.getElementById('new-script-name').value,
        category: document.getElementById('new-script-category').value,
        content: document.getElementById('new-script-content').value
    };
    
    try {
        await api('/scripts', {
            method: 'POST',
            body: JSON.stringify(data)
        });
        showToast('Script created & synced');
        closeModal('new-script-modal');
        loadAdminScripts();
        e.target.reset();
    } catch (err) {
        showToast('Failed to create script', 'error');
    }
}

async function deleteScript(scriptId) {
    if (!confirm('Delete this script?')) return;
    
    try {
        await api(`/scripts/${scriptId}`, { method: 'DELETE' });
        showToast('Script deleted');
        loadAdminScripts();
    } catch (err) {
        showToast('Failed to delete script', 'error');
    }
}

async function loadMonitoring() {
    try {
        // Health
        const health = await api('/monitoring/health');
        document.getElementById('health-badge').textContent = health.status.toUpperCase();
        document.getElementById('health-badge').className = `px-3 py-1 rounded-full text-sm ${
            health.status === 'healthy' ? 'bg-green-100 text-green-700' :
            health.status === 'degraded' ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'
        }`;
        
        document.getElementById('mon-active').textContent = health.active_users_24h;
        document.getElementById('mon-errors').textContent = health.error_rate_1h + '%';
        document.getElementById('mon-response').textContent = Math.round(health.avg_response_time_ms) + 'ms';
        
        // Stats
        const stats = await api('/monitoring/stats?hours=24');
        document.getElementById('mon-requests').textContent = stats.stats.total || 0;
        
        // Errors
        if (stats.stats.recent_errors && stats.stats.recent_errors.length > 0) {
            document.getElementById('error-list').innerHTML = stats.stats.recent_errors.slice(0, 10).map(e => `
                <div class="bg-red-50 rounded p-2 text-sm">
                    <div class="font-medium text-red-700">${e.error_type}</div>
                    <div class="text-red-600 text-xs">${e.error_message}</div>
                    <div class="text-gray-500 text-xs mt-1">${e.endpoint} • ${e.timestamp}</div>
                </div>
            `).join('');
        } else {
            document.getElementById('error-list').innerHTML = '<p class="text-green-600 text-sm">No recent errors 🎉</p>';
        }
    } catch (err) {
        console.error('Monitoring load failed', err);
    }
}

// ============ SCANNING (ADMIN ONLY) ============

async function loadScanningSection() {
    // Check if user is admin
    if (currentUser.role !== 'admin') {
        document.getElementById('admin-scanning').innerHTML = `
            <div class="bg-red-50 border border-red-200 rounded-xl p-6 text-center">
                <div class="text-4xl mb-4">🔒</div>
                <h3 class="text-lg font-semibold text-red-700">Access Denied</h3>
                <p class="text-red-600">Lead scanning is restricted to administrators only due to API costs.</p>
            </div>
        `;
        return;
    }
    
    // Populate dropdowns
    const cities = settings.cities || [];
    const types = settings.business_types || [];
    
    document.getElementById('scan-city').innerHTML = '<option value="">Select city...</option>' +
        cities.map(c => `<option value="${c}">${c}</option>`).join('');
    document.getElementById('scan-type').innerHTML = '<option value="">Select type...</option>' +
        types.map(t => `<option value="${t}">${t}</option>`).join('');
    
    // Load cost status
    await loadCostStatus();
    
    // Load scan history
    await loadScanHistory();
    
    // Set up cost estimate
    document.getElementById('scan-max').addEventListener('input', updateScanEstimate);
}

async function loadCostStatus() {
    try {
        const data = await api('/costs/status');
        const status = data.status;
        
        document.getElementById('scan-daily-spend').textContent = '$' + status.daily_spend.toFixed(2);
        document.getElementById('scan-daily-limit').textContent = status.daily_limit.toFixed(2);
        document.getElementById('scan-monthly-spend').textContent = '$' + status.monthly_spend.toFixed(2);
        document.getElementById('scan-monthly-limit').textContent = status.monthly_limit.toFixed(2);
        
        // Color code based on usage
        const dailyEl = document.getElementById('scan-daily-spend');
        const monthlyEl = document.getElementById('scan-monthly-spend');
        
        dailyEl.className = `text-2xl font-bold ${status.daily_exceeded ? 'text-red-600' : status.daily_spend > status.daily_limit * 0.8 ? 'text-yellow-600' : 'text-green-600'}`;
        monthlyEl.className = `text-2xl font-bold ${status.monthly_exceeded ? 'text-red-600' : status.monthly_spend > status.monthly_limit * 0.8 ? 'text-yellow-600' : 'text-green-600'}`;
        
        // Update cost section inputs
        const dailyInput = document.getElementById('cost-daily-limit');
        const monthlyInput = document.getElementById('cost-monthly-limit');
        if (dailyInput) dailyInput.value = status.daily_limit;
        if (monthlyInput) monthlyInput.value = status.monthly_limit;
        
        // Load history
        if (data.history) {
            document.getElementById('cost-history').innerHTML = data.history.length > 0 ?
                data.history.map(h => `
                    <div class="flex items-center justify-between bg-gray-50 rounded p-2 text-sm">
                        <span>${h.date}</span>
                        <span class="font-medium">$${h.total_cost.toFixed(2)}</span>
                        <span class="text-gray-500">${h.total_calls} calls</span>
                    </div>
                `).join('') :
                '<p class="text-gray-500 text-sm">No cost history yet</p>';
        }
    } catch (err) {
        console.error('Cost status load failed', err);
    }
}

async function loadScanHistory() {
    try {
        const data = await api('/scan/history');
        
        if (data.success && data.history.length > 0) {
            document.getElementById('scan-history').innerHTML = data.history.slice(0, 10).map(h => `
                <div class="flex items-center justify-between bg-gray-50 rounded p-2 text-sm">
                    <div>
                        <span class="font-medium">${h.city} - ${h.business_type}</span>
                        <div class="text-xs text-gray-500">${h.timestamp}</div>
                    </div>
                    <div class="text-right">
                        <div class="${h.status === 'completed' ? 'text-green-600' : 'text-red-600'}">${h.status}</div>
                        <div class="text-xs text-gray-500">${h.results_count} results • $${(h.estimated_cost_usd || 0).toFixed(2)}</div>
                    </div>
                </div>
            `).join('');
        } else {
            document.getElementById('scan-history').innerHTML = '<p class="text-gray-500 text-sm">No scans yet</p>';
        }
    } catch (err) {
        console.error('Scan history load failed', err);
    }
}

function updateScanEstimate() {
    const maxResults = parseInt(document.getElementById('scan-max').value) || 20;
    // Estimate: 1 search call + details for each result
    const searchCost = 0.032;
    const detailsCost = 0.017 * maxResults;
    const total = searchCost + detailsCost;
    
    document.getElementById('scan-estimate').textContent = '$' + total.toFixed(2);
}

async function runLeadScan() {
    const city = document.getElementById('scan-city').value;
    const type = document.getElementById('scan-type').value;
    const max = parseInt(document.getElementById('scan-max').value) || 20;
    const confirmCode = document.getElementById('scan-confirm-code').value;
    
    if (!city || !type) {
        showToast('Select city and business type', 'error');
        return;
    }
    
    if (!confirmCode) {
        showToast('Enter admin confirmation code', 'error');
        document.getElementById('scan-confirm-code').focus();
        return;
    }
    
    try {
        const result = await api('/scan/businesses', {
            method: 'POST',
            body: JSON.stringify({
                city: city,
                business_type: type,
                max_results: max,
                confirm_code: confirmCode
            })
        });
        
        if (result.success) {
            showToast(`Scan initiated! Estimated cost: $${result.estimated_cost}`);
            document.getElementById('scan-confirm-code').value = '';  // Clear code
            loadScanHistory();
            loadCostStatus();
        } else {
            showToast(result.error || 'Scan failed', 'error');
        }
    } catch (err) {
        showToast('Scan failed - check admin code and access', 'error');
    }
}

async function saveCostLimits() {
    const daily = parseFloat(document.getElementById('cost-daily-limit').value) || 50;
    const monthly = parseFloat(document.getElementById('cost-monthly-limit').value) || 500;
    
    try {
        await api('/costs/limits', {
            method: 'PUT',
            body: JSON.stringify({
                daily_limit_usd: daily,
                monthly_limit_usd: monthly
            })
        });
        showToast('Cost limits saved');
        loadCostStatus();
    } catch (err) {
        showToast('Failed to save limits', 'error');
    }
}

// ============ SCAN CODE MANAGEMENT ============
function toggleScanCodeVisibility() {
    const input = document.getElementById('scan-code-display');
    if (input) {
        input.type = input.type === 'password' ? 'text' : 'password';
    }
}

async function updateScanCode() {
    const newCode = document.getElementById('new-scan-code').value.trim();
    
    if (!newCode || newCode.length < 4) {
        showToast('Code must be at least 4 characters', 'error');
        return;
    }
    
    if (!confirm(`Change scan confirmation code to "${newCode}"?\n\nThis will immediately affect all scan operations.`)) {
        return;
    }
    
    try {
        await api('/settings', {
            method: 'PUT',
            body: JSON.stringify({ scan_confirm_code: newCode })
        });
        
        document.getElementById('scan-code-display').value = newCode;
        document.getElementById('new-scan-code').value = '';
        showToast('Scan confirmation code updated!');
    } catch (err) {
        showToast('Failed to update code', 'error');
    }
}

async function loadScanCode() {
    try {
        const settings = await api('/settings');
        const code = settings.scan_confirm_code || 'SCAN2024';
        const display = document.getElementById('scan-code-display');
        if (display) {
            display.value = code;
        }
    } catch (err) {
        console.error('Failed to load scan code');
    }
}

// ============ UTILS ============
function closeModal(id) {
    document.getElementById(id).classList.add('hidden');
}

function showToast(message, type = 'success') {
    const colors = {
        success: 'bg-green-600',
        error: 'bg-red-600',
        info: 'bg-blue-600'
    };
    
    const toast = document.createElement('div');
    toast.className = `toast px-4 py-3 rounded-lg shadow-lg text-white ${colors[type] || colors.success}`;
    toast.textContent = message;
    
    document.getElementById('toast-container').appendChild(toast);
    
    setTimeout(() => toast.remove(), 4000);
}
