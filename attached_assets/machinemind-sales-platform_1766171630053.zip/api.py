"""
MACHINEMIND SALES PLATFORM - API Server
========================================
REST API with authentication, role-based access, real-time sync,
monitoring, and comprehensive error handling.
"""

from flask import Flask, request, jsonify, g
from functools import wraps
import json
import time
import traceback
from datetime import datetime

from database import (
    db, user_manager, prospect_manager, settings_manager, analytics_manager,
    monitoring_manager, onboarding_manager, sync_manager,
    cost_manager, lead_scanner,
    Permission, UserRole, generate_id, ADMIN_ONLY_PERMISSIONS
)


app = Flask(__name__)
app.config['SECRET_KEY'] = 'change-this-in-production-use-env-var'


# ============ REQUEST LOGGING MIDDLEWARE ============

@app.before_request
def before_request():
    """Log request start time"""
    g.start_time = time.time()
    g.user = None


@app.after_request
def after_request(response):
    """Log API request for monitoring"""
    try:
        # Calculate response time
        response_time = int((time.time() - g.start_time) * 1000)
        
        # Get user ID if authenticated
        user_id = g.user['id'] if hasattr(g, 'user') and g.user else None
        
        # Log the request
        if request.path.startswith('/api/'):
            monitoring_manager.log_api_request(
                user_id=user_id,
                method=request.method,
                endpoint=request.path,
                status_code=response.status_code,
                response_time_ms=response_time,
                ip_address=request.remote_addr,
                user_agent=request.headers.get('User-Agent', '')[:200],
                error_message=None if response.status_code < 400 else response.get_data(as_text=True)[:500]
            )
    except Exception as e:
        print(f"Error logging request: {e}")
    
    return response


# ============ ERROR HANDLERS ============

@app.errorhandler(Exception)
def handle_exception(e):
    """Global exception handler with logging"""
    # Log the error
    user_id = g.user['id'] if hasattr(g, 'user') and g.user else None
    
    try:
        monitoring_manager.log_error(
            user_id=user_id,
            error_type=type(e).__name__,
            error_message=str(e),
            stack_trace=traceback.format_exc(),
            endpoint=request.path,
            request_data=json.dumps(request.get_json(silent=True) or {})[:1000]
        )
    except:
        pass
    
    # Return appropriate response
    if hasattr(e, 'code'):
        return jsonify({'error': str(e), 'type': type(e).__name__}), e.code
    return jsonify({'error': 'Internal server error', 'type': type(e).__name__}), 500


# ============ MIDDLEWARE ============

def get_current_user():
    """Get current user from session token"""
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    if not token:
        return None
    return user_manager.validate_session(token)


def require_auth(f):
    """Require authentication"""
    @wraps(f)
    def decorated(*args, **kwargs):
        user = get_current_user()
        if not user:
            return jsonify({'error': 'Unauthorized'}), 401
        g.user = user
        return f(*args, **kwargs)
    return decorated


def require_permission(permission: str):
    """Require specific permission"""
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            user = get_current_user()
            if not user:
                return jsonify({'error': 'Unauthorized'}), 401
            if permission not in user.get('permissions', []):
                return jsonify({'error': 'Forbidden - insufficient permissions'}), 403
            g.user = user
            return f(*args, **kwargs)
        return decorated
    return decorator


def require_admin(f):
    """Require admin role"""
    @wraps(f)
    def decorated(*args, **kwargs):
        user = get_current_user()
        if not user:
            return jsonify({'error': 'Unauthorized'}), 401
        if user.get('role') != 'admin':
            return jsonify({'error': 'Admin access required'}), 403
        g.user = user
        return f(*args, **kwargs)
    return decorated


# ============ AUTH ENDPOINTS ============

@app.route('/api/auth/login', methods=['POST'])
def login():
    """Login and get session token"""
    data = request.json
    email = data.get('email', '').strip()
    password = data.get('password', '')
    
    if not email or not password:
        return jsonify({'error': 'Email and password required'}), 400
    
    result = user_manager.authenticate(
        email, 
        password,
        ip=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    
    if result['success']:
        return jsonify(result)
    else:
        return jsonify(result), 401


@app.route('/api/auth/logout', methods=['POST'])
@require_auth
def logout():
    """Logout and invalidate session"""
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    user_manager.logout(token)
    return jsonify({'success': True})


@app.route('/api/auth/me', methods=['GET'])
@require_auth
def get_me():
    """Get current user info"""
    return jsonify({'user': g.user})


@app.route('/api/auth/change-password', methods=['POST'])
@require_auth
def change_password():
    """Change own password"""
    data = request.json
    # Implementation here
    return jsonify({'success': True})


# ============ USER MANAGEMENT (ADMIN) ============

@app.route('/api/users', methods=['GET'])
@require_admin
def list_users():
    """List all users"""
    users = user_manager.get_all_users()
    # Parse permissions JSON
    for user in users:
        user['permissions'] = json.loads(user.get('permissions', '[]'))
    return jsonify({'users': users})


@app.route('/api/users', methods=['POST'])
@require_admin
def create_user():
    """Create new user"""
    data = request.json
    
    required = ['email', 'password', 'name']
    if not all(k in data for k in required):
        return jsonify({'error': 'Missing required fields: email, password, name'}), 400
    
    result = user_manager.create_user(
        email=data['email'],
        password=data['password'],
        name=data['name'],
        role=data.get('role', 'rep'),
        created_by=g.user['id']
    )
    
    if result['success']:
        # Initialize onboarding for new user
        onboarding_manager.init_onboarding(result['user_id'])
        return jsonify(result), 201
    else:
        return jsonify(result), 400


@app.route('/api/users/<user_id>/permissions', methods=['PUT'])
@require_admin
def update_user_permissions(user_id):
    """Update user permissions - ENFORCES ADMIN-ONLY RESTRICTIONS"""
    data = request.json
    permissions = data.get('permissions', [])
    
    # The user_manager.update_user_permissions will automatically strip
    # admin-only permissions from non-admin users
    result = user_manager.update_user_permissions(user_id, permissions, g.user['id'])
    
    if result.get('success'):
        # Check if any permissions were stripped
        original_count = len(permissions)
        final_count = len(result.get('permissions', []))
        
        if final_count < original_count:
            return jsonify({
                'success': True,
                'warning': f'{original_count - final_count} admin-only permissions were removed',
                'final_permissions': result['permissions'],
                'admin_only_blocked': ADMIN_ONLY_PERMISSIONS
            })
        
        return jsonify({'success': True, 'permissions': result['permissions']})
    else:
        return jsonify(result), 400


@app.route('/api/users/<user_id>/toggle', methods=['POST'])
@require_admin
def toggle_user(user_id):
    """Enable/disable user"""
    data = request.json
    is_active = data.get('is_active', True)
    
    user_manager.toggle_user_active(user_id, is_active, g.user['id'])
    return jsonify({'success': True})


@app.route('/api/permissions', methods=['GET'])
@require_admin
def list_permissions():
    """List all available permissions with admin-only flags"""
    return jsonify({
        'permissions': [p.value for p in Permission],
        'admin_only': ADMIN_ONLY_PERMISSIONS,
        'description': {
            'scan_leads': 'Scan for new businesses (Google Places API - $0.03/call)',
            'enrich_leads': 'AI enrichment of prospects (OpenAI/Claude - $0.02/call)',
            'bulk_import': 'Bulk import from external sources',
            'run_automations': 'Run automated batch operations'
        },
        'roles': {
            'admin': [p.value for p in Permission],
            'manager': [
                Permission.VIEW_PROSPECTS.value,
                Permission.CREATE_PROSPECTS.value,
                Permission.EDIT_PROSPECTS.value,
                Permission.EXPORT_PROSPECTS.value,
                Permission.LOG_CALLS.value,
                Permission.VIEW_ALL_CALLS.value,
                Permission.VIEW_STRATEGY.value,
                Permission.VIEW_SCRIPTS.value,
                Permission.VIEW_ANALYTICS.value,
            ],
            'rep': [
                Permission.VIEW_PROSPECTS.value,
                Permission.CREATE_PROSPECTS.value,
                Permission.EDIT_PROSPECTS.value,
                Permission.LOG_CALLS.value,
                Permission.VIEW_STRATEGY.value,
                Permission.VIEW_SCRIPTS.value,
            ]
        },
        'warning': 'Permissions in admin_only list can NEVER be assigned to non-admin users'
    })


# ============ PROSPECTS ============

@app.route('/api/prospects', methods=['GET'])
@require_permission(Permission.VIEW_PROSPECTS.value)
def list_prospects():
    """List prospects (filtered by role)"""
    filters = {
        'deal_stage': request.args.get('stage'),
        'assigned_to': request.args.get('assigned_to'),
        'city': request.args.get('city'),
        'min_score': request.args.get('min_score', type=int)
    }
    # Remove None values
    filters = {k: v for k, v in filters.items() if v is not None}
    
    prospects = prospect_manager.get_prospects(
        user_id=g.user['id'],
        user_role=g.user['role'],
        filters=filters
    )
    
    return jsonify({'prospects': prospects, 'count': len(prospects)})


@app.route('/api/prospects', methods=['POST'])
@require_permission(Permission.CREATE_PROSPECTS.value)
def create_prospect():
    """Create new prospect"""
    data = request.json
    
    if not data.get('business_name'):
        return jsonify({'error': 'Business name required'}), 400
    
    # Default assignment to creator if not specified
    if not data.get('assigned_to'):
        data['assigned_to'] = g.user['id']
    
    result = prospect_manager.create_prospect(data, g.user['id'])
    
    if result['success']:
        # Mark onboarding step complete
        onboarding_manager.complete_step(g.user['id'], 'first_prospect')
        return jsonify(result), 201
    else:
        return jsonify(result), 400


@app.route('/api/prospects/<prospect_id>', methods=['GET'])
@require_permission(Permission.VIEW_PROSPECTS.value)
def get_prospect(prospect_id):
    """Get single prospect"""
    prospect = prospect_manager.get_prospect(prospect_id)
    
    if not prospect:
        return jsonify({'error': 'Prospect not found'}), 404
    
    # Check access for reps
    if g.user['role'] == 'rep' and prospect.get('assigned_to') != g.user['id']:
        return jsonify({'error': 'Access denied'}), 403
    
    return jsonify({'prospect': prospect})


@app.route('/api/prospects/<prospect_id>', methods=['PUT'])
@require_permission(Permission.EDIT_PROSPECTS.value)
def update_prospect(prospect_id):
    """Update prospect"""
    prospect = prospect_manager.get_prospect(prospect_id)
    
    if not prospect:
        return jsonify({'error': 'Prospect not found'}), 404
    
    # Check access for reps
    if g.user['role'] == 'rep' and prospect.get('assigned_to') != g.user['id']:
        return jsonify({'error': 'Access denied'}), 403
    
    data = request.json
    result = prospect_manager.update_prospect(prospect_id, data, g.user['id'])
    
    return jsonify(result)


@app.route('/api/prospects/<prospect_id>/calls', methods=['GET'])
@require_permission(Permission.VIEW_PROSPECTS.value)
def get_prospect_calls(prospect_id):
    """Get call history for a prospect"""
    calls = prospect_manager.get_prospect_calls(prospect_id)
    return jsonify({'calls': calls})


@app.route('/api/prospects/<prospect_id>/calls', methods=['POST'])
@require_permission(Permission.LOG_CALLS.value)
def log_call(prospect_id):
    """Log a call for a prospect"""
    data = request.json
    
    result = prospect_manager.log_call(prospect_id, g.user['id'], data)
    
    if result['success']:
        # Mark onboarding step complete
        onboarding_manager.complete_step(g.user['id'], 'first_call')
        return jsonify(result), 201
    else:
        return jsonify(result), 400


@app.route('/api/prospects/follow-ups', methods=['GET'])
@require_permission(Permission.VIEW_PROSPECTS.value)
def get_follow_ups():
    """Get prospects with upcoming follow-ups"""
    days = request.args.get('days', 3, type=int)
    
    with db.get_connection() as conn:
        cursor = conn.cursor()
        
        query = """
            SELECT * FROM prospects 
            WHERE follow_up_date <= date('now', '+{} days')
            AND deal_stage NOT IN ('won', 'lost')
        """.format(days)
        
        if g.user['role'] == 'rep':
            query += " AND assigned_to = ?"
            cursor.execute(query + " ORDER BY follow_up_date ASC", (g.user['id'],))
        else:
            cursor.execute(query + " ORDER BY follow_up_date ASC")
        
        prospects = []
        for row in cursor.fetchall():
            p = dict(row)
            p['pain_points'] = json.loads(p['pain_points'] or '[]')
            p['objections'] = json.loads(p['objections'] or '[]')
            prospects.append(p)
        
        return jsonify({'prospects': prospects})


# ============ SCRIPTS ============

@app.route('/api/scripts', methods=['GET'])
@require_permission(Permission.VIEW_SCRIPTS.value)
def list_scripts():
    """List sales scripts"""
    category = request.args.get('category')
    scripts = settings_manager.get_scripts(category)
    
    # Mark onboarding step complete
    onboarding_manager.complete_step(g.user['id'], 'scripts')
    
    return jsonify({'scripts': scripts})


@app.route('/api/scripts', methods=['POST'])
@require_admin
def create_script():
    """Create new script (admin only) - broadcasts to all users"""
    data = request.json
    
    with db.get_connection() as conn:
        cursor = conn.cursor()
        script_id = generate_id('script')
        cursor.execute("""
            INSERT INTO scripts (id, name, category, content, created_by)
            VALUES (?, ?, ?, ?, ?)
        """, (script_id, data['name'], data.get('category'), data['content'], g.user['id']))
    
    # Broadcast the change
    sync_manager.broadcast_script_update(script_id, 'create', g.user['id'], data)
        
    return jsonify({'success': True, 'script_id': script_id}), 201


@app.route('/api/scripts/<script_id>', methods=['PUT'])
@require_admin
def update_script(script_id):
    """Update script (admin only) - broadcasts to all users"""
    data = request.json
    
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE scripts SET name = ?, category = ?, content = ?, updated_at = ?
            WHERE id = ?
        """, (data['name'], data.get('category'), data['content'], 
              datetime.utcnow().isoformat(), script_id))
    
    # Broadcast the change
    sync_manager.broadcast_script_update(script_id, 'update', g.user['id'], data)
    
    return jsonify({'success': True})


@app.route('/api/scripts/<script_id>', methods=['DELETE'])
@require_admin
def delete_script(script_id):
    """Delete script (admin only)"""
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE scripts SET is_active = 0 WHERE id = ?", (script_id,))
    
    # Broadcast the change
    sync_manager.broadcast_script_update(script_id, 'delete', g.user['id'])
    
    return jsonify({'success': True})


# ============ SETTINGS ============

@app.route('/api/settings', methods=['GET'])
@require_auth
def get_settings():
    """Get system settings"""
    settings = settings_manager.get_all_settings()
    
    # Parse JSON values
    json_keys = ['deal_stages', 'business_types', 'cities']
    for key in json_keys:
        if key in settings:
            try:
                settings[key] = json.loads(settings[key])
            except:
                pass
    
    return jsonify({'settings': settings})


@app.route('/api/settings', methods=['PUT'])
@require_admin
def update_settings():
    """Update system settings (admin only) - broadcasts to all users"""
    data = request.json
    
    for key, value in data.items():
        # Convert lists/dicts to JSON
        if isinstance(value, (list, dict)):
            value = json.dumps(value)
        settings_manager.set_setting(key, str(value), g.user['id'])
        
        # Broadcast the change for real-time sync
        sync_manager.broadcast_settings_update(key, value, g.user['id'])
    
    return jsonify({'success': True})


# ============ ANALYTICS ============

@app.route('/api/analytics/dashboard', methods=['GET'])
@require_permission(Permission.VIEW_ANALYTICS.value)
def get_dashboard():
    """Get dashboard analytics"""
    days = request.args.get('days', 30, type=int)
    
    # Admins/managers see all, reps see own
    user_id = None if g.user['role'] in ['admin', 'manager'] else g.user['id']
    
    stats = analytics_manager.get_dashboard_stats(user_id, days)
    return jsonify({'stats': stats})


@app.route('/api/analytics/leaderboard', methods=['GET'])
@require_permission(Permission.VIEW_ANALYTICS.value)
def get_leaderboard():
    """Get rep leaderboard"""
    days = request.args.get('days', 30, type=int)
    leaderboard = analytics_manager.get_rep_leaderboard(days)
    return jsonify({'leaderboard': leaderboard})


# ============ MONITORING ENDPOINTS (ADMIN) ============

@app.route('/api/monitoring/stats', methods=['GET'])
@require_admin
def get_monitoring_stats():
    """Get API usage statistics"""
    hours = request.args.get('hours', 24, type=int)
    stats = monitoring_manager.get_api_stats(hours)
    return jsonify({'stats': stats})


@app.route('/api/monitoring/health', methods=['GET'])
def get_system_health():
    """Get system health (public endpoint for uptime monitoring)"""
    health = monitoring_manager.get_system_health()
    return jsonify(health)


@app.route('/api/monitoring/errors', methods=['GET'])
@require_admin
def get_recent_errors():
    """Get recent errors"""
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM error_logs 
            ORDER BY timestamp DESC 
            LIMIT 50
        """)
        errors = [dict(row) for row in cursor.fetchall()]
    return jsonify({'errors': errors})


# ============ ONBOARDING ENDPOINTS ============

@app.route('/api/onboarding/progress', methods=['GET'])
@require_auth
def get_onboarding_progress():
    """Get user's onboarding progress"""
    progress = onboarding_manager.get_progress(g.user['id'])
    return jsonify({'progress': progress})


@app.route('/api/onboarding/complete-step', methods=['POST'])
@require_auth
def complete_onboarding_step():
    """Mark an onboarding step as complete"""
    data = request.json
    step_name = data.get('step')
    
    if not step_name:
        return jsonify({'error': 'Step name required'}), 400
    
    onboarding_manager.complete_step(g.user['id'], step_name)
    return jsonify({'success': True})


@app.route('/api/onboarding/skip', methods=['POST'])
@require_auth
def skip_onboarding():
    """Skip remaining onboarding"""
    onboarding_manager.skip_onboarding(g.user['id'])
    return jsonify({'success': True})


# ============ SYNC ENDPOINTS ============

@app.route('/api/sync/changes', methods=['GET'])
@require_auth
def get_sync_changes():
    """Get changes since last sync (for real-time updates)"""
    since = request.args.get('since')
    
    if not since:
        # Return current timestamp for initial sync
        return jsonify({
            'changes': [],
            'timestamp': datetime.utcnow().isoformat()
        })
    
    # Get settings and scripts changes (stuff admin can update)
    changes = sync_manager.get_changes_since(since, ['settings', 'script'])
    
    return jsonify({
        'changes': changes,
        'timestamp': datetime.utcnow().isoformat()
    })


@app.route('/api/sync/full', methods=['GET'])
@require_auth
def get_full_sync():
    """Get full data for initial sync"""
    data = {
        'settings': settings_manager.get_all_settings(),
        'scripts': settings_manager.get_scripts(),
        'timestamp': datetime.utcnow().isoformat()
    }
    
    # Parse JSON settings
    json_keys = ['deal_stages', 'business_types', 'cities']
    for key in json_keys:
        if key in data['settings']:
            try:
                data['settings'][key] = json.loads(data['settings'][key])
            except:
                pass
    
    return jsonify(data)


# ============ GRANULAR PERMISSION CHECK ============

@app.route('/api/permissions/check', methods=['POST'])
@require_auth
def check_permissions():
    """Check if user has specific permissions"""
    data = request.json
    permissions_to_check = data.get('permissions', [])
    
    user_permissions = g.user.get('permissions', [])
    
    results = {p: p in user_permissions for p in permissions_to_check}
    
    return jsonify({
        'results': results,
        'role': g.user.get('role'),
        'all_permissions': user_permissions
    })


# ============ USER PROFILE ============

@app.route('/api/profile', methods=['GET'])
@require_auth
def get_profile():
    """Get current user's profile"""
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, email, name, role, permissions, settings, created_at, last_login
            FROM users WHERE id = ?
        """, (g.user['id'],))
        user = dict(cursor.fetchone())
        user['permissions'] = json.loads(user['permissions'] or '[]')
        user['settings'] = json.loads(user['settings'] or '{}')
    
    return jsonify({'user': user})


@app.route('/api/profile', methods=['PUT'])
@require_auth
def update_profile():
    """Update current user's profile"""
    data = request.json
    
    allowed_fields = ['name', 'settings']
    updates = {k: v for k, v in data.items() if k in allowed_fields}
    
    if 'settings' in updates:
        updates['settings'] = json.dumps(updates['settings'])
    
    if updates:
        with db.get_connection() as conn:
            cursor = conn.cursor()
            set_clause = ', '.join([f"{k} = ?" for k in updates.keys()])
            cursor.execute(f"""
                UPDATE users SET {set_clause}, updated_at = ? WHERE id = ?
            """, (*updates.values(), datetime.utcnow().isoformat(), g.user['id']))
        
        # Mark profile step complete
        onboarding_manager.complete_step(g.user['id'], 'profile')
    
    return jsonify({'success': True})


# ============ COST TRACKING & LIMITS (ADMIN ONLY) ============

@app.route('/api/costs/status', methods=['GET'])
@require_admin
def get_cost_status():
    """Get current cost status and limits - ADMIN ONLY"""
    status = cost_manager.check_limits()
    history = cost_manager.get_cost_history(30)
    
    return jsonify({
        'status': status,
        'history': history
    })


@app.route('/api/costs/limits', methods=['PUT'])
@require_admin
def update_cost_limits():
    """Update cost limits - ADMIN ONLY"""
    data = request.json
    
    daily = data.get('daily_limit_usd', 50.0)
    monthly = data.get('monthly_limit_usd', 500.0)
    
    cost_manager.set_limits(daily, monthly, g.user['id'])
    
    return jsonify({
        'success': True,
        'limits': {'daily': daily, 'monthly': monthly}
    })


# ============ LEAD SCANNING (ADMIN ONLY - HARD ENFORCED) ============

@app.route('/api/scan/businesses', methods=['POST'])
@require_admin  # First layer of protection
def scan_businesses():
    """
    Scan for new businesses using Google Places API
    
    ADMIN ONLY - This is expensive ($0.017-0.032 per call)
    Hard enforced at multiple levels + confirmation code required
    """
    # Double-check admin status (belt and suspenders)
    if g.user.get('role') != 'admin':
        return jsonify({
            'error': 'ACCESS DENIED: Only administrators can scan for new leads',
            'reason': 'This operation uses expensive APIs (Google Places)',
            'action': 'Contact your administrator to run lead scans'
        }), 403
    
    data = request.json
    confirm_code = data.get('confirm_code', '')
    
    # VERIFY CONFIRMATION CODE
    # Default code is "SCAN2024" - can be changed in settings
    settings = settings_manager.get_settings()
    expected_code = settings.get('scan_confirm_code', 'SCAN2024')
    
    if not confirm_code:
        return jsonify({
            'error': 'Admin confirmation code required',
            'reason': 'Scans cost real money - confirmation prevents accidental charges',
            'action': 'Enter your admin scan confirmation code'
        }), 400
    
    if confirm_code != expected_code:
        return jsonify({
            'error': 'Invalid confirmation code',
            'reason': 'The confirmation code you entered is incorrect',
            'action': 'Contact system administrator for the correct code'
        }), 403
    
    city = data.get('city')
    business_type = data.get('business_type')
    max_results = min(data.get('max_results', 20), 100)  # Cap at 100
    
    if not city or not business_type:
        return jsonify({'error': 'City and business_type required'}), 400
    
    result = lead_scanner.scan_businesses(g.user['id'], city, business_type, max_results)
    
    if result['success']:
        return jsonify(result)
    else:
        return jsonify(result), 403 if 'ACCESS DENIED' in result.get('error', '') else 400


@app.route('/api/scan/enrich/<prospect_id>', methods=['POST'])
@require_admin
def enrich_prospect(prospect_id):
    """
    Enrich a prospect with AI analysis
    
    ADMIN ONLY - Uses AI APIs which cost money
    """
    if g.user.get('role') != 'admin':
        return jsonify({
            'error': 'ACCESS DENIED: Only administrators can enrich leads with AI',
            'reason': 'This operation uses AI APIs (costs money per call)'
        }), 403
    
    result = lead_scanner.enrich_prospect(g.user['id'], prospect_id)
    
    if result['success']:
        return jsonify(result)
    else:
        return jsonify(result), 403 if 'ACCESS DENIED' in result.get('error', '') else 400


@app.route('/api/scan/bulk-import', methods=['POST'])
@require_admin
def bulk_import():
    """
    Bulk import prospects
    
    ADMIN ONLY
    """
    if g.user.get('role') != 'admin':
        return jsonify({
            'error': 'ACCESS DENIED: Only administrators can bulk import'
        }), 403
    
    data = request.json
    prospects = data.get('prospects', [])
    
    result = lead_scanner.bulk_import(g.user['id'], prospects)
    
    if result['success']:
        return jsonify(result)
    else:
        return jsonify(result), 403


@app.route('/api/scan/history', methods=['GET'])
@require_admin
def get_scan_history():
    """Get scan history - ADMIN ONLY"""
    result = lead_scanner.get_scan_history(g.user['id'])
    return jsonify(result)


# ============ PERMISSIONS INFO ENDPOINT ============

@app.route('/api/permissions/info', methods=['GET'])
@require_auth
def get_permissions_info():
    """Get information about permissions including which are admin-only"""
    return jsonify({
        'user_permissions': g.user.get('permissions', []),
        'user_role': g.user.get('role'),
        'admin_only_permissions': ADMIN_ONLY_PERMISSIONS,
        'can_scan_leads': g.user.get('role') == 'admin',
        'can_enrich_leads': g.user.get('role') == 'admin',
        'can_bulk_import': g.user.get('role') == 'admin',
        'message': 'Lead scanning and enrichment are restricted to administrators due to API costs'
    })


# ============ STRATEGY ENGINE ============

@app.route('/api/strategy/<prospect_id>', methods=['GET'])
@require_permission(Permission.VIEW_STRATEGY.value)
def get_strategy(prospect_id):
    """Get closing strategy for prospect"""
    prospect = prospect_manager.get_prospect(prospect_id)
    
    if not prospect:
        return jsonify({'error': 'Prospect not found'}), 404
    
    strategy = generate_closing_strategy(prospect)
    return jsonify({'strategy': strategy})


def generate_closing_strategy(prospect: dict) -> dict:
    """Generate personalized closing strategy"""
    buyer_type = prospect.get('buyer_type')
    
    strategies = {
        'analytical': {
            'approach': 'Lead with DATA and ROI',
            'do': [
                'Share specific numbers and metrics',
                'Provide case studies with results',
                'Give them time to analyze'
            ],
            'avoid': ['Emotional appeals', 'Pressure tactics', 'Vague claims'],
            'closing_question': 'Based on the numbers, what would you need to see to move forward?'
        },
        'driver': {
            'approach': 'Be DIRECT, respect their time',
            'do': [
                'Get to results quickly',
                'Give them control and options',
                'Focus on competitive advantage'
            ],
            'avoid': ['Long explanations', 'Too much detail', 'Being passive'],
            'closing_question': "Ready to get started, or what's holding you back?"
        },
        'expressive': {
            'approach': 'Sell the VISION',
            'do': [
                'Paint the picture of success',
                'Share exciting possibilities',
                'Build the relationship'
            ],
            'avoid': ['Too many details', 'Being impersonal', 'Killing the energy'],
            'closing_question': 'Can you see this working for you? What excites you most?'
        },
        'amiable': {
            'approach': 'Build TRUST first',
            'do': [
                'Reduce perceived risk',
                'Offer guarantees and support',
                "Don't pressure"
            ],
            'avoid': ['Rushing', 'Pressure tactics', 'Dismissing concerns'],
            'closing_question': 'What would help you feel confident about this decision?'
        }
    }
    
    base_strategy = strategies.get(buyer_type, {
        'approach': 'Identify buyer type first',
        'do': ['Ask discovery questions', 'Listen for communication style'],
        'avoid': [],
        'closing_question': 'What would be most helpful for you at this point?'
    })
    
    # Add objection handling
    unaddressed = [o for o in prospect.get('objections', []) if not o.get('addressed')]
    if unaddressed:
        base_strategy['must_address'] = [o.get('type') for o in unaddressed]
    
    # Score-based recommendation
    score = prospect.get('deal_score', 50)
    if score >= 70:
        base_strategy['recommendation'] = '🔥 HOT - Push for close this call'
    elif score >= 50:
        base_strategy['recommendation'] = '👍 WARM - Address concerns, book follow-up'
    elif score >= 30:
        base_strategy['recommendation'] = '🤔 LUKEWARM - Find more pain, qualify harder'
    else:
        base_strategy['recommendation'] = '❄️ COLD - Nurture or disqualify'
    
    base_strategy['deal_score'] = score
    
    return base_strategy


# ============ SPECIFIC ERROR HANDLERS ============

@app.errorhandler(400)
def bad_request(e):
    return jsonify({'error': 'Bad request', 'message': str(e.description)}), 400


@app.errorhandler(401)
def unauthorized(e):
    return jsonify({'error': 'Unauthorized', 'message': 'Please login to access this resource'}), 401


@app.errorhandler(403)
def forbidden(e):
    return jsonify({'error': 'Forbidden', 'message': 'You do not have permission to access this resource'}), 403


@app.errorhandler(404)
def not_found(e):
    return jsonify({'error': 'Not found', 'message': 'The requested resource was not found'}), 404


@app.errorhandler(500)
def server_error(e):
    return jsonify({'error': 'Internal server error', 'message': 'Something went wrong on our end'}), 500


# ============ HEALTH CHECK ============

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '1.0.0'
    })


# ============ CORS ============

@app.after_request
def add_cors_headers(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
    return response


@app.route('/api/<path:path>', methods=['OPTIONS'])
def handle_options(path):
    return '', 200


# ============ STATIC FILE SERVING ============

from flask import send_from_directory
import os

@app.route('/')
def serve_index():
    """Serve the main application"""
    return send_from_directory('.', 'index.html')

@app.route('/app.js')
def serve_js():
    """Serve the JavaScript"""
    return send_from_directory('.', 'app.js')

@app.route('/<path:filename>')
def serve_static(filename):
    """Serve other static files"""
    if os.path.exists(filename):
        return send_from_directory('.', filename)
    return jsonify({'error': 'Not found'}), 404


if __name__ == '__main__':
    print("Starting MachineMind Sales Platform API...")
    
    # Auto-create default users if they don't exist
    try:
        existing = user_manager.get_all_users()
        if len(existing) <= 1:  # Only system user exists
            print("\nInitializing default users...")
            r = user_manager.create_user('admin@machinemind.co', 'admin123', 'Admin', 'admin')
            if r.get('success'):
                print(f"  ✓ Created admin: admin@machinemind.co / admin123")
                settings_manager.update_settings(r['user_id'], {'scan_confirm_code': 'SCAN2024'})
                print(f"  ✓ Scan confirmation code set: SCAN2024")
            
            r = user_manager.create_user('sergio@machinemind.co', 'sergio123', 'Sergio', 'manager')
            if r.get('success'):
                print(f"  ✓ Created manager: sergio@machinemind.co / sergio123")
            
            r = user_manager.create_user('rep@machinemind.co', 'rep123', 'Sales Rep', 'rep')
            if r.get('success'):
                print(f"  ✓ Created rep: rep@machinemind.co / rep123")
            print("")
    except Exception as e:
        print(f"User init error (non-fatal): {e}")
    
    print("="*50)
    print("  MACHINEMIND SALES PLATFORM READY")
    print("="*50)
    print("\n  Login credentials:")
    print("  ├── Admin:   admin@machinemind.co / admin123")
    print("  ├── Manager: sergio@machinemind.co / sergio123")
    print("  └── Rep:     rep@machinemind.co / rep123")
    print("\n  Scan confirmation code: SCAN2024")
    print("  (Change in Admin > Costs)")
    print("\n")
    
    app.run(host='0.0.0.0', port=5000, debug=True)
