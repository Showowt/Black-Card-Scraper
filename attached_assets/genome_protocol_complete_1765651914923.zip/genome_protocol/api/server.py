"""
GENOME PROTOCOL™ - API Integration Layer
==========================================
REST API and webhook handlers for integrating Genome Protocol
with existing chatbot infrastructure and external systems.
"""

from flask import Flask, request, jsonify
from functools import wraps
from datetime import datetime
import json
import os
from typing import Dict, Optional

from ..core.models import GenomeProfile
from ..core.database import get_database
from ..core.engine import GenomeEngine
from ..flows.templates import FlowExecutor, get_flow, get_all_flows


def create_app(db_path: str = "genome_protocol.db") -> Flask:
    """Create and configure the Flask application"""
    app = Flask(__name__)
    
    # Initialize services
    db = get_database(db_path)
    engine = GenomeEngine(db)
    executor = FlowExecutor(engine)
    
    # Store in app context
    app.config['DB'] = db
    app.config['ENGINE'] = engine
    app.config['EXECUTOR'] = executor
    
    # API Key authentication
    def require_api_key(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            api_key = request.headers.get('X-API-Key')
            # In production, validate against stored keys
            if not api_key:
                return jsonify({"error": "API key required"}), 401
            return f(*args, **kwargs)
        return decorated
    
    # ==================== PROFILE ENDPOINTS ====================
    
    @app.route('/api/v1/profiles', methods=['POST'])
    @require_api_key
    def create_profile():
        """Create a new guest profile"""
        data = request.json
        
        required = ['property_id']
        if not all(k in data for k in required):
            return jsonify({"error": "property_id required"}), 400
        
        # Need at least one identifier
        identifiers = ['whatsapp', 'email', 'phone']
        if not any(k in data for k in identifiers):
            return jsonify({"error": "At least one identifier required"}), 400
        
        profile = db.create_profile(**data)
        
        return jsonify({
            "success": True,
            "genome_id": profile.genome_id,
            "profile": profile.to_dict()
        }), 201
    
    @app.route('/api/v1/profiles/<genome_id>', methods=['GET'])
    @require_api_key
    def get_profile(genome_id: str):
        """Get a profile by genome_id"""
        profile = db.get_profile(genome_id)
        
        if not profile:
            return jsonify({"error": "Profile not found"}), 404
        
        return jsonify({
            "success": True,
            "profile": profile.to_dict()
        })
    
    @app.route('/api/v1/profiles/lookup', methods=['POST'])
    @require_api_key
    def lookup_profile():
        """Find profile by identifier"""
        data = request.json
        
        if 'property_id' not in data or 'identifier' not in data:
            return jsonify({"error": "property_id and identifier required"}), 400
        
        profile = db.find_profile(data['property_id'], data['identifier'])
        
        if not profile:
            return jsonify({"error": "Profile not found"}), 404
        
        return jsonify({
            "success": True,
            "profile": profile.to_dict()
        })
    
    @app.route('/api/v1/profiles/<genome_id>/insights', methods=['GET'])
    @require_api_key
    def get_profile_insights(genome_id: str):
        """Get actionable insights for a profile"""
        profile = db.get_profile(genome_id)
        
        if not profile:
            return jsonify({"error": "Profile not found"}), 404
        
        return jsonify({
            "success": True,
            "genome_id": genome_id,
            "insights": profile.get_personalization_insights()
        })
    
    # ==================== MESSAGE PROCESSING ====================
    
    @app.route('/api/v1/messages/process', methods=['POST'])
    @require_api_key
    def process_message():
        """
        Process an incoming message and extract Genome signals.
        This is the main integration point for chatbots.
        """
        data = request.json
        
        required = ['property_id', 'guest_identifier', 'message']
        if not all(k in data for k in required):
            return jsonify({"error": f"Required fields: {required}"}), 400
        
        profile, result = engine.process_message(
            property_id=data['property_id'],
            guest_identifier=data['guest_identifier'],
            message=data['message'],
            channel=data.get('channel', 'whatsapp'),
            direction=data.get('direction', 'inbound'),
            response_time_seconds=data.get('response_time_seconds')
        )
        
        return jsonify({
            "success": True,
            "genome_id": profile.genome_id,
            "profile_completeness": profile.profile_completeness,
            "signals_captured": [s.to_dict() for s in result.signals],
            "inferred_intent": result.inferred_intent,
            "sentiment": result.sentiment,
            "suggested_responses": result.suggested_responses,
            "collection_opportunities": result.collection_opportunities
        })
    
    @app.route('/api/v1/messages/batch', methods=['POST'])
    @require_api_key
    def batch_process_messages():
        """Process multiple messages in batch"""
        data = request.json
        
        if 'messages' not in data or not isinstance(data['messages'], list):
            return jsonify({"error": "messages array required"}), 400
        
        results = []
        for msg in data['messages']:
            try:
                profile, result = engine.process_message(
                    property_id=msg['property_id'],
                    guest_identifier=msg['guest_identifier'],
                    message=msg['message'],
                    channel=msg.get('channel', 'whatsapp'),
                    direction=msg.get('direction', 'inbound')
                )
                results.append({
                    "success": True,
                    "genome_id": profile.genome_id,
                    "signals_captured": len(result.signals)
                })
            except Exception as e:
                results.append({
                    "success": False,
                    "error": str(e)
                })
        
        return jsonify({
            "success": True,
            "processed": len(results),
            "results": results
        })
    
    # ==================== CONVERSATION FLOWS ====================
    
    @app.route('/api/v1/flows', methods=['GET'])
    @require_api_key
    def list_flows():
        """List available conversation flows"""
        flows = get_all_flows()
        
        return jsonify({
            "success": True,
            "flows": [
                {
                    "id": f.flow_id,
                    "type": f.flow_type.value,
                    "name": f.name,
                    "description": f.description,
                    "steps_count": len(f.steps)
                }
                for f in flows.values()
            ]
        })
    
    @app.route('/api/v1/flows/start', methods=['POST'])
    @require_api_key
    def start_flow():
        """Start a conversation flow for a guest"""
        data = request.json
        
        required = ['flow_type', 'property_id', 'guest_identifier']
        if not all(k in data for k in required):
            return jsonify({"error": f"Required fields: {required}"}), 400
        
        result = executor.start_flow(
            flow_type=data['flow_type'],
            property_id=data['property_id'],
            guest_identifier=data['guest_identifier']
        )
        
        if 'error' in result:
            return jsonify(result), 400
        
        return jsonify({
            "success": True,
            **result
        })
    
    @app.route('/api/v1/flows/respond', methods=['POST'])
    @require_api_key
    def respond_to_flow():
        """Process a response within a conversation flow"""
        data = request.json
        
        required = ['session_id', 'response']
        if not all(k in data for k in required):
            return jsonify({"error": f"Required fields: {required}"}), 400
        
        result = executor.process_response(
            session_id=data['session_id'],
            user_response=data['response']
        )
        
        if 'error' in result:
            return jsonify(result), 400
        
        return jsonify({
            "success": True,
            **result
        })
    
    # ==================== PROPERTY/CLIENT MANAGEMENT ====================
    
    @app.route('/api/v1/properties', methods=['POST'])
    @require_api_key
    def create_property():
        """Register a new property (MachineMind client)"""
        data = request.json
        
        required = ['property_id', 'property_name', 'property_type']
        if not all(k in data for k in required):
            return jsonify({"error": f"Required fields: {required}"}), 400
        
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO properties 
                (property_id, property_name, property_type, city, country, tier, settings)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                data['property_id'],
                data['property_name'],
                data['property_type'],
                data.get('city'),
                data.get('country', 'Colombia'),
                data.get('tier', 'starter'),
                json.dumps(data.get('settings', {}))
            ))
        
        return jsonify({
            "success": True,
            "property_id": data['property_id']
        }), 201
    
    @app.route('/api/v1/properties/<property_id>/stats', methods=['GET'])
    @require_api_key
    def get_property_stats(property_id: str):
        """Get Genome statistics for a property"""
        stats = db.get_profile_stats(property_id)
        
        return jsonify({
            "success": True,
            "property_id": property_id,
            "stats": stats
        })
    
    @app.route('/api/v1/properties/<property_id>/profiles', methods=['GET'])
    @require_api_key
    def get_property_profiles(property_id: str):
        """Get all profiles for a property"""
        limit = request.args.get('limit', 100, type=int)
        min_completeness = request.args.get('min_completeness', 0.0, type=float)
        
        profiles = db.get_property_profiles(
            property_id, 
            limit=limit,
            min_completeness=min_completeness
        )
        
        return jsonify({
            "success": True,
            "property_id": property_id,
            "count": len(profiles),
            "profiles": [p.to_dict() for p in profiles]
        })
    
    @app.route('/api/v1/properties/<property_id>/vips', methods=['GET'])
    @require_api_key  
    def get_property_vips(property_id: str):
        """Get high-value VIP profiles for a property"""
        limit = request.args.get('limit', 20, type=int)
        
        profiles = db.get_high_value_profiles(property_id, limit=limit)
        
        return jsonify({
            "success": True,
            "property_id": property_id,
            "vip_count": len(profiles),
            "vips": [
                {
                    "profile": p.to_dict(),
                    "vip_status": p._get_vip_indicators()
                }
                for p in profiles
            ]
        })
    
    # ==================== WEBHOOKS ====================
    
    @app.route('/api/v1/webhooks/whatsapp', methods=['POST'])
    def whatsapp_webhook():
        """
        Webhook endpoint for WhatsApp Business API messages.
        Automatically processes incoming messages through Genome.
        """
        data = request.json
        
        # Handle WhatsApp webhook verification
        if request.args.get('hub.mode') == 'subscribe':
            verify_token = request.args.get('hub.verify_token')
            challenge = request.args.get('hub.challenge')
            # Verify token in production
            return challenge
        
        # Process incoming message
        try:
            # Parse WhatsApp message format
            entry = data.get('entry', [{}])[0]
            changes = entry.get('changes', [{}])[0]
            value = changes.get('value', {})
            messages = value.get('messages', [])
            
            for message in messages:
                if message.get('type') == 'text':
                    phone = message.get('from')
                    text = message.get('text', {}).get('body', '')
                    
                    # Get property_id from webhook config or message metadata
                    property_id = request.headers.get('X-Property-ID', 'default')
                    
                    # Process through Genome
                    profile, result = engine.process_message(
                        property_id=property_id,
                        guest_identifier=phone,
                        message=text,
                        channel='whatsapp',
                        direction='inbound'
                    )
            
            return jsonify({"success": True}), 200
            
        except Exception as e:
            app.logger.error(f"Webhook processing error: {e}")
            return jsonify({"error": str(e)}), 500
    
    # ==================== ANALYTICS ====================
    
    @app.route('/api/v1/analytics/signals', methods=['GET'])
    @require_api_key
    def get_signal_analytics():
        """Get signal capture analytics"""
        property_id = request.args.get('property_id')
        days = request.args.get('days', 30, type=int)
        
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            query = """
                SELECT 
                    mechanism,
                    field,
                    COUNT(*) as count,
                    AVG(confidence) as avg_confidence
                FROM signal_captures
                WHERE captured_at >= datetime('now', '-{} days')
            """.format(days)
            
            if property_id:
                query += " AND genome_id IN (SELECT genome_id FROM genome_profiles WHERE property_id = ?)"
                cursor.execute(query + " GROUP BY mechanism, field ORDER BY count DESC", (property_id,))
            else:
                cursor.execute(query + " GROUP BY mechanism, field ORDER BY count DESC")
            
            signals = [
                {
                    "mechanism": row['mechanism'],
                    "field": row['field'],
                    "count": row['count'],
                    "avg_confidence": round(row['avg_confidence'], 2)
                }
                for row in cursor.fetchall()
            ]
        
        return jsonify({
            "success": True,
            "period_days": days,
            "signals": signals
        })
    
    # ==================== HEALTH CHECK ====================
    
    @app.route('/api/v1/health', methods=['GET'])
    def health_check():
        """API health check"""
        return jsonify({
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "version": "1.0.0"
        })
    
    return app


# ==================== CHATBOT SDK ====================

class GenomeSDK:
    """
    SDK for integrating Genome Protocol into existing chatbot systems.
    Simpler than full API for direct integration.
    """
    
    def __init__(self, db_path: str = "genome_protocol.db"):
        self.db = get_database(db_path)
        self.engine = GenomeEngine(self.db)
        self.executor = FlowExecutor(self.engine)
    
    def process(self, property_id: str, guest_id: str, 
                message: str, channel: str = "whatsapp") -> Dict:
        """
        Process a message and return enriched response context.
        
        Returns:
            Dict with profile insights and response suggestions
        """
        profile, result = self.engine.process_message(
            property_id=property_id,
            guest_identifier=guest_id,
            message=message,
            channel=channel,
            direction="inbound"
        )
        
        return {
            "genome_id": profile.genome_id,
            "guest_name": profile.first_name or profile.name,
            "intent": result.inferred_intent,
            "sentiment": result.sentiment,
            "personalization": profile.get_personalization_insights(),
            "suggestions": result.suggested_responses,
            "collection_hooks": result.collection_opportunities,
            "profile_completeness": profile.profile_completeness
        }
    
    def get_guest(self, property_id: str, guest_id: str) -> Optional[Dict]:
        """Get guest profile for personalization"""
        profile = self.db.find_profile(property_id, guest_id)
        if profile:
            return profile.to_dict()
        return None
    
    def start_guided_flow(self, flow_type: str, property_id: str, 
                         guest_id: str) -> Dict:
        """Start a Genome-enabled conversation flow"""
        return self.executor.start_flow(flow_type, property_id, guest_id)
    
    def continue_flow(self, session_id: str, response: str) -> Dict:
        """Continue a conversation flow"""
        return self.executor.process_response(session_id, response)


# Entry point for running the API server
if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=5000, debug=True)
