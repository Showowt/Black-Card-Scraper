"""
GENOME PROTOCOL™ - Conversation Flow Templates
================================================
Ready-to-deploy conversation flows with embedded data collection
for hospitality businesses. Each flow captures signals naturally.
"""

from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum

from ..core.models import GenomeProfile, CollectionMechanism
from ..core.engine import GenomeEngine


class FlowType(Enum):
    BOOKING = "booking"
    RESTAURANT = "restaurant"
    CONCIERGE = "concierge"
    CHECK_IN = "check_in"
    FEEDBACK = "feedback"
    GENERAL = "general"


@dataclass
class FlowStep:
    """A single step in a conversation flow"""
    step_id: str
    message_template: str
    
    # Data collection
    genome_hook: Optional[CollectionMechanism] = None
    target_field: Optional[str] = None
    options: List[str] = field(default_factory=list)
    
    # Conditions
    condition: Optional[Callable[[GenomeProfile], bool]] = None
    skip_if_known: Optional[str] = None  # Skip if this field is already captured
    
    # Routing
    next_step: Optional[str] = None
    branch_logic: Optional[Dict[str, str]] = None  # {response: next_step_id}
    
    # Personalization
    personalization_fields: List[str] = field(default_factory=list)


@dataclass  
class ConversationFlow:
    """A complete conversation flow with Genome hooks"""
    flow_id: str
    flow_type: FlowType
    name: str
    description: str
    steps: List[FlowStep]
    
    # Configuration
    language: str = "es"  # Default Spanish for Colombia
    fallback_message: str = "¿En qué más puedo ayudarte?"
    
    def get_step(self, step_id: str) -> Optional[FlowStep]:
        for step in self.steps:
            if step.step_id == step_id:
                return step
        return None


# ==================== BOOKING FLOW ====================

BOOKING_FLOW = ConversationFlow(
    flow_id="booking_v1",
    flow_type=FlowType.BOOKING,
    name="Booking Inquiry Flow",
    description="Handles booking inquiries while capturing guest preferences",
    steps=[
        FlowStep(
            step_id="greeting",
            message_template="""¡Hola{name_greeting}! 👋

Me encantaría ayudarte con tu reserva. 

¿Para qué fechas estás buscando?""",
            personalization_fields=["name"],
            next_step="dates_received"
        ),
        
        FlowStep(
            step_id="dates_received",
            message_template="""Perfecto, déjame verificar la disponibilidad para esas fechas.

{availability_result}

Mientras busco, una pregunta rápida: **¿Prefieres llegada temprano o mantenemos el check-in estándar de las 3pm?**""",
            
            # GENOME HOOK: Preference Cascade - Chronotype
            genome_hook=CollectionMechanism.PREFERENCE_CASCADE,
            target_field="sensory.chronotype",
            options=["temprano", "estándar", "no importa"],
            branch_logic={
                "temprano": "early_arrival",
                "estándar": "standard_arrival",
                "no importa": "standard_arrival"
            }
        ),
        
        FlowStep(
            step_id="early_arrival",
            message_template="""¡Anotado! Coordinaré para que tu habitación esté lista temprano.

¿Viajas solo/a o debo planificar para más personas?""",
            
            # GENOME HOOK: Preference Cascade - Group Type
            genome_hook=CollectionMechanism.PREFERENCE_CASCADE,
            target_field="relationship.travel_companions",
            skip_if_known="relationship.travel_companions",
            next_step="group_captured"
        ),
        
        FlowStep(
            step_id="standard_arrival",
            message_template="""Perfecto, check-in estándar a las 3pm.

¿Viajas solo/a o debo planificar para más personas?""",
            
            genome_hook=CollectionMechanism.PREFERENCE_CASCADE,
            target_field="relationship.travel_companions",
            skip_if_known="relationship.travel_companions",
            next_step="group_captured"
        ),
        
        FlowStep(
            step_id="group_captured",
            message_template="""Excelente. Aquí tienes las opciones disponibles:

{room_options}

**¿Cuál te llama más la atención?**""",
            
            # GENOME HOOK: Concierge Capture - Budget/Preference reveal
            genome_hook=CollectionMechanism.CONCIERGE_CAPTURE,
            target_field="decision.price_sensitivity_index",
            next_step="room_selected"
        ),
        
        FlowStep(
            step_id="room_selected",
            message_template="""¡Excelente elección!{personalized_comment}

Para finalizar tu reserva, ¿alguna preferencia especial o alergias que deba anotar para el equipo?""",
            
            # GENOME HOOK: Relief Reveal - Dietary/Special needs
            genome_hook=CollectionMechanism.RELIEF_REVEAL,
            target_field="sensory.dietary_restrictions",
            personalization_fields=["room_choice_comment"],
            next_step="special_requests"
        ),
        
        FlowStep(
            step_id="special_requests",
            message_template="""Anotado. ¿Celebras alguna ocasión especial durante tu estadía?

(Aniversario, cumpleaños, luna de miel... así podemos preparar algo especial 🎉)""",
            
            # GENOME HOOK: Relief Reveal - Occasion
            genome_hook=CollectionMechanism.RELIEF_REVEAL,
            target_field="relationship.occasion_types",
            skip_if_known="relationship.occasion_types",
            next_step="confirmation"
        ),
        
        FlowStep(
            step_id="confirmation",
            message_template="""¡Perfecto! Aquí está el resumen de tu reserva:

{booking_summary}

**¿Te envío la confirmación por WhatsApp o prefieres email?**""",
            
            # GENOME HOOK: Preference Cascade - Communication channel
            genome_hook=CollectionMechanism.PREFERENCE_CASCADE,
            target_field="communication.preferred_channel",
            options=["whatsapp", "email"],
            next_step="complete"
        ),
        
        FlowStep(
            step_id="complete",
            message_template="""{confirmation_channel} ¡Listo! Tu confirmación va en camino.

{personalized_closing}

¿Hay algo más en lo que pueda ayudarte?"""
        )
    ]
)


# ==================== RESTAURANT FLOW ====================

RESTAURANT_FLOW = ConversationFlow(
    flow_id="restaurant_v1",
    flow_type=FlowType.RESTAURANT,
    name="Restaurant Reservation Flow",
    description="Handles restaurant reservations with preference capture",
    steps=[
        FlowStep(
            step_id="greeting",
            message_template="""¡Hola{name_greeting}! 🍽️

¿Te gustaría hacer una reserva en nuestro restaurante?

¿Para cuántas personas y qué fecha tienes en mente?""",
            personalization_fields=["name"],
            next_step="party_size_date"
        ),
        
        FlowStep(
            step_id="party_size_date",
            message_template="""Perfecto, {party_size} personas para {date}.

Tenemos disponibilidad. **¿Prefieres cena temprano tipo sunset (7pm) o más tarde en la noche?**""",
            
            # GENOME HOOK: Preference Cascade - Chronotype
            genome_hook=CollectionMechanism.PREFERENCE_CASCADE,
            target_field="sensory.chronotype",
            options=["temprano/sunset", "tarde/noche"],
            next_step="time_captured"
        ),
        
        FlowStep(
            step_id="time_captured",
            message_template="""Excelente. Tenemos mesas disponibles.

**Imagino que preferirías la terraza con vista al {view_type}—¿acierto?**""",
            
            # GENOME HOOK: Anticipation Engine - Space preference
            genome_hook=CollectionMechanism.ANTICIPATION_ENGINE,
            target_field="sensory.space_preference",
            next_step="seating_captured"
        ),
        
        FlowStep(
            step_id="seating_captured",
            message_template="""{seating_confirmation}

Una cosa importante: **¿alguna alergia o preferencia alimentaria que deba comunicar al chef?**

(Vegetariano, sin gluten, mariscos... lo que sea, lo anotamos)""",
            
            # GENOME HOOK: Relief Reveal - Dietary
            genome_hook=CollectionMechanism.RELIEF_REVEAL,
            target_field="sensory.dietary_restrictions",
            next_step="dietary_captured"
        ),
        
        FlowStep(
            step_id="dietary_captured",
            message_template="""¡Anotado para el chef! 

{dietary_note}

¿Es una ocasión especial? (Cumpleaños, aniversario, propuesta... 💍)""",
            
            # GENOME HOOK: Relief Reveal - Occasion
            genome_hook=CollectionMechanism.RELIEF_REVEAL,
            target_field="relationship.occasion_types",
            next_step="occasion_captured"
        ),
        
        FlowStep(
            step_id="occasion_captured",
            message_template="""{occasion_response}

Aquí tienes tu reserva confirmada:

📍 {restaurant_name}
📅 {date} a las {time}
👥 {party_size} personas
🪑 {seating_type}

{special_notes}

¿Te envío un recordatorio el día anterior?""",
            
            # GENOME HOOK: Preference Cascade - Communication frequency
            genome_hook=CollectionMechanism.PREFERENCE_CASCADE,
            target_field="communication.frequency_preference",
            next_step="complete"
        ),
        
        FlowStep(
            step_id="complete",
            message_template="""¡Perfecto! Todo confirmado.

{personalized_tip}

¡Te esperamos! 🙌"""
        )
    ]
)


# ==================== CONCIERGE FLOW ====================

CONCIERGE_FLOW = ConversationFlow(
    flow_id="concierge_v1",
    flow_type=FlowType.CONCIERGE,
    name="Concierge Services Flow",
    description="Handles concierge requests with deep preference mining",
    steps=[
        FlowStep(
            step_id="greeting",
            message_template="""¡Hola{name_greeting}! 

Soy tu concierge virtual. ¿En qué puedo ayudarte hoy?

• Tours y excursiones
• Transporte
• Reservas en restaurantes
• Experiencias especiales
• Recomendaciones locales""",
            personalization_fields=["name"],
            next_step="request_received"
        ),
        
        FlowStep(
            step_id="request_received",
            message_template="""¡Perfecto! Me encanta ayudar con {request_type}.

Para darte las mejores opciones: **¿buscas más aventura o relajación para esta experiencia?**""",
            
            # GENOME HOOK: Preference Cascade - Risk tolerance
            genome_hook=CollectionMechanism.PREFERENCE_CASCADE,
            target_field="decision.risk_tolerance",
            options=["aventura", "relajación", "mix de ambos"],
            next_step="style_captured"
        ),
        
        FlowStep(
            step_id="style_captured",
            message_template="""Entendido. Encontré tres opciones que creo te van a gustar:

**Opción A - {option_a_name}**
{option_a_description}
💰 {option_a_price}

**Opción B - {option_b_name}**
{option_b_description}
💰 {option_b_price}

**Opción C - {option_c_name}**
{option_c_description}
💰 {option_c_price}

**¿Cuál te llama más la atención?**""",
            
            # GENOME HOOK: Concierge Capture - Price sensitivity + preference
            genome_hook=CollectionMechanism.CONCIERGE_CAPTURE,
            target_field="decision.price_sensitivity_index",
            options=["A", "B", "C"],
            next_step="option_selected"
        ),
        
        FlowStep(
            step_id="option_selected",
            message_template="""{selection_comment}

**¿Para cuántas personas debo reservar?**""",
            
            # GENOME HOOK: Preference Cascade - Group size
            genome_hook=CollectionMechanism.PREFERENCE_CASCADE,
            target_field="relationship.typical_group_size",
            next_step="group_captured"
        ),
        
        FlowStep(
            step_id="group_captured",
            message_template="""Perfecto, {group_size} personas.

**¿Prefieren salir temprano en la mañana o más tarde?**""",
            
            # GENOME HOOK: Preference Cascade - Chronotype
            genome_hook=CollectionMechanism.PREFERENCE_CASCADE,
            target_field="sensory.chronotype",
            options=["temprano (antes de 9am)", "media mañana", "tarde"],
            next_step="timing_captured"
        ),
        
        FlowStep(
            step_id="timing_captured",
            message_template="""¡Excelente! Aquí está tu experiencia:

{experience_summary}

{pickup_details}

¿Necesitas que organice transporte desde tu hotel?""",
            
            # GENOME HOOK: Reward Loop - Show value of sharing
            genome_hook=CollectionMechanism.REWARD_LOOP,
            next_step="transport_check"
        ),
        
        FlowStep(
            step_id="transport_check",
            message_template="""{transport_response}

Todo confirmado. Te enviaré los detalles y recordatorio.

{personalized_tip_based_on_profile}

¿Hay algo más que pueda organizar para ti?""",
            next_step="complete"
        ),
        
        FlowStep(
            step_id="complete",
            message_template="""{closing_message}

¡Que disfrutes mucho! 🌟"""
        )
    ]
)


# ==================== CHECK-IN FLOW ====================

CHECK_IN_FLOW = ConversationFlow(
    flow_id="checkin_v1",
    flow_type=FlowType.CHECK_IN,
    name="Pre-Arrival Check-in Flow",
    description="Pre-arrival engagement with preference collection",
    steps=[
        FlowStep(
            step_id="pre_arrival_greeting",
            message_template="""¡Hola {name}! 👋

¡Tu llegada está cada vez más cerca! Soy tu asistente virtual y quiero asegurarme de que todo esté perfecto para recibirte.

Tu reserva:
📅 Check-in: {checkin_date}
🏨 {room_type}

¿Hay algo especial que debamos preparar para tu llegada?""",
            personalization_fields=["name", "checkin_date", "room_type"],
            next_step="special_prep"
        ),
        
        FlowStep(
            step_id="special_prep",
            message_template="""{special_prep_response}

Para tu comodidad, algunas preguntas rápidas:

**¿A qué temperatura prefieres la habitación?**
• Fresca (20°C)
• Moderada (22°C)  
• Cálida (24°C)""",
            
            # GENOME HOOK: Preference Cascade - Temperature
            genome_hook=CollectionMechanism.PREFERENCE_CASCADE,
            target_field="sensory.temperature_preference",
            options=["fresca", "moderada", "cálida"],
            next_step="temperature_set"
        ),
        
        FlowStep(
            step_id="temperature_set",
            message_template="""¡Anotado! La habitación estará a tu gusto.

**¿Prefieres almohadas firmes o suaves?**""",
            
            # GENOME HOOK: Preference Cascade - Room preferences
            genome_hook=CollectionMechanism.PREFERENCE_CASCADE,
            target_field="sensory.room_preferences",
            options=["firmes", "suaves", "ambas"],
            next_step="pillows_set"
        ),
        
        FlowStep(
            step_id="pillows_set",
            message_template="""Perfecto.

**¿A qué hora aproximada planeas llegar?** 

Así tendremos todo listo y, si llegas temprano, intentaremos tener tu habitación antes.""",
            
            # GENOME HOOK: Relief Reveal - Planning style
            genome_hook=CollectionMechanism.RELIEF_REVEAL,
            target_field="decision.typical_lead_time_days",
            next_step="arrival_time"
        ),
        
        FlowStep(
            step_id="arrival_time",
            message_template="""¡Excelente! Te esperamos {arrival_time}.

Una última cosa: **¿Hay algún snack o bebida que te gustaría encontrar en la habitación?**

(Agua, frutas, vino, algo específico... dime y lo preparamos 🍇)""",
            
            # GENOME HOOK: Relief Reveal - Preferences as care
            genome_hook=CollectionMechanism.RELIEF_REVEAL,
            target_field="sensory.amenity_priorities",
            next_step="amenities_noted"
        ),
        
        FlowStep(
            step_id="amenities_noted",
            message_template="""{amenity_response}

¡Todo listo para recibirte! Aquí está lo que hemos preparado:

{preparation_summary}

¿Necesitas información sobre transporte al hotel o alguna recomendación para tus primeras horas?""",
            
            # GENOME HOOK: Reward Loop - Show personalization value
            genome_hook=CollectionMechanism.REWARD_LOOP,
            next_step="final_offers"
        ),
        
        FlowStep(
            step_id="final_offers",
            message_template="""{transport_info}

Te enviaré un mensaje el día de tu llegada con los últimos detalles.

¡Nos vemos pronto! 🌴"""
        )
    ]
)


# ==================== FLOW REGISTRY ====================

FLOW_REGISTRY = {
    "booking": BOOKING_FLOW,
    "restaurant": RESTAURANT_FLOW,
    "concierge": CONCIERGE_FLOW,
    "checkin": CHECK_IN_FLOW,
}


def get_flow(flow_type: str) -> Optional[ConversationFlow]:
    """Get a conversation flow by type"""
    return FLOW_REGISTRY.get(flow_type)


def get_all_flows() -> Dict[str, ConversationFlow]:
    """Get all registered flows"""
    return FLOW_REGISTRY.copy()


# ==================== FLOW EXECUTOR ====================

class FlowExecutor:
    """
    Executes conversation flows and handles Genome signal capture.
    Integrates with the GenomeEngine for profile updates.
    """
    
    def __init__(self, engine: GenomeEngine):
        self.engine = engine
        self.active_sessions: Dict[str, Dict] = {}  # guest_id -> session state
    
    def start_flow(self, flow_type: str, property_id: str, 
                  guest_identifier: str) -> Dict:
        """Start a new conversation flow for a guest"""
        flow = get_flow(flow_type)
        if not flow:
            return {"error": f"Unknown flow type: {flow_type}"}
        
        # Get or create profile
        profile = self.engine.db.get_or_create_profile(property_id, guest_identifier)
        
        # Create session
        session_id = f"{property_id}:{guest_identifier}:{flow.flow_id}"
        self.active_sessions[session_id] = {
            "flow_id": flow.flow_id,
            "current_step": flow.steps[0].step_id,
            "profile": profile,
            "property_id": property_id,
            "guest_identifier": guest_identifier,
            "context": {}
        }
        
        # Get first message
        first_step = flow.steps[0]
        message = self._render_message(first_step, profile)
        
        return {
            "session_id": session_id,
            "message": message,
            "step_id": first_step.step_id,
            "genome_hook": first_step.genome_hook.value if first_step.genome_hook else None,
            "options": first_step.options
        }
    
    def process_response(self, session_id: str, user_response: str) -> Dict:
        """Process user response and advance flow"""
        if session_id not in self.active_sessions:
            return {"error": "Session not found"}
        
        session = self.active_sessions[session_id]
        flow = get_flow(session["flow_id"].split("_")[0])
        current_step = flow.get_step(session["current_step"])
        
        # Process message through engine (captures signals)
        profile, extraction = self.engine.process_message(
            property_id=session["property_id"],
            guest_identifier=session["guest_identifier"],
            message=user_response,
            channel="whatsapp",
            direction="inbound"
        )
        
        # Handle Genome hook response
        if current_step.genome_hook and current_step.target_field:
            self._process_hook_response(
                current_step, user_response, profile, session
            )
        
        # Determine next step
        next_step_id = self._determine_next_step(current_step, user_response)
        
        if not next_step_id:
            # Flow complete
            del self.active_sessions[session_id]
            return {
                "session_id": session_id,
                "message": flow.fallback_message,
                "flow_complete": True,
                "profile_completeness": profile.profile_completeness,
                "signals_captured": len(extraction.signals)
            }
        
        # Get next step
        next_step = flow.get_step(next_step_id)
        
        # Check skip conditions
        if next_step.skip_if_known:
            current_value = self._get_nested_value(profile, next_step.skip_if_known)
            if current_value and current_value != "unknown":
                # Skip to the step after
                next_step_id = next_step.next_step
                next_step = flow.get_step(next_step_id) if next_step_id else None
        
        if not next_step:
            del self.active_sessions[session_id]
            return {
                "session_id": session_id,
                "message": flow.fallback_message,
                "flow_complete": True
            }
        
        # Update session
        session["current_step"] = next_step_id
        session["profile"] = profile
        
        # Render next message
        message = self._render_message(next_step, profile, session["context"])
        
        return {
            "session_id": session_id,
            "message": message,
            "step_id": next_step_id,
            "genome_hook": next_step.genome_hook.value if next_step.genome_hook else None,
            "options": next_step.options,
            "signals_captured": len(extraction.signals),
            "profile_completeness": profile.profile_completeness
        }
    
    def _render_message(self, step: FlowStep, profile: GenomeProfile, 
                       context: Dict = None) -> str:
        """Render message template with profile data"""
        context = context or {}
        
        # Build name greeting
        if profile.first_name:
            context["name_greeting"] = f" {profile.first_name}"
            context["name"] = profile.first_name
        elif profile.name:
            context["name_greeting"] = f" {profile.name.split()[0]}"
            context["name"] = profile.name.split()[0]
        else:
            context["name_greeting"] = ""
            context["name"] = ""
        
        # Add personalization based on profile
        if profile.communication.emoji_usage == "none":
            # Remove emojis from message
            pass  # Could implement emoji stripping
        
        # Render template
        try:
            message = step.message_template.format(**context)
        except KeyError as e:
            # Missing context variable - use placeholder
            message = step.message_template
            for key in step.personalization_fields:
                message = message.replace(f"{{{key}}}", f"[{key}]")
        
        return message
    
    def _process_hook_response(self, step: FlowStep, response: str, 
                              profile: GenomeProfile, session: Dict):
        """Process response to a Genome collection hook"""
        from ..core.models import SignalCapture
        import uuid
        
        # Map response to signal value based on hook type
        signal_value = self._map_response_to_signal(step, response)
        
        if signal_value is not None:
            signal = SignalCapture(
                field=step.target_field,
                value=signal_value,
                confidence=ConfidenceLevel.DECLARED,
                mechanism=step.genome_hook,
                source_interaction_id=str(uuid.uuid4()),
                raw_input=response
            )
            profile.update_signal(signal)
            self.engine.db.update_profile(profile)
    
    def _map_response_to_signal(self, step: FlowStep, response: str) -> Any:
        """Map user response to signal value"""
        response_lower = response.lower().strip()
        
        # Check against defined options
        if step.options:
            for i, option in enumerate(step.options):
                if option.lower() in response_lower or response_lower in option.lower():
                    return option
        
        # Parse based on target field
        if "chronotype" in step.target_field:
            if any(w in response_lower for w in ["temprano", "early", "mañana", "morning"]):
                return "early_bird"
            elif any(w in response_lower for w in ["tarde", "noche", "late", "night"]):
                return "night_owl"
        
        if "travel_companions" in step.target_field:
            if any(w in response_lower for w in ["solo", "alone", "just me"]):
                return "solo"
            elif any(w in response_lower for w in ["pareja", "couple", "esposa", "esposo", "wife", "husband"]):
                return "couple"
            elif any(w in response_lower for w in ["familia", "family", "niños", "kids", "hijos"]):
                return "family"
            elif any(w in response_lower for w in ["amigos", "friends", "grupo"]):
                return "friends"
        
        if "price_sensitivity" in step.target_field:
            # Based on which option they chose (A=budget, B=mid, C=premium)
            if "a" in response_lower or "primera" in response_lower:
                return 70  # Budget conscious
            elif "c" in response_lower or "tercera" in response_lower:
                return 20  # Premium
            else:
                return 50  # Mid-range
        
        if "dietary" in step.target_field:
            if any(w in response_lower for w in ["no", "ninguna", "none", "nada"]):
                return []
            # Return the raw response for dietary - will be parsed
            return response
        
        if "occasion" in step.target_field:
            occasions = []
            if any(w in response_lower for w in ["aniversario", "anniversary"]):
                occasions.append("anniversary")
            if any(w in response_lower for w in ["cumpleaños", "birthday"]):
                occasions.append("birthday")
            if any(w in response_lower for w in ["luna de miel", "honeymoon"]):
                occasions.append("honeymoon")
            return occasions if occasions else None
        
        if "temperature" in step.target_field:
            if any(w in response_lower for w in ["fresca", "cool", "fría"]):
                return "cool"
            elif any(w in response_lower for w in ["cálida", "warm", "caliente"]):
                return "warm"
            return "moderate"
        
        return response
    
    def _determine_next_step(self, current_step: FlowStep, response: str) -> Optional[str]:
        """Determine the next step based on response"""
        # Check branch logic first
        if current_step.branch_logic:
            response_lower = response.lower().strip()
            for trigger, next_step in current_step.branch_logic.items():
                if trigger.lower() in response_lower:
                    return next_step
        
        # Default to next_step
        return current_step.next_step
    
    def _get_nested_value(self, obj: Any, path: str) -> Any:
        """Get nested attribute value"""
        parts = path.split(".")
        for part in parts:
            if hasattr(obj, part):
                obj = getattr(obj, part)
            else:
                return None
        return obj


# Import ConfidenceLevel for use in FlowExecutor
from ..core.models import ConfidenceLevel
