"""GENOME PROTOCOL™ - Platform Integrations"""

from .whatsapp import WhatsAppGenomeBot, WhatsAppMessage, create_whatsapp_blueprint
