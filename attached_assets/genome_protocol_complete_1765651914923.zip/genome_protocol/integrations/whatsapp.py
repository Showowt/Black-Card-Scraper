"""
GENOME PROTOCOL™ - WhatsApp Business API Integration
======================================================
Direct integration with WhatsApp Business API for real-time
message processing and Genome signal extraction.
"""

import os
import json
import hmac
import hashlib
import requests
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass

from ..core.engine import GenomeEngine
from ..core.database import get_database
from ..flows.templates import FlowExecutor, get_flow


@dataclass
class WhatsAppMessage:
    """Parsed WhatsApp message"""
    message_id: str
    from_number: str
    timestamp: datetime
    message_type: str  # text, image, document, location, etc.
    content: str
    context: Optional[Dict] = None  # Reply context
    
    @classmethod
    def from_webhook(cls, message_data: Dict) -> 'WhatsAppMessage':
        """Parse from WhatsApp webhook payload"""
        msg_type = message_data.get('type', 'text')
        
        if msg_type == 'text':
            content = message_data.get('text', {}).get('body', '')
        elif msg_type == 'button':
            content = message_data.get('button', {}).get('text', '')
        elif msg_type == 'interactive':
            interactive = message_data.get('interactive', {})
            if interactive.get('type') == 'button_reply':
                content = interactive.get('button_reply', {}).get('title', '')
            elif interactive.get('type') == 'list_reply':
                content = interactive.get('list_reply', {}).get('title', '')
            else:
                content = str(interactive)
        elif msg_type == 'location':
            loc = message_data.get('location', {})
            content = f"Location: {loc.get('latitude')}, {loc.get('longitude')}"
        else:
            content = f"[{msg_type} message]"
        
        return cls(
            message_id=message_data.get('id', ''),
            from_number=message_data.get('from', ''),
            timestamp=datetime.fromtimestamp(int(message_data.get('timestamp', 0))),
            message_type=msg_type,
            content=content,
            context=message_data.get('context')
        )


class WhatsAppGenomeBot:
    """
    WhatsApp chatbot with integrated Genome Protocol.
    Handles messages, extracts signals, and responds with personalization.
    """
    
    def __init__(self, 
                 phone_number_id: str,
                 access_token: str,
                 verify_token: str,
                 property_id: str,
                 db_path: str = "genome_protocol.db",
                 app_secret: Optional[str] = None):
        """
        Initialize WhatsApp Genome Bot.
        
        Args:
            phone_number_id: WhatsApp Business phone number ID
            access_token: Meta API access token
            verify_token: Webhook verification token
            property_id: MachineMind client property ID
            db_path: Path to Genome database
            app_secret: App secret for webhook signature verification
        """
        self.phone_number_id = phone_number_id
        self.access_token = access_token
        self.verify_token = verify_token
        self.property_id = property_id
        self.app_secret = app_secret
        
        # Initialize Genome components
        self.db = get_database(db_path)
        self.engine = GenomeEngine(self.db)
        self.executor = FlowExecutor(self.engine)
        
        # Message handlers
        self.intent_handlers: Dict[str, Callable] = {}
        self.active_flows: Dict[str, str] = {}  # phone -> session_id
        
        # API base URL
        self.api_base = "https://graph.facebook.com/v18.0"
    
    def verify_webhook(self, mode: str, token: str, challenge: str) -> Optional[str]:
        """Verify webhook subscription"""
        if mode == 'subscribe' and token == self.verify_token:
            return challenge
        return None
    
    def verify_signature(self, payload: bytes, signature: str) -> bool:
        """Verify webhook signature"""
        if not self.app_secret:
            return True  # Skip verification if no secret configured
        
        expected = hmac.new(
            self.app_secret.encode(),
            payload,
            hashlib.sha256
        ).hexdigest()
        
        return hmac.compare_digest(f"sha256={expected}", signature)
    
    def process_webhook(self, payload: Dict) -> List[Dict]:
        """
        Process incoming webhook payload.
        Returns list of responses to send.
        """
        responses = []
        
        for entry in payload.get('entry', []):
            for change in entry.get('changes', []):
                value = change.get('value', {})
                
                # Handle messages
                for message_data in value.get('messages', []):
                    message = WhatsAppMessage.from_webhook(message_data)
                    response = self.handle_message(message)
                    if response:
                        responses.append(response)
                
                # Handle status updates (delivered, read, etc.)
                for status in value.get('statuses', []):
                    self._handle_status(status)
        
        return responses
    
    def handle_message(self, message: WhatsAppMessage) -> Optional[Dict]:
        """
        Handle incoming message with Genome processing.
        """
        phone = message.from_number
        
        # Check if in active flow
        if phone in self.active_flows:
            return self._continue_flow(phone, message)
        
        # Process through Genome engine
        profile, result = self.engine.process_message(
            property_id=self.property_id,
            guest_identifier=phone,
            message=message.content,
            channel='whatsapp',
            direction='inbound'
        )
        
        # Check for registered intent handler
        if result.inferred_intent in self.intent_handlers:
            handler = self.intent_handlers[result.inferred_intent]
            response_text = handler(profile, message, result)
        else:
            # Use suggested response or default
            if result.suggested_responses:
                response_text = result.suggested_responses[0]
            else:
                response_text = self._default_response(profile, result)
        
        # Check for collection opportunities
        if result.collection_opportunities:
            # Append a collection hook to response
            hook = result.collection_opportunities[0]
            response_text += f"\n\n{hook.get('question', '')}"
        
        return {
            'to': phone,
            'type': 'text',
            'text': response_text,
            'genome_id': profile.genome_id,
            'intent': result.inferred_intent
        }
    
    def start_flow(self, phone: str, flow_type: str) -> Dict:
        """Start a guided conversation flow"""
        result = self.executor.start_flow(
            flow_type=flow_type,
            property_id=self.property_id,
            guest_identifier=phone
        )
        
        if 'error' not in result:
            self.active_flows[phone] = result['session_id']
        
        return {
            'to': phone,
            'type': 'text',
            'text': result.get('message', result.get('error', 'Error starting flow'))
        }
    
    def _continue_flow(self, phone: str, message: WhatsAppMessage) -> Dict:
        """Continue an active conversation flow"""
        session_id = self.active_flows[phone]
        
        result = self.executor.process_response(
            session_id=session_id,
            user_response=message.content
        )
        
        if result.get('flow_complete'):
            del self.active_flows[phone]
        
        return {
            'to': phone,
            'type': 'text',
            'text': result.get('message', ''),
            'flow_complete': result.get('flow_complete', False)
        }
    
    def _default_response(self, profile, result) -> str:
        """Generate default response when no handler matches"""
        greeting = f"Hola {profile.first_name}! " if profile.first_name else "¡Hola! "
        
        if result.inferred_intent == 'greeting':
            return f"{greeting}¿En qué puedo ayudarte hoy?"
        elif result.inferred_intent == 'booking_inquiry':
            return f"{greeting}Me encantaría ayudarte con tu reserva. ¿Para qué fechas estás buscando?"
        elif result.inferred_intent == 'price_inquiry':
            return f"{greeting}Con gusto te comparto la información de precios. ¿Qué tipo de experiencia te interesa?"
        else:
            return f"{greeting}Estoy aquí para ayudarte. ¿Qué necesitas?"
    
    def _handle_status(self, status: Dict):
        """Handle message status updates"""
        # Could track delivery, read receipts for behavioral analysis
        pass
    
    def register_handler(self, intent: str, handler: Callable):
        """Register a custom intent handler"""
        self.intent_handlers[intent] = handler
    
    # ==================== SENDING MESSAGES ====================
    
    def send_text(self, to: str, text: str, preview_url: bool = False) -> Dict:
        """Send a text message"""
        return self._send_message({
            'messaging_product': 'whatsapp',
            'recipient_type': 'individual',
            'to': to,
            'type': 'text',
            'text': {
                'preview_url': preview_url,
                'body': text
            }
        })
    
    def send_template(self, to: str, template_name: str, 
                     language: str = 'es',
                     components: List[Dict] = None) -> Dict:
        """Send a template message"""
        payload = {
            'messaging_product': 'whatsapp',
            'recipient_type': 'individual',
            'to': to,
            'type': 'template',
            'template': {
                'name': template_name,
                'language': {'code': language}
            }
        }
        
        if components:
            payload['template']['components'] = components
        
        return self._send_message(payload)
    
    def send_interactive_buttons(self, to: str, body: str, 
                                 buttons: List[Dict],
                                 header: str = None,
                                 footer: str = None) -> Dict:
        """
        Send interactive button message.
        Great for Genome Preference Cascade hooks!
        
        buttons format: [{'id': 'btn_1', 'title': 'Option 1'}, ...]
        """
        interactive = {
            'type': 'button',
            'body': {'text': body},
            'action': {
                'buttons': [
                    {'type': 'reply', 'reply': btn}
                    for btn in buttons[:3]  # Max 3 buttons
                ]
            }
        }
        
        if header:
            interactive['header'] = {'type': 'text', 'text': header}
        if footer:
            interactive['footer'] = {'text': footer}
        
        return self._send_message({
            'messaging_product': 'whatsapp',
            'recipient_type': 'individual',
            'to': to,
            'type': 'interactive',
            'interactive': interactive
        })
    
    def send_interactive_list(self, to: str, body: str,
                             button_text: str,
                             sections: List[Dict],
                             header: str = None,
                             footer: str = None) -> Dict:
        """
        Send interactive list message.
        Great for Genome Concierge Capture hooks!
        
        sections format: [
            {
                'title': 'Section 1',
                'rows': [
                    {'id': 'row_1', 'title': 'Option 1', 'description': 'Description'}
                ]
            }
        ]
        """
        interactive = {
            'type': 'list',
            'body': {'text': body},
            'action': {
                'button': button_text,
                'sections': sections
            }
        }
        
        if header:
            interactive['header'] = {'type': 'text', 'text': header}
        if footer:
            interactive['footer'] = {'text': footer}
        
        return self._send_message({
            'messaging_product': 'whatsapp',
            'recipient_type': 'individual',
            'to': to,
            'type': 'interactive',
            'interactive': interactive
        })
    
    def _send_message(self, payload: Dict) -> Dict:
        """Send message via WhatsApp API"""
        url = f"{self.api_base}/{self.phone_number_id}/messages"
        
        headers = {
            'Authorization': f'Bearer {self.access_token}',
            'Content-Type': 'application/json'
        }
        
        response = requests.post(url, headers=headers, json=payload)
        return response.json()
    
    # ==================== GENOME-ENHANCED MESSAGING ====================
    
    def send_preference_cascade(self, to: str, question: str,
                                options: List[str],
                                target_field: str) -> Dict:
        """
        Send a Preference Cascade collection hook as interactive buttons.
        
        Args:
            to: Recipient phone number
            question: The question to ask
            options: List of options (max 3)
            target_field: Genome profile field to update
        """
        buttons = [
            {'id': f'genome_{target_field}_{i}', 'title': opt[:20]}
            for i, opt in enumerate(options[:3])
        ]
        
        return self.send_interactive_buttons(
            to=to,
            body=question,
            buttons=buttons,
            footer="Genome Protocol™"
        )
    
    def send_concierge_capture(self, to: str, intro: str,
                              options: List[Dict],
                              target_field: str) -> Dict:
        """
        Send a Concierge Capture hook as interactive list.
        Choice reveals budget/preference.
        
        options format: [
            {'name': 'Option A', 'description': 'Budget option', 'price': '$50'},
            {'name': 'Option B', 'description': 'Mid-range', 'price': '$100'},
            {'name': 'Option C', 'description': 'Premium', 'price': '$200'}
        ]
        """
        sections = [{
            'title': 'Opciones disponibles',
            'rows': [
                {
                    'id': f'genome_{target_field}_{i}',
                    'title': opt['name'][:24],
                    'description': f"{opt['description']} - {opt['price']}"[:72]
                }
                for i, opt in enumerate(options)
            ]
        }]
        
        return self.send_interactive_list(
            to=to,
            body=intro,
            button_text="Ver opciones",
            sections=sections,
            footer="¿Cuál te llama más la atención?"
        )
    
    def send_anticipation_engine(self, to: str, prediction: str,
                                target_field: str) -> Dict:
        """
        Send an Anticipation Engine hook - predict and confirm.
        """
        buttons = [
            {'id': f'genome_{target_field}_confirm', 'title': '¡Sí, exacto! ✓'},
            {'id': f'genome_{target_field}_deny', 'title': 'No realmente'},
        ]
        
        return self.send_interactive_buttons(
            to=to,
            body=prediction,
            buttons=buttons
        )
    
    def send_personalized_message(self, to: str, template: str) -> Dict:
        """
        Send a personalized message using Genome profile data.
        
        Template can include placeholders:
        - {name} - Guest name
        - {greeting} - Personalized greeting based on time/style
        - {emoji} - Emoji if they use them, empty if not
        """
        profile = self.db.find_profile(self.property_id, to)
        
        if profile:
            # Build personalization context
            name = profile.first_name or profile.name or ''
            emoji = '👋 ' if profile.communication.emoji_usage != 'none' else ''
            
            # Time-appropriate greeting
            hour = datetime.now().hour
            if hour < 12:
                greeting = 'Buenos días'
            elif hour < 18:
                greeting = 'Buenas tardes'
            else:
                greeting = 'Buenas noches'
            
            if name:
                greeting = f"{greeting} {name}"
            
            # Replace placeholders
            text = template.format(
                name=name,
                greeting=greeting,
                emoji=emoji
            )
        else:
            # No profile yet - use generic
            text = template.format(
                name='',
                greeting='¡Hola!',
                emoji=''
            )
        
        return self.send_text(to, text)


# ==================== FLASK WEBHOOK BLUEPRINT ====================

def create_whatsapp_blueprint(bot: WhatsAppGenomeBot):
    """Create Flask blueprint for WhatsApp webhook"""
    from flask import Blueprint, request, jsonify
    
    bp = Blueprint('whatsapp', __name__)
    
    @bp.route('/webhook', methods=['GET'])
    def verify():
        mode = request.args.get('hub.mode')
        token = request.args.get('hub.verify_token')
        challenge = request.args.get('hub.challenge')
        
        result = bot.verify_webhook(mode, token, challenge)
        if result:
            return result, 200
        return 'Forbidden', 403
    
    @bp.route('/webhook', methods=['POST'])
    def webhook():
        # Verify signature
        signature = request.headers.get('X-Hub-Signature-256', '')
        if not bot.verify_signature(request.data, signature):
            return 'Invalid signature', 403
        
        # Process webhook
        payload = request.json
        responses = bot.process_webhook(payload)
        
        # Send responses
        for response in responses:
            if response.get('type') == 'text':
                bot.send_text(response['to'], response['text'])
        
        return jsonify({'status': 'ok'}), 200
    
    return bp


# ==================== EXAMPLE USAGE ====================

def example_setup():
    """Example bot setup with Genome hooks"""
    
    # Initialize bot
    bot = WhatsAppGenomeBot(
        phone_number_id=os.getenv('WHATSAPP_PHONE_ID'),
        access_token=os.getenv('WHATSAPP_ACCESS_TOKEN'),
        verify_token=os.getenv('WHATSAPP_VERIFY_TOKEN'),
        property_id='hotel_casa_san_agustin'
    )
    
    # Register custom handler for booking intent
    def handle_booking(profile, message, result):
        # Start booking flow with Genome hooks
        flow_result = bot.start_flow(message.from_number, 'booking')
        return flow_result['text']
    
    bot.register_handler('booking_inquiry', handle_booking)
    
    # Register handler for concierge requests
    def handle_concierge(profile, message, result):
        # Send Concierge Capture hook
        bot.send_concierge_capture(
            to=message.from_number,
            intro="Encontré tres opciones que creo te van a encantar:",
            options=[
                {'name': 'Tour en Bicicleta', 'description': 'Recorrido por el centro histórico', 'price': '$45 USD'},
                {'name': 'Tour Gastronómico', 'description': 'Degustación de comida local', 'price': '$75 USD'},
                {'name': 'Tour Privado VIP', 'description': 'Guía exclusivo + transporte', 'price': '$150 USD'}
            ],
            target_field='decision.price_sensitivity_index'
        )
        return None  # Response sent via interactive message
    
    bot.register_handler('concierge_request', handle_concierge)
    
    return bot
