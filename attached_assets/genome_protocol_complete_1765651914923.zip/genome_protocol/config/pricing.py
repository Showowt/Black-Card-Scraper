"""
GENOME PROTOCOL™ - Pricing Tiers Configuration
================================================
Pricing structure for MachineMind AI services with Genome Protocol.
Updated to include Genome as premium differentiator.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional
from enum import Enum


class TierLevel(Enum):
    STARTER = "starter"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"


@dataclass
class GenomeFeatures:
    """Genome Protocol features by tier"""
    basic_preference_tracking: bool = False
    full_genome_profiles: bool = False
    returning_guest_recognition: bool = False
    predictive_preferences: bool = False
    cross_property_intelligence: bool = False
    vip_identification: bool = False
    intelligence_reports: bool = False
    report_frequency: Optional[str] = None  # weekly, monthly, quarterly
    custom_collection_hooks: bool = False
    api_access: bool = False
    white_label_dashboard: bool = False


@dataclass
class PricingTier:
    """Complete pricing tier definition"""
    level: TierLevel
    name: str
    tagline: str
    
    # Pricing (USD)
    monthly_price: int
    annual_price: int  # Per year (discount applied)
    setup_fee: int
    
    # Core chatbot features
    conversations_per_month: int  # -1 for unlimited
    response_time_sla: str
    channels: List[str]
    languages: List[str]
    
    # Genome Protocol features
    genome: GenomeFeatures
    
    # Support
    support_level: str
    dedicated_account_manager: bool
    onboarding_calls: int
    
    # Value props for sales
    key_benefits: List[str]
    ideal_for: str
    
    def to_dict(self) -> Dict:
        return {
            "level": self.level.value,
            "name": self.name,
            "tagline": self.tagline,
            "pricing": {
                "monthly": self.monthly_price,
                "annual": self.annual_price,
                "setup": self.setup_fee,
                "currency": "USD"
            },
            "features": {
                "conversations": self.conversations_per_month,
                "response_sla": self.response_time_sla,
                "channels": self.channels,
                "languages": self.languages
            },
            "genome_features": {
                "basic_tracking": self.genome.basic_preference_tracking,
                "full_profiles": self.genome.full_genome_profiles,
                "returning_guest": self.genome.returning_guest_recognition,
                "predictive": self.genome.predictive_preferences,
                "cross_property": self.genome.cross_property_intelligence,
                "vip_identification": self.genome.vip_identification,
                "intelligence_reports": self.genome.intelligence_reports,
                "report_frequency": self.genome.report_frequency,
                "custom_hooks": self.genome.custom_collection_hooks,
                "api_access": self.genome.api_access,
                "white_label": self.genome.white_label_dashboard
            },
            "support": {
                "level": self.support_level,
                "dedicated_am": self.dedicated_account_manager,
                "onboarding_calls": self.onboarding_calls
            },
            "sales": {
                "benefits": self.key_benefits,
                "ideal_for": self.ideal_for
            }
        }


# ==================== TIER DEFINITIONS ====================

STARTER_TIER = PricingTier(
    level=TierLevel.STARTER,
    name="Starter",
    tagline="Capture the conversations you're missing",
    
    monthly_price=290,
    annual_price=2900,  # ~17% discount
    setup_fee=0,
    
    conversations_per_month=500,
    response_time_sla="< 30 seconds",
    channels=["whatsapp"],
    languages=["es", "en"],
    
    genome=GenomeFeatures(
        basic_preference_tracking=True,
        full_genome_profiles=False,
        returning_guest_recognition=False,
        predictive_preferences=False,
        cross_property_intelligence=False,
        vip_identification=False,
        intelligence_reports=False,
        report_frequency=None,
        custom_collection_hooks=False,
        api_access=False,
        white_label_dashboard=False
    ),
    
    support_level="email",
    dedicated_account_manager=False,
    onboarding_calls=1,
    
    key_benefits=[
        "24/7 instant WhatsApp responses",
        "Capture 67% of inquiries you're currently missing",
        "Basic guest preference tracking",
        "Spanish & English support",
        "Be the first to respond (78% book with first responder)"
    ],
    ideal_for="Small hotels, B&Bs, and vacation rentals getting started with automation"
)

PROFESSIONAL_TIER = PricingTier(
    level=TierLevel.PROFESSIONAL,
    name="Professional",
    tagline="Turn every conversation into guest intelligence",
    
    monthly_price=590,
    annual_price=5900,  # ~17% discount
    setup_fee=0,
    
    conversations_per_month=2000,
    response_time_sla="< 15 seconds",
    channels=["whatsapp", "instagram", "email"],
    languages=["es", "en", "pt"],
    
    genome=GenomeFeatures(
        basic_preference_tracking=True,
        full_genome_profiles=True,
        returning_guest_recognition=True,
        predictive_preferences=False,
        cross_property_intelligence=False,
        vip_identification=True,
        intelligence_reports=True,
        report_frequency="monthly",
        custom_collection_hooks=False,
        api_access=False,
        white_label_dashboard=False
    ),
    
    support_level="priority_email",
    dedicated_account_manager=False,
    onboarding_calls=2,
    
    key_benefits=[
        "Everything in Starter, plus:",
        "Full Genome Protocol™ guest profiles",
        "Returning guest recognition - treat them like VIPs instantly",
        "Multi-channel support (WhatsApp, Instagram, Email)",
        "Monthly Guest Intelligence Reports",
        "VIP guest identification",
        "Every interaction builds permanent guest memory"
    ],
    ideal_for="Boutique hotels and restaurants wanting personalized guest experiences"
)

ENTERPRISE_TIER = PricingTier(
    level=TierLevel.ENTERPRISE,
    name="Enterprise",
    tagline="Predictive intelligence that anticipates guest needs",
    
    monthly_price=1090,
    annual_price=10900,  # ~17% discount
    setup_fee=0,
    
    conversations_per_month=-1,  # Unlimited
    response_time_sla="< 10 seconds",
    channels=["whatsapp", "instagram", "email", "sms", "website"],
    languages=["es", "en", "pt", "fr", "de"],
    
    genome=GenomeFeatures(
        basic_preference_tracking=True,
        full_genome_profiles=True,
        returning_guest_recognition=True,
        predictive_preferences=True,
        cross_property_intelligence=True,
        vip_identification=True,
        intelligence_reports=True,
        report_frequency="weekly",
        custom_collection_hooks=True,
        api_access=True,
        white_label_dashboard=True
    ),
    
    support_level="priority_phone",
    dedicated_account_manager=True,
    onboarding_calls=4,
    
    key_benefits=[
        "Everything in Professional, plus:",
        "Predictive preferences - anticipate needs before they ask",
        "Cross-property intelligence (for hotel groups)",
        "Weekly Intelligence Reports",
        "Custom Genome collection hooks for your business",
        "Full API access for PMS/CRM integration",
        "White-label dashboard",
        "Unlimited conversations",
        "Dedicated account manager",
        "5-language support"
    ],
    ideal_for="Hotel groups, luxury properties, and high-volume operations"
)


# ==================== ADD-ON SERVICES ====================

@dataclass
class AddOnService:
    """Optional add-on services"""
    name: str
    description: str
    monthly_price: int
    one_time_price: Optional[int] = None
    compatible_tiers: List[TierLevel] = field(default_factory=list)


ADDON_SERVICES = [
    AddOnService(
        name="Guest Intelligence Briefing",
        description="Detailed monthly report with preference patterns, high-value profiles, personalization opportunities, and competitive intelligence",
        monthly_price=200,
        compatible_tiers=[TierLevel.STARTER, TierLevel.PROFESSIONAL]
    ),
    AddOnService(
        name="Premium Intelligence Package",
        description="Weekly briefings + quarterly strategy sessions + custom insights",
        monthly_price=500,
        compatible_tiers=[TierLevel.PROFESSIONAL, TierLevel.ENTERPRISE]
    ),
    AddOnService(
        name="Custom Flow Development",
        description="Custom conversation flows with embedded Genome collection hooks",
        monthly_price=0,
        one_time_price=750,
        compatible_tiers=[TierLevel.PROFESSIONAL, TierLevel.ENTERPRISE]
    ),
    AddOnService(
        name="PMS Integration",
        description="Connect Genome profiles to your property management system",
        monthly_price=150,
        one_time_price=500,
        compatible_tiers=[TierLevel.PROFESSIONAL, TierLevel.ENTERPRISE]
    ),
    AddOnService(
        name="Additional Language",
        description="Add support for an additional language",
        monthly_price=50,
        compatible_tiers=[TierLevel.STARTER, TierLevel.PROFESSIONAL]
    ),
]


# ==================== PRICING COMPARISONS ====================

def get_value_comparison() -> Dict:
    """
    Return value comparison for sales conversations.
    Anchored against local employee costs (Colombian market).
    """
    return {
        "local_employee_comparison": {
            "receptionist_monthly_salary_cop": 1_800_000,  # ~$450 USD
            "receptionist_monthly_salary_usd": 450,
            "working_hours_per_month": 176,  # 44 hrs/week
            "coverage": "business_hours_only",
            "languages": 1,
            "sick_days": "yes",
            "vacation": "15_days_year",
            "social_security": "additional_40_percent"
        },
        "machinemind_comparison": {
            "starter_monthly_usd": 290,
            "coverage": "24/7/365",
            "languages": 2,
            "response_time": "instant",
            "sick_days": "never",
            "vacation": "never",
            "learns_and_improves": True,
            "builds_guest_intelligence": True
        },
        "key_points": [
            "Less than 65% cost of a single employee",
            "24/7 coverage vs 8-hour shifts",
            "Instant response vs human delays", 
            "Never calls in sick or takes vacation",
            "Speaks multiple languages fluently",
            "Builds permanent guest intelligence (Genome)",
            "Scales to unlimited conversations"
        ],
        "roi_calculation": {
            "average_booking_value_usd": 350,
            "inquiries_captured_per_month": 50,
            "conversion_rate": 0.25,
            "monthly_revenue_from_captured": 4375,  # 50 * 0.25 * 350
            "starter_cost": 290,
            "roi_percentage": 1409  # ((4375-290)/290)*100
        }
    }


def get_tier(level: TierLevel) -> PricingTier:
    """Get tier by level"""
    tiers = {
        TierLevel.STARTER: STARTER_TIER,
        TierLevel.PROFESSIONAL: PROFESSIONAL_TIER,
        TierLevel.ENTERPRISE: ENTERPRISE_TIER
    }
    return tiers[level]


def get_all_tiers() -> List[PricingTier]:
    """Get all pricing tiers"""
    return [STARTER_TIER, PROFESSIONAL_TIER, ENTERPRISE_TIER]


def get_tier_comparison_table() -> List[Dict]:
    """Generate comparison table for sales materials"""
    features = [
        ("24/7 WhatsApp Response", True, True, True),
        ("Response Time SLA", "< 30s", "< 15s", "< 10s"),
        ("Monthly Conversations", "500", "2,000", "Unlimited"),
        ("Channels", "WhatsApp", "WhatsApp, IG, Email", "All 5"),
        ("Languages", "2", "3", "5"),
        ("Basic Preference Tracking", True, True, True),
        ("Full Genome Profiles", False, True, True),
        ("Returning Guest Recognition", False, True, True),
        ("VIP Identification", False, True, True),
        ("Predictive Preferences", False, False, True),
        ("Cross-Property Intelligence", False, False, True),
        ("Intelligence Reports", False, "Monthly", "Weekly"),
        ("Custom Collection Hooks", False, False, True),
        ("API Access", False, False, True),
        ("White-Label Dashboard", False, False, True),
        ("Dedicated Account Manager", False, False, True),
    ]
    
    return [
        {
            "feature": f[0],
            "starter": f[1],
            "professional": f[2],
            "enterprise": f[3]
        }
        for f in features
    ]
