"""
GENOME PROTOCOL™ - Signal Extraction Engine
=============================================
The intelligence layer that extracts behavioral signals from
conversations and updates profiles in real-time.
"""

import re
import json
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass

from .models import (
    GenomeProfile, SignalCapture, ConfidenceLevel, CollectionMechanism,
    Channel, DecisionDriver, RiskTolerance
)
from .database import GenomeDatabase, get_database


@dataclass
class ExtractionResult:
    """Result of signal extraction from a message"""
    signals: List[SignalCapture]
    inferred_intent: str
    sentiment: str
    suggested_responses: List[str]
    collection_opportunities: List[Dict]


class GenomeEngine:
    """
    Core intelligence engine for the Genome Protocol.
    Extracts signals from conversations and updates profiles.
    """
    
    def __init__(self, db: Optional[GenomeDatabase] = None):
        self.db = db or get_database()
        
        # Signal extraction patterns
        self.patterns = self._load_extraction_patterns()
        
        # Response time buckets (seconds)
        self.response_time_buckets = {
            "instant": (0, 60),
            "quick": (60, 300),
            "moderate": (300, 1800),
            "slow": (1800, 7200),
            "delayed": (7200, float('inf'))
        }
    
    def _load_extraction_patterns(self) -> Dict:
        """Load signal extraction patterns"""
        return {
            # Dietary signals
            "dietary": {
                "vegetarian": [r'\b(vegetarian|vegetariano|no meat|sin carne)\b', 0.9],
                "vegan": [r'\b(vegan|vegano|plant.?based)\b', 0.95],
                "gluten_free": [r'\b(gluten.?free|sin gluten|celiac|celiaco)\b', 0.95],
                "allergies": [r'\b(allerg|alergi|alergy).*(nut|peanut|shellfish|dairy|lactose|maní|nuez|mariscos|lácteos)\b', 0.95],
                "halal": [r'\b(halal)\b', 0.95],
                "kosher": [r'\b(kosher)\b', 0.95],
            },
            
            # Time preferences
            "chronotype": {
                "early_bird": [r'\b(early|temprano|madrugador|morning person|mañanero|6am|7am|antes de las 8)\b', 0.7],
                "night_owl": [r'\b(late|night|noche|tarde|nocturno|after 10|después de las 10)\b', 0.7],
            },
            
            # Group indicators
            "group_type": {
                "solo": [r'\b(just me|solo yo|alone|I\'m alone|viajo solo|traveling alone)\b', 0.85],
                "couple": [r'\b(my (wife|husband|partner|girlfriend|boyfriend)|mi (esposa|esposo|pareja|novia|novio)|we\'re a couple|somos pareja|anniversary|aniversario)\b', 0.85],
                "family": [r'\b(kids|children|family|niños|hijos|familia|with our children|con nuestros hijos)\b', 0.9],
                "business": [r'\b(business|trabajo|colleagues|colegas|conference|conferencia|meeting|reunión)\b', 0.8],
                "friends": [r'\b(friends|amigos|group of|grupo de|bachelor|despedida)\b', 0.8],
            },
            
            # Occasion indicators
            "occasion": {
                "anniversary": [r'\b(anniversary|aniversario)\b', 0.95],
                "birthday": [r'\b(birthday|cumpleaños|bday)\b', 0.95],
                "honeymoon": [r'\b(honeymoon|luna de miel)\b', 0.95],
                "proposal": [r'\b(propos|engagement|compromi|pedir matrimonio)\b', 0.9],
                "celebration": [r'\b(celebrat|celebra|special occasion|ocasión especial)\b', 0.7],
            },
            
            # Budget signals
            "budget": {
                "budget_conscious": [r'\b(budget|cheap|affordable|economic|barato|económico|mejor precio|best price)\b', 0.7],
                "mid_range": [r'\b(reasonable|good value|valor|razonable)\b', 0.6],
                "luxury": [r'\b(luxury|premium|best|finest|lujo|premium|el mejor|finest|exclusive)\b', 0.75],
                "price_insensitive": [r'\b(don\'t care about price|price doesn\'t matter|money is no object|no importa el precio)\b', 0.9],
            },
            
            # Space preferences
            "space": {
                "quiet": [r'\b(quiet|tranquil|peaceful|calm|tranquilo|silencio|paz)\b', 0.8],
                "energetic": [r'\b(lively|energetic|busy|animado|movido|activity)\b', 0.8],
                "private": [r'\b(private|secluded|intimate|privado|íntimo|apartado)\b', 0.85],
            },
            
            # View/location preferences
            "location_pref": {
                "ocean_view": [r'\b(ocean|sea|beach|mar|playa|vista al mar)\b', 0.8],
                "city_view": [r'\b(city view|skyline|vista ciudad)\b', 0.8],
                "pool_view": [r'\b(pool|piscina)\b', 0.7],
                "high_floor": [r'\b(high floor|piso alto|top floor|upper)\b', 0.85],
            },
            
            # Decision style signals
            "decision_style": {
                "instant": [r'\b(right now|immediately|asap|ya|ahora mismo|urgente|inmediatamente)\b', 0.8],
                "deliberate": [r'\b(thinking|consider|need to check|pensar|consultar|let me think)\b', 0.7],
                "researcher": [r'\b(reviews|compare|options|alternatives|reseñas|comparar|opciones)\b', 0.75],
            },
            
            # Communication preferences
            "communication": {
                "brief": [r'^.{1,50}$', 0.6],  # Short messages
                "detailed": [r'^.{200,}$', 0.7],  # Long messages
                "emoji_user": [r'[😀-🙏🌀-🗿🚀-🛿🤀-🧿]+', 0.8],
            }
        }
    
    def process_message(self, 
                       property_id: str,
                       guest_identifier: str,
                       message: str,
                       channel: str = "whatsapp",
                       direction: str = "inbound",
                       response_time_seconds: Optional[int] = None,
                       interaction_id: Optional[str] = None) -> Tuple[GenomeProfile, ExtractionResult]:
        """
        Process an incoming or outgoing message and extract signals.
        
        Args:
            property_id: The client property ID
            guest_identifier: WhatsApp number, email, or phone
            message: The message content
            channel: Communication channel
            direction: 'inbound' from guest, 'outbound' from system
            response_time_seconds: Time taken to respond (if outbound)
            interaction_id: Optional interaction ID for tracking
            
        Returns:
            Tuple of (updated GenomeProfile, ExtractionResult)
        """
        import uuid
        
        # Get or create profile
        profile = self.db.get_or_create_profile(property_id, guest_identifier)
        interaction_id = interaction_id or str(uuid.uuid4())
        
        # Extract signals from message content
        signals = self._extract_content_signals(message, interaction_id)
        
        # Extract behavioral signals
        behavioral_signals = self._extract_behavioral_signals(
            message, channel, direction, response_time_seconds, interaction_id
        )
        signals.extend(behavioral_signals)
        
        # Analyze sentiment
        sentiment = self._analyze_sentiment(message)
        
        # Infer intent
        intent = self._infer_intent(message)
        
        # Update profile with signals
        for signal in signals:
            profile.update_signal(signal)
        
        # Update interaction count
        profile.total_interactions += 1
        profile.last_interaction_at = datetime.utcnow()
        
        # Save updates
        self.db.update_profile(profile)
        
        # Log interaction
        self.db.log_interaction(
            genome_id=profile.genome_id,
            property_id=property_id,
            channel=channel,
            direction=direction,
            message_content=message,
            response_time_seconds=response_time_seconds,
            sentiment=sentiment,
            intent=intent,
            signals_extracted=[s.to_dict() for s in signals]
        )
        
        # Log signals
        for signal in signals:
            self.db.log_signal(signal)
        
        # Generate collection opportunities
        opportunities = self._identify_collection_opportunities(profile, intent)
        
        # Generate suggested responses based on profile
        suggested_responses = self._generate_response_suggestions(profile, intent, message)
        
        return profile, ExtractionResult(
            signals=signals,
            inferred_intent=intent,
            sentiment=sentiment,
            suggested_responses=suggested_responses,
            collection_opportunities=opportunities
        )
    
    def _extract_content_signals(self, message: str, interaction_id: str) -> List[SignalCapture]:
        """Extract signals from message content using patterns"""
        signals = []
        message_lower = message.lower()
        
        for category, patterns in self.patterns.items():
            for signal_type, (pattern, base_confidence) in patterns.items():
                if re.search(pattern, message_lower, re.IGNORECASE):
                    # Map to profile field
                    field, value = self._map_signal_to_field(category, signal_type)
                    if field:
                        signals.append(SignalCapture(
                            field=field,
                            value=value,
                            confidence=ConfidenceLevel.OBSERVED,
                            mechanism=CollectionMechanism.RELIEF_REVEAL,
                            source_interaction_id=interaction_id,
                            raw_input=message[:200]
                        ))
        
        return signals
    
    def _map_signal_to_field(self, category: str, signal_type: str) -> Tuple[Optional[str], Any]:
        """Map extracted signal to profile field path"""
        mappings = {
            # Dietary
            ("dietary", "vegetarian"): ("sensory.dietary_restrictions", "vegetarian"),
            ("dietary", "vegan"): ("sensory.dietary_restrictions", "vegan"),
            ("dietary", "gluten_free"): ("sensory.dietary_restrictions", "gluten_free"),
            ("dietary", "allergies"): ("sensory.dietary_restrictions", "allergies"),
            ("dietary", "halal"): ("sensory.dietary_restrictions", "halal"),
            ("dietary", "kosher"): ("sensory.dietary_restrictions", "kosher"),
            
            # Chronotype
            ("chronotype", "early_bird"): ("sensory.chronotype", "early_bird"),
            ("chronotype", "night_owl"): ("sensory.chronotype", "night_owl"),
            
            # Group
            ("group_type", "solo"): ("relationship.travel_companions", "solo"),
            ("group_type", "couple"): ("relationship.travel_companions", "couple"),
            ("group_type", "family"): ("relationship.travel_companions", "family"),
            ("group_type", "business"): ("relationship.travel_companions", "business"),
            ("group_type", "friends"): ("relationship.travel_companions", "friends"),
            
            # Budget
            ("budget", "budget_conscious"): ("decision.price_sensitivity_index", 80),
            ("budget", "mid_range"): ("decision.price_sensitivity_index", 50),
            ("budget", "luxury"): ("decision.price_sensitivity_index", 20),
            ("budget", "price_insensitive"): ("decision.price_sensitivity_index", 10),
            
            # Space
            ("space", "quiet"): ("sensory.environment_preference", "quiet"),
            ("space", "energetic"): ("sensory.environment_preference", "energetic"),
            ("space", "private"): ("sensory.space_preference", "private"),
            
            # Decision style
            ("decision_style", "instant"): ("decision.speed", "instant"),
            ("decision_style", "deliberate"): ("decision.speed", "deliberate"),
            ("decision_style", "researcher"): ("decision.speed", "researcher"),
        }
        
        return mappings.get((category, signal_type), (None, None))
    
    def _extract_behavioral_signals(self, message: str, channel: str, 
                                   direction: str, response_time: Optional[int],
                                   interaction_id: str) -> List[SignalCapture]:
        """Extract behavioral signals from message metadata"""
        signals = []
        
        # Message length signal
        msg_len = len(message)
        if msg_len < 50:
            response_style = "brief"
        elif msg_len > 200:
            response_style = "detailed"
        else:
            response_style = "moderate"
        
        signals.append(SignalCapture(
            field="communication.response_style",
            value=response_style,
            confidence=ConfidenceLevel.OBSERVED,
            mechanism=CollectionMechanism.CONCIERGE_CAPTURE,
            source_interaction_id=interaction_id
        ))
        
        # Emoji usage
        emoji_pattern = r'[😀-🙏🌀-🗿🚀-🛿🤀-🧿]'
        emoji_count = len(re.findall(emoji_pattern, message))
        if emoji_count == 0:
            emoji_usage = "none"
        elif emoji_count <= 2:
            emoji_usage = "minimal"
        else:
            emoji_usage = "frequent"
        
        signals.append(SignalCapture(
            field="communication.emoji_usage",
            value=emoji_usage,
            confidence=ConfidenceLevel.OBSERVED,
            mechanism=CollectionMechanism.CONCIERGE_CAPTURE,
            source_interaction_id=interaction_id
        ))
        
        # Response time (if available and inbound)
        if response_time and direction == "inbound":
            signals.append(SignalCapture(
                field="communication.avg_response_time_seconds",
                value=response_time,
                confidence=ConfidenceLevel.OBSERVED,
                mechanism=CollectionMechanism.CONCIERGE_CAPTURE,
                source_interaction_id=interaction_id
            ))
        
        # Channel preference (when they reach out)
        if direction == "inbound":
            try:
                channel_enum = Channel(channel)
                signals.append(SignalCapture(
                    field="communication.preferred_channel",
                    value=channel_enum,
                    confidence=ConfidenceLevel.OBSERVED,
                    mechanism=CollectionMechanism.CONCIERGE_CAPTURE,
                    source_interaction_id=interaction_id
                ))
            except ValueError:
                pass
        
        # Question asking behavior
        question_count = message.count('?')
        asks_questions = question_count > 0
        signals.append(SignalCapture(
            field="communication.asks_questions",
            value=asks_questions,
            confidence=ConfidenceLevel.OBSERVED,
            mechanism=CollectionMechanism.CONCIERGE_CAPTURE,
            source_interaction_id=interaction_id
        ))
        
        return signals
    
    def _analyze_sentiment(self, message: str) -> str:
        """Simple sentiment analysis"""
        positive_words = [
            'great', 'excellent', 'perfect', 'love', 'amazing', 'wonderful',
            'fantastic', 'beautiful', 'thank', 'appreciate', 'happy',
            'genial', 'excelente', 'perfecto', 'amor', 'increíble', 'maravilloso',
            'fantástico', 'hermoso', 'gracias', 'feliz'
        ]
        negative_words = [
            'bad', 'terrible', 'awful', 'hate', 'disappointed', 'angry',
            'frustrated', 'problem', 'issue', 'complaint', 'wrong',
            'malo', 'terrible', 'horrible', 'odio', 'decepcionado', 'enojado',
            'frustrado', 'problema', 'queja', 'mal'
        ]
        
        message_lower = message.lower()
        positive_count = sum(1 for word in positive_words if word in message_lower)
        negative_count = sum(1 for word in negative_words if word in message_lower)
        
        if positive_count > negative_count + 1:
            return "positive"
        elif negative_count > positive_count + 1:
            return "negative"
        return "neutral"
    
    def _infer_intent(self, message: str) -> str:
        """Infer the user's intent from the message"""
        message_lower = message.lower()
        
        intent_patterns = {
            "booking_inquiry": [
                r'\b(book|reserve|availability|disponib|reserv|check.?in|check.?out)\b',
                r'\b(room|habitación|suite|villa)\b.*\b(available|disponible)\b',
            ],
            "price_inquiry": [
                r'\b(price|cost|rate|precio|costo|tarifa|cuánto|how much)\b',
            ],
            "amenity_question": [
                r'\b(pool|spa|gym|restaurant|wifi|parking|piscina|gimnasio)\b',
            ],
            "modification_request": [
                r'\b(change|modify|cancel|cambi|modific|cancel)\b',
            ],
            "concierge_request": [
                r'\b(recommend|suggest|tour|transport|taxi|recomend|suger|tour|transporte)\b',
            ],
            "complaint": [
                r'\b(problem|issue|complaint|wrong|disappointed|problema|queja|mal)\b',
            ],
            "greeting": [
                r'^(hi|hello|hey|hola|buenos días|buenas tardes|buenas noches)',
            ],
            "confirmation": [
                r'\b(yes|ok|sure|perfect|confirm|sí|ok|perfecto|confirma)\b',
            ],
            "question": [
                r'\?$',
            ],
        }
        
        for intent, patterns in intent_patterns.items():
            for pattern in patterns:
                if re.search(pattern, message_lower, re.IGNORECASE):
                    return intent
        
        return "general_inquiry"
    
    def _identify_collection_opportunities(self, profile: GenomeProfile, 
                                          intent: str) -> List[Dict]:
        """Identify opportunities to collect more data naturally"""
        opportunities = []
        
        # Based on missing profile data
        if not profile.sensory.dietary_restrictions:
            opportunities.append({
                "mechanism": "relief_reveal",
                "target_field": "sensory.dietary_restrictions",
                "trigger": "restaurant_or_food_context",
                "question": "Any allergies or dietary preferences I should note for the kitchen?"
            })
        
        if profile.relationship.travel_companions == "unknown":
            opportunities.append({
                "mechanism": "preference_cascade",
                "target_field": "relationship.travel_companions",
                "trigger": "booking_context",
                "question": "Will you be traveling solo, or should I plan for others?"
            })
        
        if profile.sensory.chronotype == "moderate":
            opportunities.append({
                "mechanism": "anticipation_engine",
                "target_field": "sensory.chronotype",
                "trigger": "activity_planning",
                "question": "Would you prefer morning activities or are you more of a night person?"
            })
        
        # Based on intent
        if intent == "booking_inquiry" and profile.decision.typical_lead_time_days is None:
            opportunities.append({
                "mechanism": "concierge_capture",
                "target_field": "decision.typical_lead_time_days",
                "trigger": "date_selection",
                "question": "When are you looking to visit? Same-day or planning ahead?"
            })
        
        if intent == "concierge_request":
            opportunities.append({
                "mechanism": "concierge_capture",
                "target_field": "decision.primary_driver",
                "trigger": "recommendation",
                "question": "Here are three options—which one catches your eye?"
            })
        
        return opportunities[:3]  # Return top 3 opportunities
    
    def _generate_response_suggestions(self, profile: GenomeProfile, 
                                       intent: str, message: str) -> List[str]:
        """Generate personalized response suggestions"""
        suggestions = []
        
        # Personalize greeting
        if profile.first_name:
            greeting = f"Hi {profile.first_name}! "
        elif profile.name:
            greeting = f"Hello {profile.name.split()[0]}! "
        else:
            greeting = "Hello! "
        
        # Add emoji if they use them
        if profile.communication.emoji_usage in ["minimal", "frequent"]:
            greeting += "👋 "
        
        # Generate intent-specific responses
        if intent == "booking_inquiry":
            suggestions.append(
                f"{greeting}I'd love to help you book. What dates are you considering?"
            )
            if profile.decision.speed == "instant":
                suggestions.append(
                    f"{greeting}Let me check availability right now for you."
                )
        
        elif intent == "price_inquiry":
            if profile.decision.price_sensitivity_index > 60:
                suggestions.append(
                    f"{greeting}Great question! Let me show you our best value options."
                )
            else:
                suggestions.append(
                    f"{greeting}Here are our options, including our premium experiences."
                )
        
        elif intent == "concierge_request":
            suggestions.append(
                f"{greeting}I can definitely help with that. Let me find the best options for you."
            )
            # Use preference cascade mechanism
            suggestions.append(
                f"{greeting}I found three great options—which one catches your eye?"
            )
        
        elif intent == "greeting":
            suggestions.append(
                f"{greeting}How can I help you today?"
            )
        
        return suggestions


class GenomeCollectionHooks:
    """
    Pre-built collection hooks to embed in conversation flows.
    These are the "zero-form" collection mechanisms.
    """
    
    @staticmethod
    def preference_cascade_options() -> Dict[str, List[Dict]]:
        """Return ready-to-use preference cascade options"""
        return {
            "booking_flow": [
                {
                    "id": "arrival_preference",
                    "question": "Would you like to arrive early or keep the standard 3pm check-in?",
                    "options": ["early", "standard"],
                    "signal_field": "sensory.chronotype",
                    "signal_map": {"early": "early_bird", "standard": "moderate"}
                },
                {
                    "id": "communication_preference",
                    "question": "Best way to send your confirmation—WhatsApp or email?",
                    "options": ["whatsapp", "email"],
                    "signal_field": "communication.preferred_channel",
                    "signal_map": {"whatsapp": Channel.WHATSAPP, "email": Channel.EMAIL}
                },
                {
                    "id": "occasion_check",
                    "question": "Any special occasion I should note for the team?",
                    "options": ["free_text"],
                    "signal_field": "relationship.occasion_types",
                    "signal_map": "parse_occasion"
                }
            ],
            "restaurant_flow": [
                {
                    "id": "seating_preference",
                    "question": "I'd guess you'd prefer the terrace with the view—am I right?",
                    "options": ["yes", "no"],
                    "signal_field": "sensory.space_preference",
                    "signal_map": {"yes": "open", "no": "follow_up_needed"}
                },
                {
                    "id": "dietary_check",
                    "question": "Any allergies or preferences I should flag for the chef?",
                    "options": ["free_text", "none"],
                    "signal_field": "sensory.dietary_restrictions",
                    "signal_map": "parse_dietary"
                },
                {
                    "id": "timing_preference",
                    "question": "Sunset dinner around 7pm, or later evening?",
                    "options": ["early", "late"],
                    "signal_field": "sensory.chronotype",
                    "signal_map": {"early": "early_bird", "late": "night_owl"}
                }
            ],
            "concierge_flow": [
                {
                    "id": "budget_reveal",
                    "question": "Here are three options—which one catches your eye first?",
                    "options": ["option_a", "option_b", "option_c"],
                    "signal_field": "decision.price_sensitivity_index",
                    "signal_map": {"option_a": 80, "option_b": 50, "option_c": 20}
                },
                {
                    "id": "activity_preference",
                    "question": "Adventure or relaxation for this one?",
                    "options": ["adventure", "relaxation"],
                    "signal_field": "decision.risk_tolerance",
                    "signal_map": {"adventure": RiskTolerance.ADVENTUROUS, "relaxation": RiskTolerance.CONSERVATIVE}
                },
                {
                    "id": "group_check",
                    "question": "Just you, or should I plan for others?",
                    "options": ["solo", "group"],
                    "signal_field": "relationship.typical_group_size",
                    "signal_map": {"solo": 1, "group": "ask_number"}
                }
            ]
        }
    
    @staticmethod
    def anticipation_engine_predictions(profile: GenomeProfile) -> List[Dict]:
        """Generate predictions to confirm/deny based on profile"""
        predictions = []
        
        # Space preference prediction
        if profile.sensory.environment_preference == "quiet":
            predictions.append({
                "prediction": "I'm guessing you'd prefer the quieter table away from the main area—am I reading that right?",
                "signal_field": "sensory.environment_preference",
                "correct_value": "quiet",
                "confidence_boost": 0.15
            })
        
        # Timing prediction
        if profile.sensory.chronotype == "early_bird":
            predictions.append({
                "prediction": "Based on your style, I'd suggest the morning excursion rather than afternoon—sound good?",
                "signal_field": "sensory.chronotype",
                "correct_value": "early_bird",
                "confidence_boost": 0.1
            })
        
        # Budget prediction
        if profile.decision.price_sensitivity_index < 40:
            predictions.append({
                "prediction": "I think you'd really appreciate our premium option—it includes [benefit]. Worth showing you?",
                "signal_field": "decision.upgrade_propensity",
                "correct_value": 70,
                "confidence_boost": 0.2
            })
        
        return predictions
    
    @staticmethod
    def mirror_moment_profile(profile: GenomeProfile) -> Dict:
        """Generate a 'mirror moment' profile summary for guest to review/correct"""
        summary = {
            "intro": "Based on our conversations, here's what I've learned about your preferences...",
            "sections": []
        }
        
        # Communication style
        if profile.communication.response_style != "moderate":
            summary["sections"].append({
                "category": "Communication",
                "observation": f"You prefer {profile.communication.response_style} messages",
                "editable": True,
                "field": "communication.response_style"
            })
        
        # Travel style
        if profile.relationship.travel_companions != "unknown":
            summary["sections"].append({
                "category": "Travel Style",
                "observation": f"Usually traveling: {profile.relationship.travel_companions}",
                "editable": True,
                "field": "relationship.travel_companions"
            })
        
        # Dietary
        if profile.sensory.dietary_restrictions:
            summary["sections"].append({
                "category": "Dietary",
                "observation": f"Dietary notes: {', '.join(profile.sensory.dietary_restrictions)}",
                "editable": True,
                "field": "sensory.dietary_restrictions"
            })
        
        # Preferences
        if profile.sensory.environment_preference != "ambient":
            summary["sections"].append({
                "category": "Atmosphere",
                "observation": f"You prefer {profile.sensory.environment_preference} environments",
                "editable": True,
                "field": "sensory.environment_preference"
            })
        
        summary["outro"] = "Let me know if any of this needs updating!"
        
        return summary
