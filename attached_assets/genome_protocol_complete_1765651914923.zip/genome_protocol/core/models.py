"""
GENOME PROTOCOL™ - Core Data Models
MachineMind AI Automation Agency
====================================

The DNA schema for building complete customer intelligence through
service interactions, not interrogation.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime
from enum import Enum
import uuid
import json


class ConfidenceLevel(Enum):
    """How confident are we in this data point?"""
    DECLARED = 1.0       # They told us directly
    CONFIRMED = 0.95     # They confirmed our prediction
    OBSERVED = 0.85      # Strong behavioral inference
    INFERRED = 0.65      # Pattern-based inference
    ASSUMED = 0.35       # Demographic/default assumption
    UNKNOWN = 0.0        # No data


class CollectionMechanism(Enum):
    """The six zero-form collection methods"""
    CONCIERGE_CAPTURE = "concierge_capture"       # Choice reveals preference
    RELIEF_REVEAL = "relief_reveal"               # Care context extraction
    PREFERENCE_CASCADE = "preference_cascade"     # Binary micro-choices
    MIRROR_MOMENT = "mirror_moment"               # Profile correction
    ANTICIPATION_ENGINE = "anticipation_engine"   # Predict & confirm
    REWARD_LOOP = "reward_loop"                   # Value demonstration


class Channel(Enum):
    WHATSAPP = "whatsapp"
    EMAIL = "email"
    SMS = "sms"
    PHONE = "phone"
    INSTAGRAM = "instagram"
    WEBSITE_CHAT = "website_chat"


class DecisionDriver(Enum):
    PRICE = "price"
    QUALITY = "quality"
    STATUS = "status"
    CONVENIENCE = "convenience"
    EXPERIENCE = "experience"
    TRUST = "trust"


class RiskTolerance(Enum):
    CONSERVATIVE = "conservative"
    MODERATE = "moderate"
    ADVENTUROUS = "adventurous"


@dataclass
class SignalCapture:
    """A single data point captured from an interaction"""
    field: str
    value: Any
    confidence: ConfidenceLevel
    mechanism: CollectionMechanism
    source_interaction_id: str
    timestamp: datetime = field(default_factory=datetime.utcnow)
    raw_input: Optional[str] = None  # The actual message/choice that revealed this
    
    def to_dict(self) -> dict:
        return {
            "field": self.field,
            "value": self.value,
            "confidence": self.confidence.value,
            "mechanism": self.mechanism.value,
            "source": self.source_interaction_id,
            "timestamp": self.timestamp.isoformat(),
            "raw_input": self.raw_input
        }


@dataclass
class CommunicationDNA:
    """How this person prefers to communicate"""
    preferred_channel: Channel = Channel.WHATSAPP
    channel_confidence: float = 0.0
    
    frequency_preference: str = "moderate"  # minimal|moderate|engaged
    tone_preference: str = "casual"         # formal|casual|playful
    best_contact_time: str = "afternoon"    # morning|afternoon|evening|night
    
    response_style: str = "moderate"        # brief|moderate|detailed
    emoji_usage: str = "minimal"            # none|minimal|frequent
    language: str = "es"                    # Primary language
    formality_index: int = 50               # 0=very casual, 100=very formal
    
    # Behavioral observations
    avg_response_time_seconds: Optional[int] = None
    typical_message_length: Optional[int] = None
    asks_questions: bool = True
    
    def to_dict(self) -> dict:
        return {
            "preferred_channel": self.preferred_channel.value,
            "channel_confidence": self.channel_confidence,
            "frequency_preference": self.frequency_preference,
            "tone_preference": self.tone_preference,
            "best_contact_time": self.best_contact_time,
            "response_style": self.response_style,
            "emoji_usage": self.emoji_usage,
            "language": self.language,
            "formality_index": self.formality_index,
            "avg_response_time_seconds": self.avg_response_time_seconds,
            "typical_message_length": self.typical_message_length,
            "asks_questions": self.asks_questions
        }


@dataclass
class DecisionDNA:
    """How this person makes decisions"""
    speed: str = "moderate"                 # instant|moderate|deliberate|researcher
    primary_driver: DecisionDriver = DecisionDriver.EXPERIENCE
    secondary_driver: Optional[DecisionDriver] = None
    risk_tolerance: RiskTolerance = RiskTolerance.MODERATE
    
    # Price behavior
    price_sensitivity_index: int = 50       # 0=price insensitive, 100=very sensitive
    upgrade_propensity: int = 50            # 0=never upgrades, 100=always upgrades
    discount_responsive: bool = False        # Do they respond to deals?
    
    # Booking behavior  
    typical_lead_time_days: Optional[int] = None
    modification_frequency: str = "rarely"  # never|rarely|sometimes|often
    cancellation_rate: float = 0.0
    
    # Trust signals
    needs_social_proof: bool = False
    asks_for_references: bool = False
    research_depth: str = "moderate"        # minimal|moderate|extensive
    
    def to_dict(self) -> dict:
        return {
            "speed": self.speed,
            "primary_driver": self.primary_driver.value,
            "secondary_driver": self.secondary_driver.value if self.secondary_driver else None,
            "risk_tolerance": self.risk_tolerance.value,
            "price_sensitivity_index": self.price_sensitivity_index,
            "upgrade_propensity": self.upgrade_propensity,
            "discount_responsive": self.discount_responsive,
            "typical_lead_time_days": self.typical_lead_time_days,
            "modification_frequency": self.modification_frequency,
            "cancellation_rate": self.cancellation_rate,
            "needs_social_proof": self.needs_social_proof,
            "asks_for_references": self.asks_for_references,
            "research_depth": self.research_depth
        }


@dataclass
class SensoryDNA:
    """Environmental and sensory preferences (hospitality gold)"""
    # Space
    environment_preference: str = "ambient"  # quiet|ambient|energetic
    space_preference: str = "open"           # intimate|open|private
    crowd_tolerance: str = "moderate"        # low|moderate|high
    
    # Climate
    temperature_preference: str = "warm"     # cool|moderate|warm
    lighting_preference: str = "natural"     # bright|dim|natural
    
    # Timing
    chronotype: str = "moderate"             # early_bird|moderate|night_owl
    pace_preference: str = "relaxed"         # rushed|moderate|relaxed
    
    # Food & Beverage
    dietary_restrictions: List[str] = field(default_factory=list)
    cuisine_preferences: List[str] = field(default_factory=list)
    alcohol_preference: str = "unknown"      # none|light|moderate|enthusiast
    
    # Hospitality specific
    room_preferences: List[str] = field(default_factory=list)  # high_floor, ocean_view, etc.
    amenity_priorities: List[str] = field(default_factory=list)  # pool, gym, spa, etc.
    
    def to_dict(self) -> dict:
        return {
            "environment_preference": self.environment_preference,
            "space_preference": self.space_preference,
            "crowd_tolerance": self.crowd_tolerance,
            "temperature_preference": self.temperature_preference,
            "lighting_preference": self.lighting_preference,
            "chronotype": self.chronotype,
            "pace_preference": self.pace_preference,
            "dietary_restrictions": self.dietary_restrictions,
            "cuisine_preferences": self.cuisine_preferences,
            "alcohol_preference": self.alcohol_preference,
            "room_preferences": self.room_preferences,
            "amenity_priorities": self.amenity_priorities
        }


@dataclass  
class EmotionalFingerprint:
    """Emotional patterns and triggers"""
    stress_indicators: List[str] = field(default_factory=list)
    joy_triggers: List[str] = field(default_factory=list)
    trust_signals: List[str] = field(default_factory=list)
    anxiety_patterns: List[str] = field(default_factory=list)
    
    # Sentiment tracking
    baseline_sentiment: str = "neutral"      # negative|neutral|positive|enthusiastic
    sentiment_volatility: str = "stable"     # stable|moderate|volatile
    
    # Service recovery insights
    complaint_style: str = "unknown"         # silent|direct|escalating
    recovery_responsiveness: str = "unknown" # easy|moderate|difficult
    
    def to_dict(self) -> dict:
        return {
            "stress_indicators": self.stress_indicators,
            "joy_triggers": self.joy_triggers,
            "trust_signals": self.trust_signals,
            "anxiety_patterns": self.anxiety_patterns,
            "baseline_sentiment": self.baseline_sentiment,
            "sentiment_volatility": self.sentiment_volatility,
            "complaint_style": self.complaint_style,
            "recovery_responsiveness": self.recovery_responsiveness
        }


@dataclass
class RelationshipContext:
    """Who they travel/dine/experience with"""
    typical_group_size: int = 1
    travel_companions: str = "unknown"       # solo|couple|family|friends|business
    
    # Group dynamics
    is_decision_maker: bool = True
    influence_position: str = "independent"  # leader|influencer|follower|independent
    
    # Known connections
    known_companions: List[Dict] = field(default_factory=list)  # [{name, relationship}]
    
    # Occasion patterns
    occasion_types: List[str] = field(default_factory=list)  # anniversary, birthday, business, etc.
    celebration_style: str = "unknown"       # private|shared|public
    
    def to_dict(self) -> dict:
        return {
            "typical_group_size": self.typical_group_size,
            "travel_companions": self.travel_companions,
            "is_decision_maker": self.is_decision_maker,
            "influence_position": self.influence_position,
            "known_companions": self.known_companions,
            "occasion_types": self.occasion_types,
            "celebration_style": self.celebration_style
        }


@dataclass
class ContextMemory:
    """Accumulated knowledge from interactions"""
    significant_dates: List[Dict] = field(default_factory=list)  # [{date, occasion, notes}]
    past_experiences: List[Dict] = field(default_factory=list)   # [{property, date, highlights, issues}]
    stated_preferences: List[Dict] = field(default_factory=list) # [{preference, context, timestamp}]
    observed_contradictions: List[Dict] = field(default_factory=list)  # [{stated, observed, context}]
    
    # Conversation memory
    topics_discussed: List[str] = field(default_factory=list)
    requests_made: List[Dict] = field(default_factory=list)
    feedback_given: List[Dict] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        return {
            "significant_dates": self.significant_dates,
            "past_experiences": self.past_experiences,
            "stated_preferences": self.stated_preferences,
            "observed_contradictions": self.observed_contradictions,
            "topics_discussed": self.topics_discussed,
            "requests_made": self.requests_made,
            "feedback_given": self.feedback_given
        }


@dataclass
class GenomeProfile:
    """
    The complete customer DNA profile.
    Built through service interactions, not interrogation.
    """
    # Core identifiers
    genome_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    property_id: str = ""                    # Which client's guest
    external_ids: Dict[str, str] = field(default_factory=dict)  # {system: id}
    
    # Identity layer (progressively revealed)
    name: Optional[str] = None
    first_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    whatsapp: Optional[str] = None
    instagram: Optional[str] = None
    
    # Demographics (inferred or declared)
    country: Optional[str] = None
    city: Optional[str] = None
    language: str = "es"
    estimated_age_range: Optional[str] = None
    
    # The DNA strands
    communication: CommunicationDNA = field(default_factory=CommunicationDNA)
    decision: DecisionDNA = field(default_factory=DecisionDNA)
    sensory: SensoryDNA = field(default_factory=SensoryDNA)
    emotional: EmotionalFingerprint = field(default_factory=EmotionalFingerprint)
    relationship: RelationshipContext = field(default_factory=RelationshipContext)
    memory: ContextMemory = field(default_factory=ContextMemory)
    
    # Profile meta
    profile_completeness: float = 0.0
    overall_confidence: float = 0.0
    total_interactions: int = 0
    total_signals_captured: int = 0
    
    # Timestamps
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    last_interaction_at: Optional[datetime] = None
    
    # Signal history
    signal_log: List[SignalCapture] = field(default_factory=list)
    confidence_scores: Dict[str, float] = field(default_factory=dict)
    
    # Value metrics
    lifetime_value: float = 0.0
    predicted_ltv: float = 0.0
    engagement_score: int = 50
    
    def update_signal(self, signal: SignalCapture) -> bool:
        """
        Update profile with new signal if confidence is higher.
        Returns True if update was applied.
        """
        current_confidence = self.confidence_scores.get(signal.field, 0.0)
        
        if signal.confidence.value > current_confidence:
            # Parse the field path and update
            self._set_nested_value(signal.field, signal.value)
            self.confidence_scores[signal.field] = signal.confidence.value
            self.signal_log.append(signal)
            self.total_signals_captured += 1
            self.updated_at = datetime.utcnow()
            self._recalculate_completeness()
            return True
        return False
    
    def _set_nested_value(self, field_path: str, value: Any):
        """Set value on nested dataclass attributes"""
        parts = field_path.split(".")
        obj = self
        
        for part in parts[:-1]:
            obj = getattr(obj, part)
        
        setattr(obj, parts[-1], value)
    
    def _recalculate_completeness(self):
        """Calculate profile completeness percentage"""
        total_fields = 0
        filled_fields = 0
        
        # Check identity fields
        identity_fields = ['name', 'phone', 'email', 'country']
        for f in identity_fields:
            total_fields += 1
            if getattr(self, f):
                filled_fields += 1
        
        # Check DNA strand completeness
        dna_strands = ['communication', 'decision', 'sensory', 'emotional', 'relationship']
        for strand in dna_strands:
            strand_obj = getattr(self, strand)
            strand_dict = strand_obj.to_dict()
            for key, value in strand_dict.items():
                total_fields += 1
                if value and value != "unknown" and value != 0 and value != []:
                    filled_fields += 1
        
        self.profile_completeness = (filled_fields / total_fields) * 100 if total_fields > 0 else 0
        
        # Calculate overall confidence
        if self.confidence_scores:
            self.overall_confidence = sum(self.confidence_scores.values()) / len(self.confidence_scores)
    
    def get_personalization_insights(self) -> Dict[str, Any]:
        """Return actionable insights for personalizing service"""
        insights = {
            "greeting_style": self._get_greeting_style(),
            "communication_tips": self._get_communication_tips(),
            "service_priorities": self._get_service_priorities(),
            "upsell_opportunities": self._get_upsell_opportunities(),
            "risk_factors": self._get_risk_factors(),
            "vip_indicators": self._get_vip_indicators()
        }
        return insights
    
    def _get_greeting_style(self) -> Dict:
        """How to greet this guest"""
        return {
            "formality": "formal" if self.communication.formality_index > 60 else "casual",
            "use_first_name": self.communication.formality_index < 70,
            "include_emoji": self.communication.emoji_usage != "none",
            "language": self.language
        }
    
    def _get_communication_tips(self) -> List[str]:
        """Tips for communicating with this guest"""
        tips = []
        
        if self.communication.response_style == "brief":
            tips.append("Keep messages concise - they prefer brevity")
        elif self.communication.response_style == "detailed":
            tips.append("Provide thorough details - they appreciate completeness")
            
        if self.communication.best_contact_time:
            tips.append(f"Best time to reach: {self.communication.best_contact_time}")
            
        if self.decision.needs_social_proof:
            tips.append("Include reviews/testimonials when making recommendations")
            
        return tips
    
    def _get_service_priorities(self) -> List[str]:
        """What matters most to this guest"""
        priorities = []
        
        if self.decision.primary_driver:
            priorities.append(f"Primary driver: {self.decision.primary_driver.value}")
            
        if self.sensory.dietary_restrictions:
            priorities.append(f"Dietary: {', '.join(self.sensory.dietary_restrictions)}")
            
        if self.sensory.room_preferences:
            priorities.append(f"Room prefs: {', '.join(self.sensory.room_preferences)}")
            
        return priorities
    
    def _get_upsell_opportunities(self) -> List[Dict]:
        """Potential upsell opportunities based on profile"""
        opportunities = []
        
        if self.decision.upgrade_propensity > 60:
            opportunities.append({
                "type": "room_upgrade",
                "confidence": self.decision.upgrade_propensity,
                "approach": "direct_offer"
            })
            
        if self.relationship.occasion_types:
            opportunities.append({
                "type": "occasion_package",
                "occasions": self.relationship.occasion_types,
                "approach": "anticipate_and_suggest"
            })
            
        if self.sensory.amenity_priorities:
            for amenity in self.sensory.amenity_priorities[:2]:
                opportunities.append({
                    "type": f"{amenity}_package",
                    "approach": "bundle_with_stay"
                })
                
        return opportunities
    
    def _get_risk_factors(self) -> List[Dict]:
        """Potential issues to watch for"""
        risks = []
        
        if self.decision.cancellation_rate > 0.2:
            risks.append({
                "type": "cancellation_risk",
                "level": "high" if self.decision.cancellation_rate > 0.4 else "moderate",
                "mitigation": "Consider requiring deposit or flexible rebooking"
            })
            
        if self.decision.modification_frequency == "often":
            risks.append({
                "type": "modification_prone",
                "mitigation": "Confirm details thoroughly before finalizing"
            })
            
        if self.emotional.complaint_style == "escalating":
            risks.append({
                "type": "escalation_risk",
                "mitigation": "Address issues proactively and quickly"
            })
            
        return risks
    
    def _get_vip_indicators(self) -> Dict:
        """VIP status indicators"""
        vip_score = 0
        reasons = []
        
        if self.lifetime_value > 1000:
            vip_score += 30
            reasons.append("High lifetime value")
            
        if self.decision.price_sensitivity_index < 30:
            vip_score += 20
            reasons.append("Price insensitive")
            
        if self.decision.upgrade_propensity > 70:
            vip_score += 15
            reasons.append("Frequent upgrader")
            
        if self.total_interactions > 10:
            vip_score += 15
            reasons.append("Loyal repeat guest")
            
        if self.relationship.influence_position == "leader":
            vip_score += 20
            reasons.append("Group influencer")
            
        return {
            "vip_score": min(vip_score, 100),
            "is_vip": vip_score >= 50,
            "reasons": reasons
        }
    
    def to_dict(self) -> dict:
        """Full profile export"""
        return {
            "genome_id": self.genome_id,
            "property_id": self.property_id,
            "identity": {
                "name": self.name,
                "first_name": self.first_name,
                "phone": self.phone,
                "email": self.email,
                "whatsapp": self.whatsapp,
                "instagram": self.instagram,
                "country": self.country,
                "city": self.city,
                "language": self.language
            },
            "communication_dna": self.communication.to_dict(),
            "decision_dna": self.decision.to_dict(),
            "sensory_dna": self.sensory.to_dict(),
            "emotional_fingerprint": self.emotional.to_dict(),
            "relationship_context": self.relationship.to_dict(),
            "context_memory": self.memory.to_dict(),
            "meta": {
                "profile_completeness": self.profile_completeness,
                "overall_confidence": self.overall_confidence,
                "total_interactions": self.total_interactions,
                "total_signals_captured": self.total_signals_captured,
                "created_at": self.created_at.isoformat(),
                "updated_at": self.updated_at.isoformat(),
                "last_interaction_at": self.last_interaction_at.isoformat() if self.last_interaction_at else None
            },
            "value_metrics": {
                "lifetime_value": self.lifetime_value,
                "predicted_ltv": self.predicted_ltv,
                "engagement_score": self.engagement_score,
                "vip_status": self._get_vip_indicators()
            },
            "personalization": self.get_personalization_insights()
        }
    
    def to_json(self) -> str:
        """JSON export"""
        return json.dumps(self.to_dict(), indent=2, default=str)
