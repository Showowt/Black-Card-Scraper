"""
PROSPECT GENOME™ - B2B Sales Intelligence
==========================================
Apply Genome Protocol to your own sales process.
Build prospect profiles during calls, not after.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum
import uuid
import json


class BuyerType(Enum):
    """Primary buyer psychology archetypes"""
    ANALYTICAL = "analytical"      # Needs data, ROI, proof
    DRIVER = "driver"              # Wants results, speed, control
    EXPRESSIVE = "expressive"      # Relationship-focused, vision-driven
    AMIABLE = "amiable"            # Risk-averse, consensus-seeking


class DecisionAuthority(Enum):
    """Who makes the buying decision"""
    SOLE_DECISION_MAKER = "sole"
    INFLUENCER = "influencer"
    GATEKEEPER = "gatekeeper"
    CHAMPION = "champion"
    ECONOMIC_BUYER = "economic_buyer"
    UNKNOWN = "unknown"


class UrgencyLevel(Enum):
    """How urgent is their need"""
    BLEEDING = "bleeding"          # Critical pain, need solution NOW
    URGENT = "urgent"              # Active problem, timeline pressure
    PLANNING = "planning"          # Future need, exploring options
    BROWSING = "browsing"          # Just looking, no real timeline
    UNKNOWN = "unknown"


class BudgetSignal(Enum):
    """Budget indicators from conversation"""
    PRICE_FIRST = "price_first"            # Asked about price early
    VALUE_FOCUSED = "value_focused"        # Focused on ROI/outcomes
    BUDGET_CONSTRAINED = "budget_constrained"
    BUDGET_FLEXIBLE = "budget_flexible"
    COMPARING_OPTIONS = "comparing"
    UNKNOWN = "unknown"


class ObjectionType(Enum):
    """Common objection categories"""
    PRICE = "price"
    TIMING = "timing"
    AUTHORITY = "authority"
    NEED = "need"
    TRUST = "trust"
    COMPETITOR = "competitor"
    TECHNICAL = "technical"
    CHANGE_RESISTANCE = "change_resistance"


@dataclass
class CallSignal:
    """A signal captured during a sales call"""
    signal_type: str
    value: Any
    timestamp: datetime = field(default_factory=datetime.utcnow)
    context: Optional[str] = None
    confidence: float = 0.8
    
    def to_dict(self) -> dict:
        return {
            "type": self.signal_type,
            "value": self.value if not isinstance(self.value, Enum) else self.value.value,
            "timestamp": self.timestamp.isoformat(),
            "context": self.context,
            "confidence": self.confidence
        }


@dataclass
class PainPoint:
    """A specific pain point identified"""
    description: str
    severity: int = 5  # 1-10 scale
    mentioned_count: int = 1
    emotional_charge: str = "neutral"  # frustrated|anxious|resigned|neutral
    quotes: List[str] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        return {
            "description": self.description,
            "severity": self.severity,
            "mentioned_count": self.mentioned_count,
            "emotional_charge": self.emotional_charge,
            "quotes": self.quotes
        }


@dataclass
class Objection:
    """An objection raised during the call"""
    objection_type: ObjectionType
    statement: str
    addressed: bool = False
    response_that_worked: Optional[str] = None
    still_concern: bool = True
    
    def to_dict(self) -> dict:
        return {
            "type": self.objection_type.value,
            "statement": self.statement,
            "addressed": self.addressed,
            "response_that_worked": self.response_that_worked,
            "still_concern": self.still_concern
        }


@dataclass
class CompetitorMention:
    """Competitor mentioned during call"""
    name: str
    context: str  # How they mentioned it
    sentiment: str = "neutral"  # positive|negative|neutral
    currently_using: bool = False
    considering: bool = False


@dataclass
class DecisionDNA:
    """How this prospect makes decisions"""
    buyer_type: BuyerType = BuyerType.ANALYTICAL
    authority: DecisionAuthority = DecisionAuthority.UNKNOWN
    
    # Decision process
    decision_speed: str = "moderate"  # instant|fast|moderate|slow|committee
    needs_consensus: bool = False
    other_stakeholders: List[str] = field(default_factory=list)
    
    # What they need to decide
    needs_case_study: bool = False
    needs_demo: bool = False
    needs_proposal: bool = False
    needs_references: bool = False
    needs_trial: bool = False
    needs_internal_approval: bool = False
    
    # Risk profile
    risk_tolerance: str = "moderate"  # conservative|moderate|aggressive
    change_readiness: str = "moderate"  # resistant|cautious|moderate|eager
    
    def to_dict(self) -> dict:
        return {
            "buyer_type": self.buyer_type.value,
            "authority": self.authority.value,
            "decision_speed": self.decision_speed,
            "needs_consensus": self.needs_consensus,
            "other_stakeholders": self.other_stakeholders,
            "requirements": {
                "case_study": self.needs_case_study,
                "demo": self.needs_demo,
                "proposal": self.needs_proposal,
                "references": self.needs_references,
                "trial": self.needs_trial,
                "internal_approval": self.needs_internal_approval
            },
            "risk_tolerance": self.risk_tolerance,
            "change_readiness": self.change_readiness
        }


@dataclass
class CommunicationStyle:
    """How to communicate with this prospect"""
    pace: str = "moderate"  # slow|moderate|fast
    detail_level: str = "moderate"  # high_level|moderate|detailed
    tone_preference: str = "professional"  # casual|professional|formal
    
    # Behavioral observations
    talks_a_lot: bool = False
    asks_many_questions: bool = False
    interrupts: bool = False
    takes_notes: bool = False
    
    # Preferred content
    prefers_visuals: bool = False
    prefers_data: bool = False
    prefers_stories: bool = False
    prefers_demos: bool = True
    
    # Language patterns
    uses_technical_terms: bool = False
    uses_business_jargon: bool = False
    emotional_language: bool = False
    
    def to_dict(self) -> dict:
        return {
            "pace": self.pace,
            "detail_level": self.detail_level,
            "tone_preference": self.tone_preference,
            "behaviors": {
                "talks_a_lot": self.talks_a_lot,
                "asks_many_questions": self.asks_many_questions,
                "interrupts": self.interrupts,
                "takes_notes": self.takes_notes
            },
            "content_preferences": {
                "visuals": self.prefers_visuals,
                "data": self.prefers_data,
                "stories": self.prefers_stories,
                "demos": self.prefers_demos
            },
            "language": {
                "technical": self.uses_technical_terms,
                "business_jargon": self.uses_business_jargon,
                "emotional": self.emotional_language
            }
        }


@dataclass
class BudgetContext:
    """Budget and financial signals"""
    signal: BudgetSignal = BudgetSignal.UNKNOWN
    
    # Revealed information
    stated_budget: Optional[str] = None
    budget_range_min: Optional[float] = None
    budget_range_max: Optional[float] = None
    budget_cycle: Optional[str] = None  # monthly|quarterly|annual
    fiscal_year_end: Optional[str] = None
    
    # Signals
    price_anchors_mentioned: List[str] = field(default_factory=list)  # Prices they referenced
    value_drivers: List[str] = field(default_factory=list)  # What ROI they care about
    cost_of_inaction: Optional[str] = None  # What it costs them to do nothing
    
    def to_dict(self) -> dict:
        return {
            "signal": self.signal.value,
            "stated_budget": self.stated_budget,
            "budget_range": {
                "min": self.budget_range_min,
                "max": self.budget_range_max
            },
            "budget_cycle": self.budget_cycle,
            "fiscal_year_end": self.fiscal_year_end,
            "price_anchors": self.price_anchors_mentioned,
            "value_drivers": self.value_drivers,
            "cost_of_inaction": self.cost_of_inaction
        }


@dataclass
class ProspectGenome:
    """
    Complete B2B prospect intelligence profile.
    Built during sales conversations, not forms.
    """
    # Identifiers
    genome_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    prospect_id: str = ""  # Link to your CRM/prospect database
    
    # Basic info (from your database)
    business_name: str = ""
    contact_name: str = ""
    contact_role: str = ""
    phone: str = ""
    email: str = ""
    city: str = ""
    business_type: str = ""  # hotel|villa|restaurant|tour
    
    # Intelligence layers
    decision: DecisionDNA = field(default_factory=DecisionDNA)
    communication: CommunicationStyle = field(default_factory=CommunicationStyle)
    budget: BudgetContext = field(default_factory=BudgetContext)
    
    # Pain & motivation
    pain_points: List[PainPoint] = field(default_factory=list)
    stated_goals: List[str] = field(default_factory=list)
    trigger_event: Optional[str] = None  # What made them interested now?
    
    # Objections & concerns
    objections: List[Objection] = field(default_factory=list)
    unspoken_concerns: List[str] = field(default_factory=list)  # Your intuition
    
    # Competitive landscape
    competitors_mentioned: List[CompetitorMention] = field(default_factory=list)
    current_solution: Optional[str] = None
    switching_cost_concern: bool = False
    
    # Urgency & timeline
    urgency: UrgencyLevel = UrgencyLevel.UNKNOWN
    stated_timeline: Optional[str] = None
    key_dates: List[Dict] = field(default_factory=list)  # [{date, event}]
    
    # Relationship
    rapport_level: int = 5  # 1-10
    trust_signals: List[str] = field(default_factory=list)
    personal_notes: List[str] = field(default_factory=list)
    
    # Call history
    calls: List[Dict] = field(default_factory=list)
    total_call_time_minutes: int = 0
    
    # Signals log
    signals: List[CallSignal] = field(default_factory=list)
    
    # Status
    deal_stage: str = "discovery"  # discovery|qualification|proposal|negotiation|closed
    next_action: Optional[str] = None
    follow_up_date: Optional[datetime] = None
    
    # Meta
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    
    def add_signal(self, signal_type: str, value: Any, context: str = None):
        """Add a signal captured during call"""
        signal = CallSignal(
            signal_type=signal_type,
            value=value,
            context=context
        )
        self.signals.append(signal)
        self.updated_at = datetime.utcnow()
    
    def add_pain_point(self, description: str, severity: int = 5, 
                      emotional_charge: str = "neutral", quote: str = None):
        """Add or update a pain point"""
        # Check if similar pain point exists
        for pp in self.pain_points:
            if description.lower() in pp.description.lower() or pp.description.lower() in description.lower():
                pp.mentioned_count += 1
                pp.severity = max(pp.severity, severity)
                if quote:
                    pp.quotes.append(quote)
                return
        
        # New pain point
        pp = PainPoint(
            description=description,
            severity=severity,
            emotional_charge=emotional_charge,
            quotes=[quote] if quote else []
        )
        self.pain_points.append(pp)
    
    def add_objection(self, objection_type: ObjectionType, statement: str):
        """Log an objection"""
        obj = Objection(
            objection_type=objection_type,
            statement=statement
        )
        self.objections.append(obj)
    
    def get_closing_strategy(self) -> Dict:
        """Generate recommended closing strategy based on profile"""
        strategy = {
            "approach": "",
            "key_points": [],
            "avoid": [],
            "closing_question": "",
            "follow_up_cadence": ""
        }
        
        # Based on buyer type
        if self.decision.buyer_type == BuyerType.ANALYTICAL:
            strategy["approach"] = "Data-driven presentation with clear ROI"
            strategy["key_points"] = [
                "Lead with specific numbers and metrics",
                "Provide case studies with measurable results",
                "Give them time to analyze - don't rush"
            ]
            strategy["avoid"] = ["Emotional appeals", "Pressure tactics", "Vague claims"]
            strategy["closing_question"] = "Based on the data, what would you need to see to move forward?"
            
        elif self.decision.buyer_type == BuyerType.DRIVER:
            strategy["approach"] = "Direct, results-focused, respect their time"
            strategy["key_points"] = [
                "Cut to the chase - what results will they get",
                "Give them options and control",
                "Focus on competitive advantage"
            ]
            strategy["avoid"] = ["Long explanations", "Too much detail", "Being passive"]
            strategy["closing_question"] = "Ready to get started, or what's holding you back?"
            
        elif self.decision.buyer_type == BuyerType.EXPRESSIVE:
            strategy["approach"] = "Vision-focused, relationship-building"
            strategy["key_points"] = [
                "Paint the picture of success",
                "Share stories and testimonials",
                "Make it personal and exciting"
            ]
            strategy["avoid"] = ["Too many details", "Being impersonal", "Killing the energy"]
            strategy["closing_question"] = "Can you see this working for your business? What excites you most?"
            
        elif self.decision.buyer_type == BuyerType.AMIABLE:
            strategy["approach"] = "Supportive, low-pressure, consensus-building"
            strategy["key_points"] = [
                "Reduce perceived risk",
                "Offer guarantees and support",
                "Help them build internal consensus"
            ]
            strategy["avoid"] = ["Pressure", "Rushing decisions", "Ignoring their concerns"]
            strategy["closing_question"] = "What would help you feel confident about this decision?"
        
        # Adjust for urgency
        if self.urgency == UrgencyLevel.BLEEDING:
            strategy["follow_up_cadence"] = "Same day / Next morning"
            strategy["key_points"].insert(0, "Emphasize speed to relief")
        elif self.urgency == UrgencyLevel.URGENT:
            strategy["follow_up_cadence"] = "Within 24-48 hours"
        elif self.urgency == UrgencyLevel.PLANNING:
            strategy["follow_up_cadence"] = "Weekly check-ins"
        else:
            strategy["follow_up_cadence"] = "Bi-weekly nurture"
        
        # Factor in unaddressed objections
        unaddressed = [o for o in self.objections if not o.addressed]
        if unaddressed:
            strategy["must_address"] = [o.statement for o in unaddressed]
        
        return strategy
    
    def get_call_prep(self) -> Dict:
        """Generate call preparation brief"""
        return {
            "business": self.business_name,
            "contact": f"{self.contact_name} ({self.contact_role})",
            "buyer_type": self.decision.buyer_type.value,
            "communication_tips": [
                f"Pace: {self.communication.pace}",
                f"Detail level: {self.communication.detail_level}",
                f"Tone: {self.communication.tone_preference}"
            ],
            "top_pain_points": [
                {"pain": pp.description, "severity": pp.severity}
                for pp in sorted(self.pain_points, key=lambda x: -x.severity)[:3]
            ],
            "open_objections": [
                o.statement for o in self.objections if o.still_concern
            ],
            "what_they_need": [
                k for k, v in {
                    "Case study": self.decision.needs_case_study,
                    "Demo": self.decision.needs_demo,
                    "Proposal": self.decision.needs_proposal,
                    "References": self.decision.needs_references,
                    "Trial": self.decision.needs_trial
                }.items() if v
            ],
            "urgency": self.urgency.value,
            "next_action": self.next_action,
            "rapport_level": self.rapport_level,
            "personal_notes": self.personal_notes[-3:] if self.personal_notes else []
        }
    
    def get_deal_score(self) -> Dict:
        """Calculate deal score and likelihood to close"""
        score = 50  # Base score
        factors = []
        
        # Urgency boost
        urgency_scores = {
            UrgencyLevel.BLEEDING: 25,
            UrgencyLevel.URGENT: 15,
            UrgencyLevel.PLANNING: 5,
            UrgencyLevel.BROWSING: -10,
            UrgencyLevel.UNKNOWN: 0
        }
        score += urgency_scores.get(self.urgency, 0)
        if self.urgency in [UrgencyLevel.BLEEDING, UrgencyLevel.URGENT]:
            factors.append(f"+{urgency_scores[self.urgency]} High urgency")
        
        # Authority
        if self.decision.authority == DecisionAuthority.SOLE_DECISION_MAKER:
            score += 15
            factors.append("+15 Sole decision maker")
        elif self.decision.authority == DecisionAuthority.ECONOMIC_BUYER:
            score += 10
            factors.append("+10 Economic buyer")
        elif self.decision.authority == DecisionAuthority.CHAMPION:
            score += 5
            factors.append("+5 Internal champion")
        
        # Budget signals
        if self.budget.signal == BudgetSignal.VALUE_FOCUSED:
            score += 10
            factors.append("+10 Value-focused buyer")
        elif self.budget.signal == BudgetSignal.BUDGET_FLEXIBLE:
            score += 15
            factors.append("+15 Flexible budget")
        elif self.budget.signal == BudgetSignal.BUDGET_CONSTRAINED:
            score -= 10
            factors.append("-10 Budget constrained")
        
        # Pain severity
        if self.pain_points:
            max_pain = max(pp.severity for pp in self.pain_points)
            if max_pain >= 8:
                score += 15
                factors.append("+15 Severe pain point")
            elif max_pain >= 6:
                score += 8
                factors.append("+8 Significant pain")
        
        # Objections
        unaddressed = len([o for o in self.objections if not o.addressed])
        if unaddressed > 2:
            score -= 15
            factors.append(f"-15 {unaddressed} unaddressed objections")
        elif unaddressed > 0:
            score -= 5
            factors.append(f"-5 {unaddressed} unaddressed objection(s)")
        
        # Rapport
        if self.rapport_level >= 8:
            score += 10
            factors.append("+10 Strong rapport")
        elif self.rapport_level <= 4:
            score -= 10
            factors.append("-10 Low rapport")
        
        # Change readiness
        if self.decision.change_readiness == "eager":
            score += 10
            factors.append("+10 Eager to change")
        elif self.decision.change_readiness == "resistant":
            score -= 15
            factors.append("-15 Resistant to change")
        
        # Cap score
        score = max(0, min(100, score))
        
        # Likelihood assessment
        if score >= 80:
            likelihood = "Very High"
        elif score >= 60:
            likelihood = "High"
        elif score >= 40:
            likelihood = "Moderate"
        elif score >= 20:
            likelihood = "Low"
        else:
            likelihood = "Very Low"
        
        return {
            "score": score,
            "likelihood": likelihood,
            "factors": factors,
            "recommendation": self._get_recommendation(score)
        }
    
    def _get_recommendation(self, score: int) -> str:
        if score >= 80:
            return "Push for close. High probability deal - don't let it slip."
        elif score >= 60:
            return "Strong prospect. Address remaining objections and propose next steps."
        elif score >= 40:
            return "Needs work. Focus on building urgency and addressing concerns."
        elif score >= 20:
            return "Long shot. Qualify harder or move to nurture sequence."
        else:
            return "Unlikely to close. Consider disqualifying to focus on better opportunities."
    
    def to_dict(self) -> dict:
        return {
            "genome_id": self.genome_id,
            "prospect_id": self.prospect_id,
            "business": {
                "name": self.business_name,
                "type": self.business_type,
                "city": self.city
            },
            "contact": {
                "name": self.contact_name,
                "role": self.contact_role,
                "phone": self.phone,
                "email": self.email
            },
            "intelligence": {
                "decision_dna": self.decision.to_dict(),
                "communication_style": self.communication.to_dict(),
                "budget_context": self.budget.to_dict()
            },
            "pain_points": [pp.to_dict() for pp in self.pain_points],
            "stated_goals": self.stated_goals,
            "trigger_event": self.trigger_event,
            "objections": [o.to_dict() for o in self.objections],
            "urgency": self.urgency.value,
            "stated_timeline": self.stated_timeline,
            "deal_stage": self.deal_stage,
            "deal_score": self.get_deal_score(),
            "closing_strategy": self.get_closing_strategy(),
            "signals": [s.to_dict() for s in self.signals],
            "meta": {
                "rapport_level": self.rapport_level,
                "total_call_time": self.total_call_time_minutes,
                "calls_count": len(self.calls),
                "created_at": self.created_at.isoformat(),
                "updated_at": self.updated_at.isoformat()
            }
        }
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, default=str)
