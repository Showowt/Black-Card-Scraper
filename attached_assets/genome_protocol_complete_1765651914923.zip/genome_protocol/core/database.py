"""
GENOME PROTOCOL™ - Database Layer
===================================
SQLite for development, PostgreSQL-compatible for production.
"""

import sqlite3
import json
from datetime import datetime
from typing import Optional, List, Dict, Any
from contextlib import contextmanager
from pathlib import Path

from .models import (
    GenomeProfile, SignalCapture, ConfidenceLevel, CollectionMechanism,
    CommunicationDNA, DecisionDNA, SensoryDNA, EmotionalFingerprint,
    RelationshipContext, ContextMemory, Channel, DecisionDriver, RiskTolerance
)


class GenomeDatabase:
    """Database operations for Genome Protocol"""
    
    def __init__(self, db_path: str = "genome_protocol.db"):
        self.db_path = db_path
        self._init_database()
    
    @contextmanager
    def get_connection(self):
        """Context manager for database connections"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def _init_database(self):
        """Initialize database schema"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Main profiles table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS genome_profiles (
                    genome_id TEXT PRIMARY KEY,
                    property_id TEXT NOT NULL,
                    external_ids TEXT DEFAULT '{}',
                    
                    -- Identity
                    name TEXT,
                    first_name TEXT,
                    phone TEXT,
                    email TEXT,
                    whatsapp TEXT,
                    instagram TEXT,
                    country TEXT,
                    city TEXT,
                    language TEXT DEFAULT 'es',
                    estimated_age_range TEXT,
                    
                    -- DNA Strands (JSON)
                    communication_dna TEXT DEFAULT '{}',
                    decision_dna TEXT DEFAULT '{}',
                    sensory_dna TEXT DEFAULT '{}',
                    emotional_fingerprint TEXT DEFAULT '{}',
                    relationship_context TEXT DEFAULT '{}',
                    context_memory TEXT DEFAULT '{}',
                    
                    -- Confidence tracking
                    confidence_scores TEXT DEFAULT '{}',
                    
                    -- Meta
                    profile_completeness REAL DEFAULT 0.0,
                    overall_confidence REAL DEFAULT 0.0,
                    total_interactions INTEGER DEFAULT 0,
                    total_signals_captured INTEGER DEFAULT 0,
                    
                    -- Value metrics
                    lifetime_value REAL DEFAULT 0.0,
                    predicted_ltv REAL DEFAULT 0.0,
                    engagement_score INTEGER DEFAULT 50,
                    
                    -- Timestamps
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    last_interaction_at TEXT,
                    
                    -- Indexes
                    UNIQUE(property_id, whatsapp),
                    UNIQUE(property_id, email)
                )
            """)
            
            # Signal capture log
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS signal_captures (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    genome_id TEXT NOT NULL,
                    field TEXT NOT NULL,
                    value TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    mechanism TEXT NOT NULL,
                    source_interaction_id TEXT,
                    raw_input TEXT,
                    captured_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    
                    FOREIGN KEY (genome_id) REFERENCES genome_profiles(genome_id)
                )
            """)
            
            # Interactions log (for behavioral analysis)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS interactions (
                    interaction_id TEXT PRIMARY KEY,
                    genome_id TEXT NOT NULL,
                    property_id TEXT NOT NULL,
                    channel TEXT NOT NULL,
                    direction TEXT NOT NULL,  -- inbound|outbound
                    message_content TEXT,
                    message_length INTEGER,
                    response_time_seconds INTEGER,
                    sentiment TEXT,
                    intent TEXT,
                    signals_extracted TEXT DEFAULT '[]',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    
                    FOREIGN KEY (genome_id) REFERENCES genome_profiles(genome_id)
                )
            """)
            
            # Property clients (your MachineMind clients)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS properties (
                    property_id TEXT PRIMARY KEY,
                    property_name TEXT NOT NULL,
                    property_type TEXT NOT NULL,  -- hotel|villa|restaurant|tour|concierge
                    city TEXT,
                    country TEXT DEFAULT 'Colombia',
                    tier TEXT DEFAULT 'starter',  -- starter|professional|enterprise
                    genome_enabled BOOLEAN DEFAULT 1,
                    settings TEXT DEFAULT '{}',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create indexes for fast lookups
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_profiles_property ON genome_profiles(property_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_profiles_whatsapp ON genome_profiles(whatsapp)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_profiles_email ON genome_profiles(email)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_signals_genome ON signal_captures(genome_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_interactions_genome ON interactions(genome_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_interactions_property ON interactions(property_id)")
    
    # ==================== PROFILE OPERATIONS ====================
    
    def create_profile(self, property_id: str, **kwargs) -> GenomeProfile:
        """Create a new genome profile"""
        profile = GenomeProfile(property_id=property_id)
        
        # Set any provided fields
        for key, value in kwargs.items():
            if hasattr(profile, key):
                setattr(profile, key, value)
        
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO genome_profiles (
                    genome_id, property_id, external_ids,
                    name, first_name, phone, email, whatsapp, instagram,
                    country, city, language, estimated_age_range,
                    communication_dna, decision_dna, sensory_dna,
                    emotional_fingerprint, relationship_context, context_memory,
                    confidence_scores, profile_completeness, overall_confidence,
                    total_interactions, total_signals_captured,
                    lifetime_value, predicted_ltv, engagement_score,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                profile.genome_id, profile.property_id, json.dumps(profile.external_ids),
                profile.name, profile.first_name, profile.phone, profile.email,
                profile.whatsapp, profile.instagram, profile.country, profile.city,
                profile.language, profile.estimated_age_range,
                json.dumps(profile.communication.to_dict()),
                json.dumps(profile.decision.to_dict()),
                json.dumps(profile.sensory.to_dict()),
                json.dumps(profile.emotional.to_dict()),
                json.dumps(profile.relationship.to_dict()),
                json.dumps(profile.memory.to_dict()),
                json.dumps(profile.confidence_scores),
                profile.profile_completeness, profile.overall_confidence,
                profile.total_interactions, profile.total_signals_captured,
                profile.lifetime_value, profile.predicted_ltv, profile.engagement_score,
                profile.created_at.isoformat(), profile.updated_at.isoformat()
            ))
        
        return profile
    
    def get_profile(self, genome_id: str) -> Optional[GenomeProfile]:
        """Retrieve a profile by genome_id"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM genome_profiles WHERE genome_id = ?", (genome_id,))
            row = cursor.fetchone()
            
            if row:
                return self._row_to_profile(dict(row))
        return None
    
    def find_profile(self, property_id: str, identifier: str) -> Optional[GenomeProfile]:
        """Find profile by whatsapp, email, or phone"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM genome_profiles 
                WHERE property_id = ? 
                AND (whatsapp = ? OR email = ? OR phone = ?)
            """, (property_id, identifier, identifier, identifier))
            row = cursor.fetchone()
            
            if row:
                return self._row_to_profile(dict(row))
        return None
    
    def get_or_create_profile(self, property_id: str, identifier: str, 
                              identifier_type: str = "whatsapp") -> GenomeProfile:
        """Get existing profile or create new one"""
        profile = self.find_profile(property_id, identifier)
        
        if not profile:
            kwargs = {identifier_type: identifier}
            profile = self.create_profile(property_id, **kwargs)
        
        return profile
    
    def update_profile(self, profile: GenomeProfile):
        """Update an existing profile"""
        profile.updated_at = datetime.utcnow()
        
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE genome_profiles SET
                    external_ids = ?,
                    name = ?, first_name = ?, phone = ?, email = ?,
                    whatsapp = ?, instagram = ?, country = ?, city = ?,
                    language = ?, estimated_age_range = ?,
                    communication_dna = ?, decision_dna = ?, sensory_dna = ?,
                    emotional_fingerprint = ?, relationship_context = ?, context_memory = ?,
                    confidence_scores = ?,
                    profile_completeness = ?, overall_confidence = ?,
                    total_interactions = ?, total_signals_captured = ?,
                    lifetime_value = ?, predicted_ltv = ?, engagement_score = ?,
                    updated_at = ?, last_interaction_at = ?
                WHERE genome_id = ?
            """, (
                json.dumps(profile.external_ids),
                profile.name, profile.first_name, profile.phone, profile.email,
                profile.whatsapp, profile.instagram, profile.country, profile.city,
                profile.language, profile.estimated_age_range,
                json.dumps(profile.communication.to_dict()),
                json.dumps(profile.decision.to_dict()),
                json.dumps(profile.sensory.to_dict()),
                json.dumps(profile.emotional.to_dict()),
                json.dumps(profile.relationship.to_dict()),
                json.dumps(profile.memory.to_dict()),
                json.dumps(profile.confidence_scores),
                profile.profile_completeness, profile.overall_confidence,
                profile.total_interactions, profile.total_signals_captured,
                profile.lifetime_value, profile.predicted_ltv, profile.engagement_score,
                profile.updated_at.isoformat(),
                profile.last_interaction_at.isoformat() if profile.last_interaction_at else None,
                profile.genome_id
            ))
    
    def _row_to_profile(self, row: dict) -> GenomeProfile:
        """Convert database row to GenomeProfile object"""
        profile = GenomeProfile(
            genome_id=row['genome_id'],
            property_id=row['property_id']
        )
        
        # Identity fields
        profile.external_ids = json.loads(row.get('external_ids', '{}'))
        profile.name = row.get('name')
        profile.first_name = row.get('first_name')
        profile.phone = row.get('phone')
        profile.email = row.get('email')
        profile.whatsapp = row.get('whatsapp')
        profile.instagram = row.get('instagram')
        profile.country = row.get('country')
        profile.city = row.get('city')
        profile.language = row.get('language', 'es')
        profile.estimated_age_range = row.get('estimated_age_range')
        
        # DNA strands
        comm_data = json.loads(row.get('communication_dna', '{}'))
        profile.communication = self._dict_to_communication_dna(comm_data)
        
        decision_data = json.loads(row.get('decision_dna', '{}'))
        profile.decision = self._dict_to_decision_dna(decision_data)
        
        sensory_data = json.loads(row.get('sensory_dna', '{}'))
        profile.sensory = self._dict_to_sensory_dna(sensory_data)
        
        emotional_data = json.loads(row.get('emotional_fingerprint', '{}'))
        profile.emotional = self._dict_to_emotional(emotional_data)
        
        relationship_data = json.loads(row.get('relationship_context', '{}'))
        profile.relationship = self._dict_to_relationship(relationship_data)
        
        memory_data = json.loads(row.get('context_memory', '{}'))
        profile.memory = self._dict_to_memory(memory_data)
        
        # Meta
        profile.confidence_scores = json.loads(row.get('confidence_scores', '{}'))
        profile.profile_completeness = row.get('profile_completeness', 0.0)
        profile.overall_confidence = row.get('overall_confidence', 0.0)
        profile.total_interactions = row.get('total_interactions', 0)
        profile.total_signals_captured = row.get('total_signals_captured', 0)
        
        # Value metrics
        profile.lifetime_value = row.get('lifetime_value', 0.0)
        profile.predicted_ltv = row.get('predicted_ltv', 0.0)
        profile.engagement_score = row.get('engagement_score', 50)
        
        # Timestamps
        if row.get('created_at'):
            profile.created_at = datetime.fromisoformat(row['created_at'])
        if row.get('updated_at'):
            profile.updated_at = datetime.fromisoformat(row['updated_at'])
        if row.get('last_interaction_at'):
            profile.last_interaction_at = datetime.fromisoformat(row['last_interaction_at'])
        
        return profile
    
    def _dict_to_communication_dna(self, data: dict) -> CommunicationDNA:
        comm = CommunicationDNA()
        if data.get('preferred_channel'):
            try:
                comm.preferred_channel = Channel(data['preferred_channel'])
            except ValueError:
                pass
        comm.channel_confidence = data.get('channel_confidence', 0.0)
        comm.frequency_preference = data.get('frequency_preference', 'moderate')
        comm.tone_preference = data.get('tone_preference', 'casual')
        comm.best_contact_time = data.get('best_contact_time', 'afternoon')
        comm.response_style = data.get('response_style', 'moderate')
        comm.emoji_usage = data.get('emoji_usage', 'minimal')
        comm.language = data.get('language', 'es')
        comm.formality_index = data.get('formality_index', 50)
        comm.avg_response_time_seconds = data.get('avg_response_time_seconds')
        comm.typical_message_length = data.get('typical_message_length')
        comm.asks_questions = data.get('asks_questions', True)
        return comm
    
    def _dict_to_decision_dna(self, data: dict) -> DecisionDNA:
        dec = DecisionDNA()
        dec.speed = data.get('speed', 'moderate')
        if data.get('primary_driver'):
            try:
                dec.primary_driver = DecisionDriver(data['primary_driver'])
            except ValueError:
                pass
        if data.get('secondary_driver'):
            try:
                dec.secondary_driver = DecisionDriver(data['secondary_driver'])
            except ValueError:
                pass
        if data.get('risk_tolerance'):
            try:
                dec.risk_tolerance = RiskTolerance(data['risk_tolerance'])
            except ValueError:
                pass
        dec.price_sensitivity_index = data.get('price_sensitivity_index', 50)
        dec.upgrade_propensity = data.get('upgrade_propensity', 50)
        dec.discount_responsive = data.get('discount_responsive', False)
        dec.typical_lead_time_days = data.get('typical_lead_time_days')
        dec.modification_frequency = data.get('modification_frequency', 'rarely')
        dec.cancellation_rate = data.get('cancellation_rate', 0.0)
        dec.needs_social_proof = data.get('needs_social_proof', False)
        dec.asks_for_references = data.get('asks_for_references', False)
        dec.research_depth = data.get('research_depth', 'moderate')
        return dec
    
    def _dict_to_sensory_dna(self, data: dict) -> SensoryDNA:
        sens = SensoryDNA()
        sens.environment_preference = data.get('environment_preference', 'ambient')
        sens.space_preference = data.get('space_preference', 'open')
        sens.crowd_tolerance = data.get('crowd_tolerance', 'moderate')
        sens.temperature_preference = data.get('temperature_preference', 'warm')
        sens.lighting_preference = data.get('lighting_preference', 'natural')
        sens.chronotype = data.get('chronotype', 'moderate')
        sens.pace_preference = data.get('pace_preference', 'relaxed')
        sens.dietary_restrictions = data.get('dietary_restrictions', [])
        sens.cuisine_preferences = data.get('cuisine_preferences', [])
        sens.alcohol_preference = data.get('alcohol_preference', 'unknown')
        sens.room_preferences = data.get('room_preferences', [])
        sens.amenity_priorities = data.get('amenity_priorities', [])
        return sens
    
    def _dict_to_emotional(self, data: dict) -> EmotionalFingerprint:
        emo = EmotionalFingerprint()
        emo.stress_indicators = data.get('stress_indicators', [])
        emo.joy_triggers = data.get('joy_triggers', [])
        emo.trust_signals = data.get('trust_signals', [])
        emo.anxiety_patterns = data.get('anxiety_patterns', [])
        emo.baseline_sentiment = data.get('baseline_sentiment', 'neutral')
        emo.sentiment_volatility = data.get('sentiment_volatility', 'stable')
        emo.complaint_style = data.get('complaint_style', 'unknown')
        emo.recovery_responsiveness = data.get('recovery_responsiveness', 'unknown')
        return emo
    
    def _dict_to_relationship(self, data: dict) -> RelationshipContext:
        rel = RelationshipContext()
        rel.typical_group_size = data.get('typical_group_size', 1)
        rel.travel_companions = data.get('travel_companions', 'unknown')
        rel.is_decision_maker = data.get('is_decision_maker', True)
        rel.influence_position = data.get('influence_position', 'independent')
        rel.known_companions = data.get('known_companions', [])
        rel.occasion_types = data.get('occasion_types', [])
        rel.celebration_style = data.get('celebration_style', 'unknown')
        return rel
    
    def _dict_to_memory(self, data: dict) -> ContextMemory:
        mem = ContextMemory()
        mem.significant_dates = data.get('significant_dates', [])
        mem.past_experiences = data.get('past_experiences', [])
        mem.stated_preferences = data.get('stated_preferences', [])
        mem.observed_contradictions = data.get('observed_contradictions', [])
        mem.topics_discussed = data.get('topics_discussed', [])
        mem.requests_made = data.get('requests_made', [])
        mem.feedback_given = data.get('feedback_given', [])
        return mem
    
    # ==================== SIGNAL OPERATIONS ====================
    
    def log_signal(self, signal: SignalCapture):
        """Log a captured signal to the database"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO signal_captures 
                (genome_id, field, value, confidence, mechanism, source_interaction_id, raw_input)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                signal.source_interaction_id.split(':')[0] if ':' in signal.source_interaction_id else signal.source_interaction_id,
                signal.field,
                json.dumps(signal.value) if not isinstance(signal.value, str) else signal.value,
                signal.confidence.value,
                signal.mechanism.value,
                signal.source_interaction_id,
                signal.raw_input
            ))
    
    # ==================== INTERACTION OPERATIONS ====================
    
    def log_interaction(self, genome_id: str, property_id: str, channel: str,
                       direction: str, message_content: str, **kwargs):
        """Log an interaction"""
        import uuid
        interaction_id = str(uuid.uuid4())
        
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO interactions
                (interaction_id, genome_id, property_id, channel, direction,
                 message_content, message_length, response_time_seconds,
                 sentiment, intent, signals_extracted)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                interaction_id, genome_id, property_id, channel, direction,
                message_content, len(message_content) if message_content else 0,
                kwargs.get('response_time_seconds'),
                kwargs.get('sentiment'),
                kwargs.get('intent'),
                json.dumps(kwargs.get('signals_extracted', []))
            ))
        
        return interaction_id
    
    # ==================== ANALYTICS ====================
    
    def get_property_profiles(self, property_id: str, 
                             limit: int = 100, 
                             min_completeness: float = 0.0) -> List[GenomeProfile]:
        """Get all profiles for a property"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM genome_profiles 
                WHERE property_id = ? AND profile_completeness >= ?
                ORDER BY updated_at DESC
                LIMIT ?
            """, (property_id, min_completeness, limit))
            
            return [self._row_to_profile(dict(row)) for row in cursor.fetchall()]
    
    def get_profile_stats(self, property_id: str) -> Dict:
        """Get aggregate statistics for a property"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Total profiles
            cursor.execute("""
                SELECT 
                    COUNT(*) as total_profiles,
                    AVG(profile_completeness) as avg_completeness,
                    AVG(overall_confidence) as avg_confidence,
                    SUM(lifetime_value) as total_ltv,
                    AVG(engagement_score) as avg_engagement
                FROM genome_profiles
                WHERE property_id = ?
            """, (property_id,))
            row = cursor.fetchone()
            
            # Profile completeness distribution
            cursor.execute("""
                SELECT 
                    CASE 
                        WHEN profile_completeness < 25 THEN 'minimal'
                        WHEN profile_completeness < 50 THEN 'basic'
                        WHEN profile_completeness < 75 THEN 'good'
                        ELSE 'complete'
                    END as tier,
                    COUNT(*) as count
                FROM genome_profiles
                WHERE property_id = ?
                GROUP BY tier
            """, (property_id,))
            tiers = {r['tier']: r['count'] for r in cursor.fetchall()}
            
            return {
                "total_profiles": row['total_profiles'] or 0,
                "avg_completeness": round(row['avg_completeness'] or 0, 1),
                "avg_confidence": round(row['avg_confidence'] or 0, 2),
                "total_ltv": round(row['total_ltv'] or 0, 2),
                "avg_engagement": round(row['avg_engagement'] or 0, 1),
                "completeness_tiers": tiers
            }
    
    def get_high_value_profiles(self, property_id: str, limit: int = 20) -> List[GenomeProfile]:
        """Get highest value profiles for VIP treatment"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM genome_profiles
                WHERE property_id = ?
                ORDER BY lifetime_value DESC, engagement_score DESC
                LIMIT ?
            """, (property_id, limit))
            
            return [self._row_to_profile(dict(row)) for row in cursor.fetchall()]


# Singleton instance
_db_instance = None

def get_database(db_path: str = "genome_protocol.db") -> GenomeDatabase:
    """Get or create database instance"""
    global _db_instance
    if _db_instance is None or _db_instance.db_path != db_path:
        _db_instance = GenomeDatabase(db_path)
    return _db_instance
