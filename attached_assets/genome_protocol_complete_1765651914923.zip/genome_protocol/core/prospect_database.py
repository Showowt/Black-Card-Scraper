"""
PROSPECT GENOME™ - Database Integration & Call Prep
=====================================================
Integrates with your MachineMind prospect database to 
pre-load prospect info and generate call briefs.
"""

import json
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from pathlib import Path

from .prospect_models import (
    ProspectGenome, BuyerType, UrgencyLevel, DecisionAuthority,
    BudgetSignal, PainPoint, Objection, ObjectionType
)


class ProspectDatabase:
    """
    Database operations for Prospect Genome.
    Integrates with existing MachineMind prospect data.
    """
    
    def __init__(self, db_path: str = "prospect_genome.db"):
        self.db_path = db_path
        self._init_database()
    
    def _init_database(self):
        """Initialize the prospect genome database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Prospect Genome profiles
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS prospect_genomes (
                genome_id TEXT PRIMARY KEY,
                prospect_id TEXT UNIQUE,
                
                -- Basic info
                business_name TEXT,
                contact_name TEXT,
                contact_role TEXT,
                phone TEXT,
                email TEXT,
                city TEXT,
                business_type TEXT,
                
                -- Intelligence (JSON)
                decision_dna TEXT DEFAULT '{}',
                communication_style TEXT DEFAULT '{}',
                budget_context TEXT DEFAULT '{}',
                
                -- Pain & Motivation (JSON arrays)
                pain_points TEXT DEFAULT '[]',
                stated_goals TEXT DEFAULT '[]',
                trigger_event TEXT,
                
                -- Objections & Concerns (JSON)
                objections TEXT DEFAULT '[]',
                unspoken_concerns TEXT DEFAULT '[]',
                
                -- Competition
                competitors TEXT DEFAULT '[]',
                current_solution TEXT,
                
                -- Urgency & Timeline
                urgency TEXT DEFAULT 'unknown',
                stated_timeline TEXT,
                key_dates TEXT DEFAULT '[]',
                
                -- Relationship
                rapport_level INTEGER DEFAULT 5,
                trust_signals TEXT DEFAULT '[]',
                personal_notes TEXT DEFAULT '[]',
                
                -- Call history
                calls TEXT DEFAULT '[]',
                total_call_time INTEGER DEFAULT 0,
                signals TEXT DEFAULT '[]',
                
                -- Status
                deal_stage TEXT DEFAULT 'discovery',
                deal_score INTEGER DEFAULT 50,
                next_action TEXT,
                follow_up_date TEXT,
                
                -- Meta
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Call logs
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS call_logs (
                call_id TEXT PRIMARY KEY,
                genome_id TEXT,
                started_at TEXT,
                ended_at TEXT,
                duration_minutes INTEGER,
                notes TEXT,
                signals_captured TEXT DEFAULT '[]',
                outcome TEXT,
                next_steps TEXT,
                
                FOREIGN KEY (genome_id) REFERENCES prospect_genomes(genome_id)
            )
        """)
        
        # Create indexes
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_prospect_business ON prospect_genomes(business_name)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_prospect_stage ON prospect_genomes(deal_stage)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_prospect_followup ON prospect_genomes(follow_up_date)")
        
        conn.commit()
        conn.close()
    
    def import_from_machinemind_db(self, machinemind_db_path: str):
        """
        Import prospects from your existing MachineMind prospect database.
        Assumes a table structure with business info.
        """
        mm_conn = sqlite3.connect(machinemind_db_path)
        mm_conn.row_factory = sqlite3.Row
        mm_cursor = mm_conn.cursor()
        
        # Adjust this query based on your actual database schema
        mm_cursor.execute("""
            SELECT 
                id, business_name, contact_name, contact_role,
                phone, email, city, business_type,
                rating, review_count, ai_score, readiness_score
            FROM prospects
            WHERE readiness_score > 0
        """)
        
        imported = 0
        for row in mm_cursor.fetchall():
            genome = ProspectGenome(
                prospect_id=str(row['id']),
                business_name=row['business_name'] or '',
                contact_name=row['contact_name'] or '',
                contact_role=row['contact_role'] or '',
                phone=row['phone'] or '',
                email=row['email'] or '',
                city=row['city'] or '',
                business_type=row['business_type'] or ''
            )
            
            # Infer initial signals from existing data
            if row['ai_score'] and row['ai_score'] > 90:
                genome.add_signal('high_ai_score', f"AI Score: {row['ai_score']}")
            
            self.save_genome(genome)
            imported += 1
        
        mm_conn.close()
        return imported
    
    def save_genome(self, genome: ProspectGenome):
        """Save or update a prospect genome"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT OR REPLACE INTO prospect_genomes (
                genome_id, prospect_id, business_name, contact_name, contact_role,
                phone, email, city, business_type,
                decision_dna, communication_style, budget_context,
                pain_points, stated_goals, trigger_event,
                objections, unspoken_concerns,
                competitors, current_solution,
                urgency, stated_timeline, key_dates,
                rapport_level, trust_signals, personal_notes,
                calls, total_call_time, signals,
                deal_stage, deal_score, next_action, follow_up_date,
                updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            genome.genome_id,
            genome.prospect_id,
            genome.business_name,
            genome.contact_name,
            genome.contact_role,
            genome.phone,
            genome.email,
            genome.city,
            genome.business_type,
            json.dumps(genome.decision.to_dict()),
            json.dumps(genome.communication.to_dict()),
            json.dumps(genome.budget.to_dict()),
            json.dumps([pp.to_dict() for pp in genome.pain_points]),
            json.dumps(genome.stated_goals),
            genome.trigger_event,
            json.dumps([o.to_dict() for o in genome.objections]),
            json.dumps(genome.unspoken_concerns),
            json.dumps([vars(c) for c in genome.competitors_mentioned]),
            genome.current_solution,
            genome.urgency.value,
            genome.stated_timeline,
            json.dumps(genome.key_dates),
            genome.rapport_level,
            json.dumps(genome.trust_signals),
            json.dumps(genome.personal_notes),
            json.dumps(genome.calls),
            genome.total_call_time_minutes,
            json.dumps([s.to_dict() for s in genome.signals]),
            genome.deal_stage,
            genome.get_deal_score()['score'],
            genome.next_action,
            genome.follow_up_date.isoformat() if genome.follow_up_date else None,
            datetime.utcnow().isoformat()
        ))
        
        conn.commit()
        conn.close()
    
    def get_genome(self, genome_id: str) -> Optional[ProspectGenome]:
        """Get a prospect genome by ID"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM prospect_genomes WHERE genome_id = ?", (genome_id,))
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return self._row_to_genome(dict(row))
        return None
    
    def find_by_business(self, business_name: str) -> Optional[ProspectGenome]:
        """Find genome by business name"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT * FROM prospect_genomes WHERE business_name LIKE ?", 
            (f"%{business_name}%",)
        )
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return self._row_to_genome(dict(row))
        return None
    
    def get_follow_ups_due(self, days_ahead: int = 3) -> List[ProspectGenome]:
        """Get prospects with follow-ups due in the next N days"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        end_date = (datetime.utcnow() + timedelta(days=days_ahead)).isoformat()
        
        cursor.execute("""
            SELECT * FROM prospect_genomes 
            WHERE follow_up_date IS NOT NULL 
            AND follow_up_date <= ?
            AND deal_stage NOT IN ('closed_won', 'closed_lost')
            ORDER BY follow_up_date ASC
        """, (end_date,))
        
        genomes = [self._row_to_genome(dict(row)) for row in cursor.fetchall()]
        conn.close()
        return genomes
    
    def get_hot_prospects(self, min_score: int = 60) -> List[ProspectGenome]:
        """Get high-scoring prospects"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT * FROM prospect_genomes 
            WHERE deal_score >= ?
            AND deal_stage NOT IN ('closed_won', 'closed_lost')
            ORDER BY deal_score DESC
        """, (min_score,))
        
        genomes = [self._row_to_genome(dict(row)) for row in cursor.fetchall()]
        conn.close()
        return genomes
    
    def _row_to_genome(self, row: dict) -> ProspectGenome:
        """Convert database row to ProspectGenome object"""
        genome = ProspectGenome(
            genome_id=row['genome_id'],
            prospect_id=row['prospect_id'] or '',
            business_name=row['business_name'] or '',
            contact_name=row['contact_name'] or '',
            contact_role=row['contact_role'] or '',
            phone=row['phone'] or '',
            email=row['email'] or '',
            city=row['city'] or '',
            business_type=row['business_type'] or ''
        )
        
        # Parse JSON fields
        if row.get('decision_dna'):
            data = json.loads(row['decision_dna'])
            if data.get('buyer_type'):
                try:
                    genome.decision.buyer_type = BuyerType(data['buyer_type'])
                except ValueError:
                    pass
            if data.get('authority'):
                try:
                    genome.decision.authority = DecisionAuthority(data['authority'])
                except ValueError:
                    pass
        
        if row.get('urgency'):
            try:
                genome.urgency = UrgencyLevel(row['urgency'])
            except ValueError:
                pass
        
        if row.get('pain_points'):
            for pp_data in json.loads(row['pain_points']):
                genome.pain_points.append(PainPoint(**pp_data))
        
        if row.get('objections'):
            for obj_data in json.loads(row['objections']):
                obj = Objection(
                    objection_type=ObjectionType(obj_data['type']),
                    statement=obj_data.get('statement', ''),
                    addressed=obj_data.get('addressed', False)
                )
                genome.objections.append(obj)
        
        genome.rapport_level = row.get('rapport_level', 5)
        genome.deal_stage = row.get('deal_stage', 'discovery')
        genome.next_action = row.get('next_action')
        genome.stated_timeline = row.get('stated_timeline')
        genome.trigger_event = row.get('trigger_event')
        
        if row.get('follow_up_date'):
            genome.follow_up_date = datetime.fromisoformat(row['follow_up_date'])
        
        if row.get('personal_notes'):
            genome.personal_notes = json.loads(row['personal_notes'])
        
        return genome


class CallPrepGenerator:
    """
    Generates call preparation briefs from Prospect Genome data.
    Use before every sales call.
    """
    
    def __init__(self, db: ProspectDatabase):
        self.db = db
    
    def generate_call_brief(self, genome_id: str) -> Dict:
        """Generate a comprehensive call prep brief"""
        genome = self.db.get_genome(genome_id)
        if not genome:
            return {"error": "Prospect not found"}
        
        brief = {
            "header": {
                "business": genome.business_name,
                "contact": f"{genome.contact_name} ({genome.contact_role})",
                "phone": genome.phone,
                "city": genome.city,
                "type": genome.business_type
            },
            "intelligence_summary": {
                "buyer_type": genome.decision.buyer_type.value if genome.decision.buyer_type else "Unknown",
                "urgency": genome.urgency.value,
                "authority": genome.decision.authority.value if genome.decision.authority else "Unknown",
                "deal_score": genome.get_deal_score()['score'],
                "rapport": genome.rapport_level
            },
            "approach_guidance": self._get_approach_guidance(genome),
            "pain_points": [
                {
                    "pain": pp.description,
                    "severity": pp.severity,
                    "quote": pp.quotes[0] if pp.quotes else None
                }
                for pp in sorted(genome.pain_points, key=lambda x: -x.severity)[:3]
            ],
            "open_objections": [
                {
                    "type": o.objection_type.value,
                    "statement": o.statement,
                    "handling_tip": self._get_objection_tip(o.objection_type)
                }
                for o in genome.objections if not o.addressed
            ],
            "questions_to_ask": self._generate_discovery_questions(genome),
            "talking_points": self._generate_talking_points(genome),
            "danger_zones": self._identify_danger_zones(genome),
            "close_readiness": self._assess_close_readiness(genome),
            "personal_notes": genome.personal_notes[-5:] if genome.personal_notes else [],
            "history": {
                "total_calls": len(genome.calls),
                "total_time": genome.total_call_time_minutes,
                "last_interaction": genome.updated_at.isoformat() if genome.updated_at else None
            }
        }
        
        return brief
    
    def _get_approach_guidance(self, genome: ProspectGenome) -> Dict:
        """Get communication approach based on buyer type"""
        approaches = {
            BuyerType.ANALYTICAL: {
                "tone": "Professional, data-driven",
                "pace": "Methodical, allow pauses",
                "focus": "ROI, metrics, proof points",
                "do": ["Provide specific numbers", "Reference case studies", "Be precise"],
                "dont": ["Rush them", "Make claims without proof", "Be too casual"]
            },
            BuyerType.DRIVER: {
                "tone": "Direct, confident",
                "pace": "Fast, efficient",
                "focus": "Results, competitive advantage, control",
                "do": ["Get to the point", "Give options", "Respect their time"],
                "dont": ["Ramble", "Over-explain", "Be passive"]
            },
            BuyerType.EXPRESSIVE: {
                "tone": "Enthusiastic, warm",
                "pace": "Energetic, collaborative",
                "focus": "Vision, possibilities, recognition",
                "do": ["Share stories", "Paint the picture", "Show excitement"],
                "dont": ["Bog down in details", "Be boring", "Ignore relationship"]
            },
            BuyerType.AMIABLE: {
                "tone": "Warm, supportive",
                "pace": "Relaxed, patient",
                "focus": "Security, support, consensus",
                "do": ["Build trust first", "Offer guarantees", "Include their team"],
                "dont": ["Pressure", "Rush decisions", "Dismiss concerns"]
            }
        }
        
        buyer_type = genome.decision.buyer_type or BuyerType.ANALYTICAL
        return approaches.get(buyer_type, approaches[BuyerType.ANALYTICAL])
    
    def _get_objection_tip(self, objection_type: ObjectionType) -> str:
        """Get handling tip for objection type"""
        tips = {
            ObjectionType.PRICE: "Reframe to ROI. What's the cost of NOT solving this?",
            ObjectionType.TIMING: "Create urgency. What are they losing every day they wait?",
            ObjectionType.AUTHORITY: "Ask who else should be involved. Offer to present to group.",
            ObjectionType.NEED: "Dig deeper into pain. They haven't felt it enough yet.",
            ObjectionType.TRUST: "Offer case studies, references, or a pilot.",
            ObjectionType.COMPETITOR: "Don't trash talk. Focus on unique differentiation.",
            ObjectionType.TECHNICAL: "Bring in technical resource if needed. Address specifics.",
            ObjectionType.CHANGE_RESISTANCE: "Emphasize ease of implementation and support."
        }
        return tips.get(objection_type, "Acknowledge, explore, address")
    
    def _generate_discovery_questions(self, genome: ProspectGenome) -> List[str]:
        """Generate discovery questions based on gaps in profile"""
        questions = []
        
        # If we don't know trigger event
        if not genome.trigger_event:
            questions.append("What made you interested in exploring this now?")
        
        # If we don't know urgency
        if genome.urgency == UrgencyLevel.UNKNOWN:
            questions.append("What's your timeline for making a decision on this?")
        
        # If we don't know authority
        if genome.decision.authority == DecisionAuthority.UNKNOWN:
            questions.append("Who else would need to be involved in this decision?")
        
        # If we don't have pain points
        if not genome.pain_points:
            questions.append("What's your biggest challenge with guest inquiries right now?")
            questions.append("What happens to inquiries that come in after hours?")
        
        # If we don't know current solution
        if not genome.current_solution:
            questions.append("How are you handling this today?")
        
        # Budget discovery
        if genome.budget.signal == BudgetSignal.UNKNOWN:
            questions.append("What kind of investment were you expecting for a solution like this?")
        
        # Standard power questions
        questions.extend([
            "If you could wave a magic wand, what would change?",
            "What would success look like 6 months from now?",
            "What's the cost of not solving this?"
        ])
        
        return questions[:6]  # Return top 6
    
    def _generate_talking_points(self, genome: ProspectGenome) -> List[str]:
        """Generate talking points based on profile"""
        points = []
        
        # Based on business type
        type_points = {
            "hotel": [
                "67% of hotel inquiries go unanswered after hours",
                "78% of guests book with whoever responds first",
                "Our clients recover $X in previously lost bookings"
            ],
            "villa": [
                "Villa guests expect instant, personalized responses",
                "We handle multiple languages automatically",
                "Integrates with your booking system"
            ],
            "restaurant": [
                "Reservation requests at 2am shouldn't wait until morning",
                "We capture dietary preferences before they arrive",
                "Reduce no-shows with automated confirmations"
            ]
        }
        
        if genome.business_type and genome.business_type.lower() in type_points:
            points.extend(type_points[genome.business_type.lower()])
        
        # Based on pain points
        for pp in genome.pain_points[:2]:
            if "unanswered" in pp.description.lower():
                points.append(f"You mentioned {pp.description} - we solve that automatically")
            if "after hours" in pp.description.lower():
                points.append("24/7 coverage without 24/7 staff")
        
        # Based on buyer type
        if genome.decision.buyer_type == BuyerType.ANALYTICAL:
            points.append("I can share our ROI calculator with specific numbers")
        elif genome.decision.buyer_type == BuyerType.DRIVER:
            points.append("We can have you live within 48 hours")
        
        return points[:5]
    
    def _identify_danger_zones(self, genome: ProspectGenome) -> List[str]:
        """Identify potential deal killers"""
        dangers = []
        
        # Unaddressed objections
        unaddressed = [o for o in genome.objections if not o.addressed]
        if len(unaddressed) >= 2:
            dangers.append(f"⚠️ {len(unaddressed)} unaddressed objections - must handle before close")
        
        # Low rapport
        if genome.rapport_level < 4:
            dangers.append("⚠️ Low rapport - focus on relationship building first")
        
        # Gatekeeper
        if genome.decision.authority == DecisionAuthority.GATEKEEPER:
            dangers.append("⚠️ Talking to gatekeeper - need to get to decision maker")
        
        # Price sensitivity + constrained budget
        if genome.budget.signal == BudgetSignal.BUDGET_CONSTRAINED:
            dangers.append("⚠️ Budget constrained - lead with ROI, not features")
        
        # Change resistance
        if genome.decision.change_readiness == "resistant":
            dangers.append("⚠️ Change resistant - emphasize low risk and support")
        
        # Competitor presence
        if genome.competitors_mentioned:
            dangers.append(f"⚠️ Evaluating competitors - be ready to differentiate")
        
        return dangers
    
    def _assess_close_readiness(self, genome: ProspectGenome) -> Dict:
        """Assess how ready this prospect is to close"""
        score_data = genome.get_deal_score()
        
        ready_signals = []
        not_ready_signals = []
        
        # Check signals
        if genome.urgency in [UrgencyLevel.BLEEDING, UrgencyLevel.URGENT]:
            ready_signals.append("High urgency")
        else:
            not_ready_signals.append("No urgency established")
        
        if genome.decision.authority == DecisionAuthority.SOLE_DECISION_MAKER:
            ready_signals.append("Decision maker identified")
        elif genome.decision.authority == DecisionAuthority.UNKNOWN:
            not_ready_signals.append("Authority unclear")
        
        if genome.pain_points and max(pp.severity for pp in genome.pain_points) >= 7:
            ready_signals.append("Strong pain identified")
        else:
            not_ready_signals.append("Pain not strong enough")
        
        unaddressed = [o for o in genome.objections if not o.addressed]
        if not unaddressed:
            ready_signals.append("No open objections")
        else:
            not_ready_signals.append(f"{len(unaddressed)} objections to address")
        
        if genome.rapport_level >= 7:
            ready_signals.append("Good rapport")
        
        return {
            "score": score_data['score'],
            "likelihood": score_data['likelihood'],
            "ready_signals": ready_signals,
            "blockers": not_ready_signals,
            "recommended_close": "direct" if score_data['score'] >= 70 else "trial" if score_data['score'] >= 50 else "nurture",
            "closing_question": genome.get_closing_strategy()['closing_question']
        }
    
    def print_brief(self, genome_id: str):
        """Print a formatted call brief to console"""
        brief = self.generate_call_brief(genome_id)
        
        if "error" in brief:
            print(f"Error: {brief['error']}")
            return
        
        print("\n" + "="*60)
        print("📞 CALL PREP BRIEF")
        print("="*60)
        
        print(f"\n🏢 {brief['header']['business']}")
        print(f"👤 {brief['header']['contact']}")
        print(f"📱 {brief['header']['phone']}")
        print(f"📍 {brief['header']['city']} | {brief['header']['type']}")
        
        print(f"\n📊 INTELLIGENCE")
        print(f"   Buyer Type: {brief['intelligence_summary']['buyer_type']}")
        print(f"   Urgency: {brief['intelligence_summary']['urgency']}")
        print(f"   Authority: {brief['intelligence_summary']['authority']}")
        print(f"   Deal Score: {brief['intelligence_summary']['deal_score']}/100")
        print(f"   Rapport: {brief['intelligence_summary']['rapport']}/10")
        
        print(f"\n🎯 APPROACH")
        approach = brief['approach_guidance']
        print(f"   Tone: {approach['tone']}")
        print(f"   Pace: {approach['pace']}")
        print(f"   Focus: {approach['focus']}")
        
        if brief['pain_points']:
            print(f"\n💔 TOP PAIN POINTS")
            for pp in brief['pain_points']:
                print(f"   [{pp['severity']}/10] {pp['pain']}")
                if pp['quote']:
                    print(f"         \"{pp['quote']}\"")
        
        if brief['open_objections']:
            print(f"\n⚠️ OPEN OBJECTIONS")
            for obj in brief['open_objections']:
                print(f"   • {obj['type'].upper()}: {obj['statement']}")
                print(f"     Tip: {obj['handling_tip']}")
        
        print(f"\n❓ QUESTIONS TO ASK")
        for q in brief['questions_to_ask']:
            print(f"   • {q}")
        
        if brief['danger_zones']:
            print(f"\n🚨 DANGER ZONES")
            for d in brief['danger_zones']:
                print(f"   {d}")
        
        print(f"\n✅ CLOSE READINESS: {brief['close_readiness']['likelihood']}")
        print(f"   Recommended: {brief['close_readiness']['recommended_close'].upper()} close")
        print(f"   Question: {brief['close_readiness']['closing_question']}")
        
        print("\n" + "="*60 + "\n")


# Quick CLI usage
if __name__ == "__main__":
    import sys
    
    db = ProspectDatabase()
    prep = CallPrepGenerator(db)
    
    if len(sys.argv) > 1:
        # Look up by business name
        genome = db.find_by_business(sys.argv[1])
        if genome:
            prep.print_brief(genome.genome_id)
        else:
            print(f"No prospect found matching: {sys.argv[1]}")
    else:
        # Show follow-ups due
        print("\n📅 FOLLOW-UPS DUE:")
        for g in db.get_follow_ups_due(7):
            print(f"  • {g.business_name} ({g.contact_name}) - {g.follow_up_date}")
        
        print("\n🔥 HOT PROSPECTS:")
        for g in db.get_hot_prospects(60):
            print(f"  • {g.business_name} - Score: {g.get_deal_score()['score']}")
