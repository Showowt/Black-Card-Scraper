"""
GENOME PROTOCOL™
================
Customer Intelligence Through Service, Not Interrogation.

A MachineMind AI Framework for building complete customer profiles
through natural conversation flows.

(c) 2024 MachineMind AI Automation Agency
"""

from .core.models import (
    GenomeProfile,
    SignalCapture,
    ConfidenceLevel,
    CollectionMechanism,
    CommunicationDNA,
    DecisionDNA,
    SensoryDNA,
    EmotionalFingerprint,
    RelationshipContext,
    ContextMemory
)

from .core.database import GenomeDatabase, get_database
from .core.engine import GenomeEngine, GenomeCollectionHooks

from .flows.templates import (
    ConversationFlow,
    FlowStep,
    FlowExecutor,
    get_flow,
    get_all_flows,
    BOOKING_FLOW,
    RESTAURANT_FLOW,
    CONCIERGE_FLOW,
    CHECK_IN_FLOW
)

from .api.server import GenomeSDK, create_app

# B2B Sales Intelligence
from .core.prospect_models import (
    ProspectGenome,
    BuyerType,
    UrgencyLevel,
    DecisionAuthority,
    BudgetSignal,
    ObjectionType,
    PainPoint,
    Objection,
    CallSignal
)

from .core.prospect_database import ProspectDatabase, CallPrepGenerator

__version__ = "1.0.0"
__author__ = "MachineMind AI"

__all__ = [
    # Models
    'GenomeProfile',
    'SignalCapture',
    'ConfidenceLevel',
    'CollectionMechanism',
    'CommunicationDNA',
    'DecisionDNA',
    'SensoryDNA',
    'EmotionalFingerprint',
    'RelationshipContext',
    'ContextMemory',
    
    # Database
    'GenomeDatabase',
    'get_database',
    
    # Engine
    'GenomeEngine',
    'GenomeCollectionHooks',
    
    # Flows
    'ConversationFlow',
    'FlowStep',
    'FlowExecutor',
    'get_flow',
    'get_all_flows',
    'BOOKING_FLOW',
    'RESTAURANT_FLOW',
    'CONCIERGE_FLOW',
    'CHECK_IN_FLOW',
    
    # API
    'GenomeSDK',
    'create_app',
    
    # B2B Prospect Genome
    'ProspectGenome',
    'BuyerType',
    'UrgencyLevel',
    'DecisionAuthority',
    'BudgetSignal',
    'ObjectionType',
    'PainPoint',
    'Objection',
    'CallSignal',
    'ProspectDatabase',
    'CallPrepGenerator'
]
