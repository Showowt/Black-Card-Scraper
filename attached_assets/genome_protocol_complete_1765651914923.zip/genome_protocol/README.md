# GENOME PROTOCOL™

## Customer & Prospect Intelligence Through Service, Not Interrogation

A complete intelligence-gathering system for MachineMind AI Automation Agency.

---

## 🧬 Two Systems, One Philosophy

### 1. Guest Genome (B2C) - For Your Hospitality Clients
Build complete guest profiles during service conversations. Every chatbot interaction captures preference signals without forms or interrogation.

### 2. Prospect Genome (B2B) - For Your Sales Calls
Build prospect profiles during sales calls. Know exactly how to close based on real-time behavioral signals.

---

## 📁 System Architecture

```
genome_protocol/
├── core/
│   ├── models.py              # Guest DNA schema (CommunicationDNA, DecisionDNA, etc.)
│   ├── database.py            # SQLite database for guest profiles
│   ├── engine.py              # Signal extraction engine
│   ├── prospect_models.py     # Prospect DNA schema (BuyerType, Urgency, etc.)
│   └── prospect_database.py   # Prospect database + call prep generator
├── flows/
│   └── templates.py           # Pre-built conversation flows (booking, restaurant, etc.)
├── api/
│   └── server.py              # REST API + SDK for chatbot integration
└── dashboard/
    ├── guest_intelligence.html    # Client-facing analytics dashboard
    └── sales_call_companion.html  # Real-time sales call tool
```

---

## 🎯 Using the Sales Call Companion

### Quick Start
1. Open `dashboard/sales_call_companion.html` in your browser
2. Enter prospect info (or it pre-loads from your database)
3. Click "Start Call" when you dial
4. Capture signals with one-click buttons as you talk
5. Get real-time closing recommendations

### Signal Capture Flow

**Before the call:**
- Review the auto-generated Call Prep Brief
- Note pain points from previous calls
- Check unaddressed objections

**During the call:**
1. **Identify Buyer Type** (first 2 minutes)
   - Analytical: Asks about data, ROI, proof
   - Driver: Wants bottom line, fast-paced
   - Expressive: Talks about vision, relationships
   - Amiable: Risk-averse, asks about support

2. **Capture Signals** (ongoing)
   - Click urgency level when revealed
   - Log objections as they arise
   - Add pain points with severity
   - Capture key quotes verbatim

3. **Monitor Deal Score** (updates in real-time)
   - 70+ = Push for close
   - 40-70 = Address objections
   - <40 = Qualify harder or nurture

**After the call:**
- Add next action + follow-up date
- Export profile to JSON
- Review closing strategy for next call

---

## 🏨 Guest Genome Integration

### SDK Quick Start

```python
from genome_protocol import GenomeSDK

# Initialize
sdk = GenomeSDK(db_path="your_database.db")

# Process every incoming message
result = sdk.process(
    property_id="hotel_casa_san_agustin",
    guest_id="+573001234567",
    message="Hola, quisiera reservar una habitación con vista al mar"
)

# Result includes:
# - genome_id: unique guest identifier
# - intent: booking_inquiry
# - sentiment: neutral
# - personalization: how to communicate with this guest
# - suggestions: personalized response options
# - collection_hooks: opportunities to capture more data
```

### Collection Mechanisms

1. **Preference Cascade** - Binary micro-choices
   ```
   "¿Prefieres llegada temprano o check-in estándar de las 3pm?"
   ```
   → Captures: chronotype (early_bird / moderate)

2. **Concierge Capture** - Choice reveals preference
   ```
   "Aquí hay tres opciones. ¿Cuál te llama más la atención?"
   ```
   → Captures: price_sensitivity, decision_style

3. **Relief Reveal** - Care-framed extraction
   ```
   "¿Alguna alergia que deba comunicar al chef?"
   ```
   → Captures: dietary_restrictions

4. **Anticipation Engine** - Predict and confirm
   ```
   "Imagino que preferirías la mesa tranquila—¿acierto?"
   ```
   → Confirms/corrects: environment_preference

5. **Mirror Moment** - Profile review
   ```
   "Basado en nuestras conversaciones, aquí está lo que sé de tus preferencias..."
   ```
   → Allows guest to correct/enhance

6. **Reward Loop** - Show personalization value
   ```
   "Como preferiste llegada temprano, ya coordiné tu habitación para las 11am."
   ```
   → Reinforces value of sharing preferences

---

## 💰 Monetization Layers

### For Your Clients (Tier Upgrades)

| Tier | Price | Genome Features |
|------|-------|-----------------|
| Starter | $290/mo | Basic preference tracking |
| Professional | $590/mo | Full Genome profiles + returning guest recognition |
| Enterprise | $1,090/mo | Predictive preferences + cross-property intelligence |

### New Revenue Stream: Guest Intelligence Briefings

Monthly reports for clients ($200-500/mo):
- Top preference patterns
- High-value guest profiles
- Personalization opportunities
- VIP alert system

---

## 🔒 Lock-In Mechanism

After 6 months of Genome collection:
- Your AI knows their guests better than they do
- Switching means losing the intelligence asset
- The data compound effect creates dependency

---

## 📊 API Endpoints

### Guest Genome API

```
POST /api/v1/messages/process     - Process message, extract signals
POST /api/v1/profiles             - Create guest profile
GET  /api/v1/profiles/{id}        - Get profile
GET  /api/v1/profiles/{id}/insights - Get personalization insights
POST /api/v1/flows/start          - Start guided conversation flow
POST /api/v1/flows/respond        - Continue flow
GET  /api/v1/properties/{id}/stats - Get property analytics
GET  /api/v1/properties/{id}/vips  - Get VIP guests
```

### Running the API

```bash
cd genome_protocol
pip install flask
python -m api.server
# API runs on http://localhost:5000
```

---

## 🚀 Implementation Roadmap

### Week 1
- [ ] Add 3 Genome hooks to existing chatbot templates
- [ ] Start using Sales Call Companion for all prospect calls

### Week 2-3
- [ ] Deploy database schema
- [ ] Begin logging all signals

### Month 1
- [ ] Launch Guest Intelligence Dashboard for first client
- [ ] Collect baseline data

### Month 2
- [ ] Introduce Genome as premium tier feature
- [ ] Create first Guest Intelligence Briefing report

### Month 3+
- [ ] Cross-property intelligence (for chains)
- [ ] Predictive preference engine
- [ ] API for third-party integrations

---

## 🧠 The Psychology

**Why it works:**
- Data is a byproduct of value, not the goal
- Questions framed as care, not extraction
- Binary choices feel like decisions, not interrogation
- Predictions feel personal, not invasive
- Corrections feel empowering, not demanding

**The compound effect:**
- Each interaction adds signal
- Profile completeness grows naturally
- Personalization improves
- Guest feels understood
- They share more
- Cycle reinforces

---

## License

Proprietary - MachineMind AI Automation Agency
GENOME PROTOCOL™ is intellectual property of MachineMind.

---

*"Revelation through relief"* - Build intelligence through service, not extraction.
