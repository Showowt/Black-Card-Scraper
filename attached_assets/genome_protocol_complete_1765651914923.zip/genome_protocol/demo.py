#!/usr/bin/env python3
"""
GENOME PROTOCOL™ - Interactive Demo
=====================================
Demonstrates the complete Genome Protocol system in action.
Run this to see how guest intelligence is built through service.

Usage:
    python demo.py [--interactive]
"""

import sys
import json
from datetime import datetime, timedelta
from typing import List

# Add parent to path for imports
sys.path.insert(0, '/home/claude/genome_protocol')

from core.models import GenomeProfile, SignalCapture, ConfidenceLevel, CollectionMechanism
from core.database import GenomeDatabase, get_database
from core.engine import GenomeEngine, GenomeCollectionHooks
from flows.templates import FlowExecutor, get_flow, BOOKING_FLOW
from reports.intelligence_report import IntelligenceReportGenerator
from config.pricing import get_all_tiers, get_value_comparison


def print_header(title: str):
    """Print formatted section header"""
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60 + "\n")


def print_subheader(title: str):
    """Print formatted subsection header"""
    print(f"\n--- {title} ---\n")


def demo_basic_signal_extraction():
    """Demo: Extract signals from conversation messages"""
    print_header("DEMO 1: Signal Extraction from Conversations")
    
    # Initialize
    db = get_database(":memory:")  # In-memory for demo
    engine = GenomeEngine(db)
    
    # Simulate conversation messages
    messages = [
        "Hola! Estoy buscando una habitación para mi esposa y yo para nuestro aniversario",
        "Somos vegetarianos, es posible que el restaurante tenga opciones?",
        "Preferiríamos una habitación tranquila, lejos del ruido",
        "Llegamos temprano, como a las 10am, es posible el early check-in?",
        "El precio está bien, queremos la suite con vista al mar 🌊"
    ]
    
    property_id = "demo_hotel"
    guest_phone = "+573001234567"
    
    print("Processing guest conversation...\n")
    
    for i, message in enumerate(messages, 1):
        print(f"Message {i}: \"{message}\"")
        
        profile, result = engine.process_message(
            property_id=property_id,
            guest_identifier=guest_phone,
            message=message,
            channel="whatsapp",
            direction="inbound"
        )
        
        if result.signals:
            print(f"  → Signals captured:")
            for signal in result.signals:
                print(f"     • {signal.field}: {signal.value} (confidence: {signal.confidence.name})")
        
        print(f"  → Intent: {result.inferred_intent}")
        print(f"  → Sentiment: {result.sentiment}")
        print()
    
    # Show final profile
    print_subheader("Final Guest Profile After Conversation")
    print(f"Profile Completeness: {profile.profile_completeness:.1f}%")
    print(f"Total Signals Captured: {profile.total_signals_captured}")
    print(f"\nKey Insights:")
    print(f"  • Travel Style: {profile.relationship.travel_companions}")
    print(f"  • Occasion: {profile.relationship.occasion_types}")
    print(f"  • Dietary: {profile.sensory.dietary_restrictions}")
    print(f"  • Environment: {profile.sensory.environment_preference}")
    print(f"  • Chronotype: {profile.sensory.chronotype}")
    print(f"  • Price Sensitivity: {profile.decision.price_sensitivity_index}/100")
    print(f"  • Emoji Usage: {profile.communication.emoji_usage}")
    
    return profile, engine


def demo_collection_hooks():
    """Demo: The six zero-form collection mechanisms"""
    print_header("DEMO 2: Genome Collection Hooks (Zero-Form Data Collection)")
    
    hooks = GenomeCollectionHooks()
    
    print("The Genome Protocol uses 6 collection mechanisms:\n")
    
    mechanisms = [
        ("1. PREFERENCE CASCADE", "Binary micro-choices embedded in service"),
        ("2. CONCIERGE CAPTURE", "Choice reveals budget/preference"),
        ("3. RELIEF REVEAL", "Care-framed questions extract data"),
        ("4. ANTICIPATION ENGINE", "Predict and let them confirm/deny"),
        ("5. MIRROR MOMENT", "Show profile, let them correct"),
        ("6. REWARD LOOP", "Demonstrate value of sharing"),
    ]
    
    for name, desc in mechanisms:
        print(f"  {name}")
        print(f"     {desc}\n")
    
    # Show example hooks
    print_subheader("Example: Preference Cascade Options")
    cascade_options = hooks.preference_cascade_options()
    
    for flow_name, options in cascade_options.items():
        print(f"\n{flow_name.upper()} FLOW:")
        for opt in options[:2]:  # Show first 2
            print(f"  Question: \"{opt['question']}\"")
            print(f"  → Captures: {opt['signal_field']}")
            print()


def demo_conversation_flow():
    """Demo: Guided conversation flow with embedded hooks"""
    print_header("DEMO 3: Booking Flow with Genome Hooks")
    
    db = get_database(":memory:")
    engine = GenomeEngine(db)
    executor = FlowExecutor(engine)
    
    property_id = "hotel_demo"
    guest_phone = "+573009876543"
    
    print("Starting booking conversation flow...\n")
    
    # Start flow
    result = executor.start_flow("booking", property_id, guest_phone)
    print(f"BOT: {result['message']}")
    print(f"     [Hook: {result.get('genome_hook', 'None')}]\n")
    
    # Simulate responses
    responses = [
        "Para el 15 de enero, 3 noches",
        "Temprano mejor, llegamos en vuelo de la mañana",
        "Viajamos mi esposa y yo",
        "Me gusta la segunda opción, la suite",
        "Soy alérgico a los mariscos",
        "Sí, es nuestro aniversario!",
        "WhatsApp está perfecto"
    ]
    
    for response in responses:
        print(f"GUEST: {response}")
        result = executor.process_response(result['session_id'], response)
        print(f"BOT: {result['message'][:200]}...")
        if result.get('genome_hook'):
            print(f"     [Hook: {result['genome_hook']}]")
        if result.get('signals_captured'):
            print(f"     [Signals captured: {result['signals_captured']}]")
        print()
        
        if result.get('flow_complete'):
            break
    
    # Show final profile
    profile = engine.db.find_profile(property_id, guest_phone)
    print_subheader("Profile Built During Booking")
    print(f"Completeness: {profile.profile_completeness:.1f}%")
    insights = profile.get_personalization_insights()
    print(f"\nPersonalization Insights:")
    print(f"  Greeting Style: {insights['greeting_style']}")
    print(f"  Communication Tips: {insights['communication_tips'][:2]}")
    print(f"  Upsell Opportunities: {len(insights['upsell_opportunities'])}")


def demo_returning_guest():
    """Demo: Returning guest recognition"""
    print_header("DEMO 4: Returning Guest Recognition")
    
    db = get_database(":memory:")
    engine = GenomeEngine(db)
    
    property_id = "hotel_demo"
    guest_phone = "+573001112222"
    
    # Create an existing profile with history
    profile = db.create_profile(
        property_id=property_id,
        whatsapp=guest_phone,
        name="María García",
        first_name="María"
    )
    
    # Add some history
    profile.relationship.travel_companions = "couple"
    profile.sensory.dietary_restrictions = ["vegetarian"]
    profile.sensory.room_preferences = ["high_floor", "ocean_view"]
    profile.decision.upgrade_propensity = 75
    profile.communication.emoji_usage = "frequent"
    profile.lifetime_value = 2500.0
    profile.total_interactions = 15
    profile.profile_completeness = 68.0
    db.update_profile(profile)
    
    print("Simulating returning guest inquiry...\n")
    
    # New message from returning guest
    message = "Hola, quiero hacer otra reserva para febrero"
    
    profile, result = engine.process_message(
        property_id=property_id,
        guest_identifier=guest_phone,
        message=message,
        channel="whatsapp",
        direction="inbound"
    )
    
    print(f"GUEST: \"{message}\"\n")
    
    # Show recognition
    print("🌟 RETURNING GUEST DETECTED 🌟\n")
    print(f"Name: {profile.name}")
    print(f"Previous Interactions: {profile.total_interactions}")
    print(f"Lifetime Value: ${profile.lifetime_value:,.2f}")
    print(f"Profile Completeness: {profile.profile_completeness}%")
    
    print("\nKnown Preferences:")
    print(f"  • Travel Style: {profile.relationship.travel_companions}")
    print(f"  • Dietary: {', '.join(profile.sensory.dietary_restrictions)}")
    print(f"  • Room Preferences: {', '.join(profile.sensory.room_preferences)}")
    print(f"  • Upgrade Propensity: {profile.decision.upgrade_propensity}% (HIGH)")
    
    print("\nPersonalized Response Suggestion:")
    if result.suggested_responses:
        print(f"  \"{result.suggested_responses[0]}\"")
    
    print("\n📈 Upsell Alert: High upgrade propensity - offer suite upgrade!")


def demo_intelligence_report():
    """Demo: Generate client intelligence report"""
    print_header("DEMO 5: Guest Intelligence Report Generation")
    
    # Create database with sample data
    db = get_database(":memory:")
    engine = GenomeEngine(db)
    property_id = "hotel_demo"
    
    print("Generating sample data for report...\n")
    
    # Create sample profiles
    sample_guests = [
        {"name": "María García", "ltv": 4500, "completeness": 89, "vip": True},
        {"name": "John Smith", "ltv": 3200, "completeness": 76, "vip": True},
        {"name": "Ana Rodríguez", "ltv": 2100, "completeness": 82, "vip": False},
        {"name": "Carlos Pérez", "ltv": 1800, "completeness": 65, "vip": False},
        {"name": "Guest 5", "ltv": 500, "completeness": 45, "vip": False},
        {"name": "Guest 6", "ltv": 350, "completeness": 32, "vip": False},
        {"name": "Guest 7", "ltv": 200, "completeness": 28, "vip": False},
        {"name": "Guest 8", "ltv": 150, "completeness": 22, "vip": False},
    ]
    
    for i, guest in enumerate(sample_guests):
        profile = db.create_profile(
            property_id=property_id,
            whatsapp=f"+5730012345{i:02d}",
            name=guest["name"]
        )
        profile.lifetime_value = guest["ltv"]
        profile.profile_completeness = guest["completeness"]
        profile.total_interactions = guest["completeness"] // 5
        profile.total_signals_captured = guest["completeness"] // 3
        
        # Add some variety
        if i % 2 == 0:
            profile.sensory.dietary_restrictions = ["vegetarian"]
            profile.relationship.travel_companions = "couple"
        else:
            profile.relationship.travel_companions = "family"
            profile.relationship.occasion_types = ["birthday"]
        
        db.update_profile(profile)
    
    # Generate report
    generator = IntelligenceReportGenerator(db)
    report = generator.generate_report(property_id, period_days=30)
    
    print("📊 GUEST INTELLIGENCE REPORT")
    print("=" * 40)
    print(f"\nProperty: {report['property_id']}")
    print(f"Period: Last {report['period']['days']} days")
    print(f"Generated: {report['generated_at'][:10]}")
    
    print("\n📈 KEY METRICS:")
    metrics = report['metrics']
    print(f"  Total Profiles: {metrics['profiles']['total']}")
    print(f"  Avg Completeness: {metrics['completeness']['average']}%")
    print(f"  VIP Guests: {metrics['value']['vip_guests']}")
    print(f"  Total LTV: ${metrics['value']['total_lifetime_value']:,.2f}")
    
    print("\n💡 TOP INSIGHTS:")
    for insight in report['insights'][:3]:
        print(f"\n  {insight['title']}")
        print(f"  → {insight['detail'][:80]}...")
    
    print("\n🎯 RECOMMENDATIONS:")
    for rec in report['recommendations'][:2]:
        print(f"\n  [{rec['priority'].upper()}] {rec['recommendation']}")
        print(f"  Impact: {rec['expected_impact']}")


def demo_pricing_tiers():
    """Demo: Show pricing tiers with Genome features"""
    print_header("DEMO 6: MachineMind Pricing with Genome Protocol")
    
    tiers = get_all_tiers()
    
    for tier in tiers:
        print(f"\n{'⭐' * (tiers.index(tier) + 1)} {tier.name.upper()} - ${tier.monthly_price}/month")
        print(f"   \"{tier.tagline}\"")
        print(f"\n   Core Features:")
        print(f"   • {tier.conversations_per_month if tier.conversations_per_month > 0 else 'Unlimited'} conversations/month")
        print(f"   • {', '.join(tier.channels)} channels")
        print(f"   • {len(tier.languages)} languages")
        
        print(f"\n   Genome Protocol Features:")
        genome = tier.genome
        print(f"   • Basic Tracking: {'✓' if genome.basic_preference_tracking else '✗'}")
        print(f"   • Full Profiles: {'✓' if genome.full_genome_profiles else '✗'}")
        print(f"   • Returning Guest Recognition: {'✓' if genome.returning_guest_recognition else '✗'}")
        print(f"   • Predictive Preferences: {'✓' if genome.predictive_preferences else '✗'}")
        print(f"   • Intelligence Reports: {genome.report_frequency or '✗'}")
        print(f"   • API Access: {'✓' if genome.api_access else '✗'}")
    
    # Show value comparison
    print_subheader("Value vs. Local Employee")
    comparison = get_value_comparison()
    
    print("MachineMind Starter ($290/mo) vs. Colombian Receptionist ($450/mo):")
    print("\n  MachineMind advantages:")
    for point in comparison['key_points'][:5]:
        print(f"    ✓ {point}")
    
    roi = comparison['roi_calculation']
    print(f"\n  ROI Calculation:")
    print(f"    • 50 captured inquiries/month × 25% conversion × $350 avg")
    print(f"    • = ${roi['monthly_revenue_from_captured']:,}/month revenue")
    print(f"    • ROI: {roi['roi_percentage']}%")


def run_interactive_demo():
    """Run interactive demo allowing user to test the system"""
    print_header("INTERACTIVE GENOME PROTOCOL DEMO")
    
    db = get_database("demo_genome.db")
    engine = GenomeEngine(db)
    
    property_id = "interactive_demo"
    guest_phone = "+573001234567"
    
    print("Type messages to see Genome Protocol in action.")
    print("Commands: /profile, /insights, /quit\n")
    
    while True:
        try:
            message = input("You: ").strip()
            
            if message == "/quit":
                break
            elif message == "/profile":
                profile = engine.db.find_profile(property_id, guest_phone)
                if profile:
                    print(f"\n{json.dumps(profile.to_dict(), indent=2, default=str)[:2000]}...")
                continue
            elif message == "/insights":
                profile = engine.db.find_profile(property_id, guest_phone)
                if profile:
                    insights = profile.get_personalization_insights()
                    print(f"\n{json.dumps(insights, indent=2)}")
                continue
            
            if not message:
                continue
            
            profile, result = engine.process_message(
                property_id=property_id,
                guest_identifier=guest_phone,
                message=message,
                channel="whatsapp",
                direction="inbound"
            )
            
            print(f"\n[Intent: {result.inferred_intent} | Sentiment: {result.sentiment}]")
            if result.signals:
                print(f"[Signals: {[s.field for s in result.signals]}]")
            print(f"[Profile: {profile.profile_completeness:.1f}% complete]\n")
            
            if result.suggested_responses:
                print(f"Bot: {result.suggested_responses[0]}\n")
                
        except KeyboardInterrupt:
            break
    
    print("\nDemo complete!")


def main():
    """Run all demos"""
    print("\n" + "🧬" * 30)
    print("\n   GENOME PROTOCOL™ DEMONSTRATION")
    print("   Customer Intelligence Through Service")
    print("   MachineMind AI Automation Agency")
    print("\n" + "🧬" * 30)
    
    if len(sys.argv) > 1 and sys.argv[1] == "--interactive":
        run_interactive_demo()
    else:
        # Run all demos
        demo_basic_signal_extraction()
        input("\nPress Enter to continue to next demo...")
        
        demo_collection_hooks()
        input("\nPress Enter to continue to next demo...")
        
        demo_conversation_flow()
        input("\nPress Enter to continue to next demo...")
        
        demo_returning_guest()
        input("\nPress Enter to continue to next demo...")
        
        demo_intelligence_report()
        input("\nPress Enter to continue to next demo...")
        
        demo_pricing_tiers()
        
        print_header("DEMO COMPLETE")
        print("The Genome Protocol transforms every conversation into")
        print("permanent guest intelligence - no forms, no friction.")
        print("\nThis is how MachineMind creates unbeatable lock-in:")
        print("After 6 months, you know guests better than they know themselves.")
        print("\n" + "🧬" * 30 + "\n")


if __name__ == "__main__":
    main()
