"""GENOME PROTOCOL™ - Intelligence Reports"""

from .intelligence_report import (
    IntelligenceReportGenerator,
    generate_client_report,
    ReportMetrics
)
