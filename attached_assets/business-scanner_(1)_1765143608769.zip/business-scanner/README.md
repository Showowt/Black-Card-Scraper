# Black Card Business Scanner

> Own the map of monetizable businesses. Prospecting engine for your AI automation empire.

## What This Does

Scrapes, normalizes, enriches, and stores business data from:
- **Google Places API** - Primary source for restaurants, hotels, clubs, spas, tour operators
- **Website Metadata** - Emails, phones, social links, booking detection
- **AI Enrichment** - Classification, opportunity scoring, personalized outreach hooks

Outputs to:
- **Supabase** - Centralized database for all your tools
- **CSV/JSON** - CRM imports, outreach campaigns
- **Movvia Format** - Direct vendor import
- **Outreach Lists** - Pre-scored with AI-generated openers

## Quick Start

### 1. Environment Setup

```bash
# Copy environment template
cp .env.example .env

# Edit .env with your keys:
# - SUPABASE_URL
# - SUPABASE_KEY  
# - GOOGLE_PLACES_API_KEY
# - OPENAI_API_KEY
```

### 2. Install Dependencies

```bash
# In Replit, dependencies install automatically from pyproject.toml
# Or manually:
pip install -r requirements.txt
```

### 3. Database Setup

Run the SQL schema in your Supabase SQL Editor:

```bash
python main.py setup
```

This prints the schema. Copy and run it in Supabase.

### 4. Scan Your First City

```bash
# Scan Cartagena restaurants
python main.py scan --city Cartagena --category restaurant --max 50

# Scan hotels
python main.py scan --city Cartagena --category hotel --max 30

# Scan without saving (test mode)
python main.py scan --city Medellín --category club --no-save
```

## Commands

### `scan` - Core scanning command
```bash
python main.py scan \
  --city Cartagena \
  --category restaurant \
  --max 60 \
  --enrich \
  --save \
  --export restaurants.csv
```

Options:
- `--city`, `-c`: City to scan (Cartagena, Medellín, Bogotá, Santa Marta, Barranquilla)
- `--category`, `-cat`: Business category (see below)
- `--max`, `-m`: Maximum results (default: 60)
- `--enrich/--no-enrich`: Run AI enrichment (default: enabled)
- `--save/--no-save`: Save to Supabase (default: enabled)
- `--export`, `-e`: Export to CSV path

### `search` - Text search for specific queries
```bash
python main.py search "rooftop bar" --city Cartagena
python main.py search "party boat tour" --city Cartagena
python main.py search "boutique hotel old town" --city Cartagena
```

### `export` - Export from database
```bash
# All businesses to CSV
python main.py export --output all_businesses.csv

# Filtered export
python main.py export --city Cartagena --min-score 70 --format outreach

# Movvia vendor format
python main.py export --category hotel --format movvia --output movvia_hotels.csv
```

### `stats` - Database statistics
```bash
python main.py stats
python main.py stats --city Cartagena
```

### `categories` - List available categories
```bash
python main.py categories
```

### `cities` - List available cities
```bash
python main.py cities
```

## Categories

| Category | Google Places Types |
|----------|-------------------|
| `restaurant` | restaurant, cafe, bar, bakery, food |
| `hotel` | lodging, hotel, resort, hostel, guest_house |
| `club` | night_club, bar, casino |
| `tour_operator` | travel_agency, tourist_attraction, tour_operator |
| `spa` | spa, beauty_salon, hair_care |
| `real_estate` | real_estate_agency |
| `gym` | gym, fitness_center |
| `coworking` | coworking_space |

## Data Schema

Each business includes:

```json
{
  "name": "La Vitrola",
  "category": "restaurant",
  "subcategory": "Fine Dining",
  "city": "Cartagena",
  "address": "Calle del Baloco...",
  "website": "https://...",
  "contact": {
    "email": "reservas@lavitrola.co",
    "phone": "+573001234567",
    "whatsapp": "https://wa.me/573001234567"
  },
  "socials": {
    "instagram": "https://instagram.com/lavitrola",
    "facebook": "https://facebook.com/lavitrola"
  },
  "rating": 4.7,
  "review_count": 1250,
  "ai_readiness": "high",
  "ai_opportunity_score": 85,
  "ai_outreach_hook": "I noticed La Vitrola's stunning rooftop...",
  "ai_summary": "Upscale restaurant in the walled city..."
}
```

## Integration Points

### Movvia
```python
from services.exporter import Exporter
Exporter.to_movvia_vendors(businesses, "movvia_import.csv")
```

### Outreach CRM
```python
Exporter.to_outreach_csv(businesses, "outreach_list.csv")
```

### AI Content Generation
Query the database for "Top 50 rooftops" content:
```python
from services.storage import SupabaseStorage
storage = SupabaseStorage()
rooftops = await storage.search(
    city="Cartagena",
    min_score=60,
)
```

## API Keys Required

| Service | Purpose | Get It |
|---------|---------|--------|
| Google Places API | Primary data source | [Google Cloud Console](https://console.cloud.google.com) |
| Supabase | Database | [Supabase](https://supabase.com) |
| OpenAI | AI enrichment | [OpenAI Platform](https://platform.openai.com) |

### Google Places API Setup
1. Create project in Google Cloud Console
2. Enable "Places API (New)"
3. Create API key
4. Set budget alerts (costs ~$17/1000 requests for Nearby Search)

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        INPUTS                               │
│  Google Places API │ Website Scraper │ CSV Import           │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                      NORMALIZER                             │
│  Pydantic Models → Clean Data → Dedupe                      │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                     AI ENRICHMENT                           │
│  OpenAI → Classification → Scoring → Outreach Hooks         │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                       STORAGE                               │
│  Supabase Postgres → businesses table                       │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                       OUTPUTS                               │
│  CSV Export │ JSON API │ Movvia │ Outreach Lists            │
└─────────────────────────────────────────────────────────────┘
```

## Cost Estimates

| Operation | Cost |
|-----------|------|
| Google Places Nearby Search | ~$0.017/request (20 results) |
| Google Places Text Search | ~$0.017/request |
| OpenAI GPT-4o-mini enrichment | ~$0.0001/business |
| Supabase | Free tier covers 500MB |

**50 restaurants scan:** ~$0.05 Google + ~$0.01 OpenAI = **~$0.06 total**

## Roadmap

- [ ] Instagram scraper (public profile data)
- [ ] Webhook for new business alerts
- [ ] Dashboard UI (React)
- [ ] Automated weekly scans
- [ ] Competitive intelligence layer

---

Built for the Black Card Vault ecosystem.
