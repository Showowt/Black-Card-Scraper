# Phil McGill Business Intelligence System
## AI-Powered Outreach for Colombian Hospitality

**Built on 47 years of combined sales psychology research.**
**1,400+ successful transformations. $4.7M in documented results.**

---

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Set environment variables
cp .env.example .env
# Edit .env with your API keys

# Scan businesses
python main.py scan --city Cartagena --category restaurant

# Generate outreach-ready package (THE MAIN WEAPON)
python main.py outreach-ready --city Cartagena --min-score 75

# Open dashboard in browser
open outreach_ready/dashboard.html
```

---

## Core Commands

### Data Collection
```bash
python main.py scan -c Cartagena -cat restaurant -m 100
python main.py deep-scan -c Cartagena -cat boat_charter
python main.py search "rooftop bar" -c Cartagena
python main.py intent-scan --time week
python main.py events --days 90 --priority
```

### Outreach Generation
```bash
# Generate full outreach package with dashboard
python main.py outreach-ready --city Cartagena --min-score 70 --limit 30

# Single business deep scan
python main.py phil-scan <business_id> -o outreach.md --proposal

# Batch generation
python main.py phil-batch -c Cartagena --min-score 70 -l 20
```

### Claude AI Co-Pilot (Requires ANTHROPIC_API_KEY)
```bash
# Interactive mode
python main.py copilot

# Response drafting
python main.py respond "their message" -b "Business Name"

# Objection handling
python main.py handle-objection "Es muy caro" -b "Restaurant XYZ"
```

### Authority Content
```bash
python main.py content --type insight --topic "AI for restaurants"
python main.py content-calendar -c Cartagena -cat restaurant
python main.py brand-assets
```

---

## Key Documentation

| File | Purpose |
|------|---------|
| `BLUE_OCEAN_PLAYBOOK.md` | Channel strategy + execution guide |
| `PSYCHOLOGY_CHEATSHEET.md` | Quick reference for 4 frameworks |
| `API_10X_STRATEGY.md` | Claude API integration guide |

---

## Output Files

When you run `outreach-ready`:

| File | Purpose |
|------|---------|
| `dashboard.html` | Interactive dashboard with click-to-copy |
| `quick_actions.csv` | Minimal CSV for rapid outreach |
| `outreach_full.csv` | Full data for CRM |
| `outreach_data.json` | For automations |

---

## Environment Variables

```
GOOGLE_PLACES_API_KEY=your_key
OPENAI_API_KEY=your_key
ANTHROPIC_API_KEY=your_key  # For Claude co-pilot
SUPABASE_URL=your_url
SUPABASE_KEY=your_key
REDDIT_CLIENT_ID=your_id
REDDIT_CLIENT_SECRET=your_secret
```

---

## Categories

| Category | Description |
|----------|-------------|
| `restaurant` | Restaurants, cafes, bars |
| `hotel` | Hotels, hostels, boutique stays |
| `club` | Nightclubs, bars, lounges |
| `tour_operator` | Tour companies, experiences |
| `spa` | Spas, wellness centers |
| `boat_charter` | Yacht charters, boat tours |
| `photographer` | Event and travel photographers |
| `videographer` | Video production |
| `chef` | Private chefs, catering |
| `event_planner` | Event planning services |
| `DJ` | DJs and entertainment |
| `real_estate` | Real estate agencies |
| `gym` | Fitness centers |
| `coworking` | Coworking spaces |

---

## The System

```
SCAN → ENRICH → SCORE → GENERATE → EXECUTE

1. Scan businesses via Google Places API
2. Enrich with AI analysis + opportunity scoring
3. Generate psychology-driven outreach scripts
4. Dashboard with click-to-copy + pre-filled links
5. Co-Pilot for real-time response drafting
```

---

## Data Flow

```
┌─────────────────────────────────────────┐
│           DATA COLLECTION               │
│  Google Places │ Website │ Reddit       │
└──────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────┐
│           AI ENRICHMENT                 │
│  OpenAI Analysis │ Scoring │ Hooks      │
└──────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────┐
│         PSYCHOLOGY ENGINE               │
│  Neuroscience │ NLP │ Behavioral Econ   │
└──────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────┐
│          OUTREACH READY                 │
│  Dashboard │ Scripts │ Links            │
└──────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────┐
│          CLAUDE CO-PILOT                │
│  Response Draft │ Objection Handle      │
└──────────────────────────────────────────┘
```

---

## API Costs

| Service | Operation | Cost |
|---------|-----------|------|
| Google Places | Nearby Search | ~$0.017/request |
| OpenAI | Enrichment | ~$0.0001/business |
| Claude | Co-pilot | ~$0.02/interaction |
| Supabase | Storage | Free tier |

**50 businesses full pipeline: ~$0.10**

---

*Phil McGill | Colombia's AI Authority*
*47 Years Research • 1,400+ Transformations • $4.7M Results*
